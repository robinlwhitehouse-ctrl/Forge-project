"""Forge Stage (new layout). Prep stays in main Library. Does not replace forge_next.py."""

from __future__ import annotations

import json
import random
import traceback
from pathlib import Path
import os
import tkinter as tk
VIDEO_SUFFIXES = {".mp4", ".webm", ".mov", ".mkv", ".avi"}
from tkinter import simpledialog
from tkinter import filedialog, messagebox, ttk

from core.projects import ProjectRepository
from core.records import RecordRepository
from core.player_characters import PlayerCharacterRepository
from core.npcs import NPCRepository
from core.monsters import CREATURE_TYPES, MonsterRepository
from core.locations import LocationRepository
from core.shops import ShopRepository
from core.factions import FactionRepository
from core.maps import MapRepository
from core.map_display import MapDisplayRepository
from core.scripts import ScriptRepository
from core.story_tracker import StoryTrackerRepository
from core.calendar import CalendarRepository, CampaignCalendar, harptos
from core.world_clock import WorldClockRepository
from core.tables import TableRepository
from core.companions import CompanionRepository
from core.notes import CampaignNote, NotesRepository, new_note_id
from core.materials import MaterialsRepository
from core.quests import QuestRepository
from core.items import ItemRepository
from core.traps import TrapRepository
from core.weapons import WeaponRepository
from core.armor import ArmorRepository
from core.assets import AssetRepository
from core.audio_player import AudioPlayer
from core.errorlog import install as install_errorlog, log_exception

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except Exception:
    HAS_PIL = False

BG, FG, GOLD, PANEL = "#2b2d31", "#e6e6e6", "#c9b458", "#36393f"


def _safe_int(value, default=0) -> int:
    try:
        return int(str(value).strip() or default)
    except (TypeError, ValueError):
        return default


class ForgeStage(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        install_errorlog(self)  # log unhandled errors to logs/forge_errors.log
        self.title("Forge Stage 301")
        self.geometry("1480x900")
        self.configure(bg=BG)
        self.forge_root = None
        self.project = None
        self.repos = {}
        self.board = []
        self.turn = 0
        self._photo = None
        self._tv_photo = None
        self._img_size = (1, 1)
        self._drag = None
        self._pan_last = None
        self._tv = None
        self._beat_index = 0
        self.audio = AudioPlayer()
        self.sfx = AudioPlayer(role="sfx")
        self._build_style()
        self._build()
        self._load_last_root()
        self._tick_countdown()
        self._restore_stage_size()
        self.protocol("WM_DELETE_WINDOW", self.close_stage)

    def _build_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(".", background=BG, foreground=FG, fieldbackground=PANEL)
        style.configure("TFrame", background=BG)
        style.configure("TLabel", background=BG, foreground=FG)
        style.configure("TLabelframe", background=BG, foreground=GOLD)
        style.configure("TLabelframe.Label", background=BG, foreground=GOLD)
        style.configure("TButton", background=PANEL, foreground=FG)
        style.configure("Gold.TLabel", background=BG, foreground=GOLD, font=("Segoe UI", 14, "bold"))

    def _build(self) -> None:
        self._font_size = 10
        self._reveal_size = 0.08
        self._brush_cells = 0.5
        menubar = tk.Menu(self)
        file_m = tk.Menu(menubar, tearoff=0)
        file_m.add_command(label="Forge folder…", command=self.choose_root)
        file_m.add_command(label="Push TV", command=self.push_tv)
        file_m.add_separator()
        file_m.add_command(label="Music off", command=self.music_off)
        file_m.add_command(label="Music on (follow beats)", command=self.music_on)
        vol_m = tk.Menu(file_m, tearoff=0)
        for label, level in (("25%", 0.25), ("50%", 0.5), ("75%", 0.75), ("100%", 1.0)):
            vol_m.add_command(label=label, command=lambda v=level: self.set_chapter_volume(v))
        file_m.add_cascade(label="Chapter volume", menu=vol_m)
        file_m.add_separator()
        file_m.add_command(label="Exit", command=self.destroy)
        menubar.add_cascade(label="File", menu=file_m)
        view_m = tk.Menu(menubar, tearoff=0)
        text_m = tk.Menu(view_m, tearoff=0)
        for label, size in (("Small", 9), ("Normal", 10), ("Large", 13), ("XL", 16)):
            text_m.add_command(label=label, command=lambda s=size: self.set_text_size(s))
        view_m.add_cascade(label="Text size", menu=text_m)
        win_m = tk.Menu(view_m, tearoff=0)
        win_m.add_command(label="Maximized", command=self.stage_maximize)
        win_m.add_command(label="Fit screen", command=self.stage_fit_screen)
        win_m.add_command(label="Compact", command=lambda: self.stage_window("1280x800"))
        win_m.add_command(label="Wide", command=lambda: self.stage_window("1920x1080"))
        win_m.add_separator()
        win_m.add_command(label="Remember this size", command=self.remember_stage_size)
        view_m.add_cascade(label="Stage size", menu=win_m)
        fog_m = tk.Menu(view_m, tearoff=0)
        for label, size in (("Small reveal", 0.08), ("Medium reveal", 0.16), ("Large reveal", 0.28), ("Huge reveal", 0.40)):
            fog_m.add_command(label=label, command=lambda s=size: self.set_reveal_size(s))
        view_m.add_cascade(label="Fog brush", menu=fog_m)
        vis_m = tk.Menu(view_m, tearoff=0)
        vis_m.add_command(label="Vision off", command=lambda: self.set_vision(0))
        vis_m.add_command(label="30 ft  (6 squares)", command=lambda: self.set_vision(6))
        vis_m.add_command(label="60 ft  (12 squares)", command=lambda: self.set_vision(12))
        vis_m.add_command(label="120 ft (24 squares)", command=lambda: self.set_vision(24))
        vis_m.add_command(label="Custom squares…", command=self.ask_vision)
        view_m.add_cascade(label="Token vision", menu=vis_m)
        wall_m = tk.Menu(view_m, tearoff=0)
        wall_m.add_command(label="Trace wall", command=lambda: self.start_wall_trace(False))
        wall_m.add_command(label="Trace door", command=lambda: self.start_wall_trace(True))
        wall_m.add_command(label="Stop tracing", command=self.stop_wall_trace)
        wall_m.add_separator()
        wall_m.add_command(label="Undo last line", command=self.undo_wall)
        wall_m.add_command(label="Clear walls", command=self.clear_walls)
        view_m.add_cascade(label="Walls", menu=wall_m)
        zoom_m = tk.Menu(view_m, tearoff=0)
        zoom_m.add_command(label="Zoom in", command=lambda: self.nudge_zoom(1.25))
        zoom_m.add_command(label="Zoom out", command=lambda: self.nudge_zoom(0.8))
        zoom_m.add_command(label="Reset zoom", command=self.reset_zoom)
        view_m.add_cascade(label="Map zoom", menu=zoom_m)
        grid_m = tk.Menu(view_m, tearoff=0)
        grid_m.add_command(label="Grid on/off", command=self.toggle_grid)
        for label, px in (("Fine 32px", 32), ("Default 50px", 50), ("Medium 64px", 64), ("Coarse 80px", 80), ("Large 100px", 100)):
            grid_m.add_command(label=label, command=lambda p=px: self.set_grid_size(p))
        grid_m.add_command(label="Grid size…", command=self.ask_grid_size)
        grid_m.add_separator()
        grid_m.add_command(label="Nudge grid left", command=lambda: self.nudge_grid(-4, 0))
        grid_m.add_command(label="Nudge grid right", command=lambda: self.nudge_grid(4, 0))
        grid_m.add_command(label="Nudge grid up", command=lambda: self.nudge_grid(0, -4))
        grid_m.add_command(label="Nudge grid down", command=lambda: self.nudge_grid(0, 4))
        grid_m.add_command(label="Reset grid offset", command=lambda: self.nudge_grid(0, 0, reset=True))
        grid_m.add_separator()
        grid_m.add_command(label="Soft lines", command=lambda: self.set_grid_style(False))
        grid_m.add_command(label="Strong lines (TV)", command=lambda: self.set_grid_style(True))
        for label, color in (("White", "#ffffff"), ("Gold", "#e6c35c"), ("Cyan", "#7ec8e3"), ("Black", "#111111")):
            grid_m.add_command(label=f"Color {label}", command=lambda c=color: self.set_grid_color(c))
        view_m.add_cascade(label="Grid", menu=grid_m)
        view_m.add_separator()
        view_m.add_command(label="Brush on/off", command=self.toggle_brush)
        view_m.add_command(label="Fog on/off", command=self.toggle_fog)
        view_m.add_command(label="Cover all (fog on)", command=self.cover_all_fog)
        view_m.add_command(label="Fog off — show map", command=self.fog_off)
        view_m.add_separator()
        view_m.add_command(label="Live clock on/off", command=lambda: (self.live_clock.set(not self.live_clock.get()), self.toggle_live_clock()))
        menubar.add_cascade(label="View", menu=view_m)
        tools_m = tk.Menu(menubar, tearoff=0)
        tools_m.add_command(label="Board ← tokens", command=self.board_from_tokens)
        tools_m.add_command(label="Roll initiative 1d20", command=self.roll_init)
        tools_m.add_separator()
        tools_m.add_command(label="Turn timer 1 min", command=lambda: self.start_turn_timer(60))
        tools_m.add_command(label="Turn timer 6 min", command=lambda: self.start_turn_timer(360))
        tools_m.add_command(label="Cancel turn timer", command=self.cancel_turn_timer)
        tools_m.add_separator()
        tools_m.add_command(label="Clear story log", command=self.clear_story_log)
        tools_m.add_command(label="Reset story tracker", command=self.reset_story_tracker)
        tools_m.add_separator()
        tools_m.add_command(label="Camp watch…", command=self.open_camp_watch)
        tools_m.add_command(label="Reset clock…", command=self.reset_clock)
        tools_m.add_command(label="Calendar settings…", command=self.open_calendar_settings)
        tools_m.add_command(label="Roll tables…", command=self.open_roll_tables)
        tools_m.add_command(label="SRD lookup…", command=self.open_srd_lookup)
        tools_m.add_separator()
        tools_m.add_command(label="Open PDF…", command=self.open_pdf_tool)
        menubar.add_cascade(label="Tools", menu=tools_m)
        self.config(menu=menubar)
        top = ttk.Frame(self, padding=8)
        top.pack(fill="x")
        ttk.Label(top, text="STAGE", style="Gold.TLabel").pack(side="left")
        ttk.Label(top, text="  File menu: folder + Push TV").pack(side="left")
        self.status = tk.StringVar(value="Choose the Forge folder that contains projects\\")
        ttk.Label(self, textvariable=self.status).pack(fill="x", padx=8)

        body = ttk.Panedwindow(self, orient="horizontal")
        body.pack(fill="both", expand=True, padx=8, pady=8)

        map_wrap = ttk.Frame(body)
        body.add(map_wrap, weight=4)
        mf = ttk.LabelFrame(map_wrap, text="DM map", padding=6)
        mf.pack(fill="both", expand=True)
        row = ttk.Frame(mf)
        row.pack(fill="x")
        ttk.Label(row, text="DM").pack(side="left")
        self._dm_name = tk.StringVar(value="")
        self._tv_name = tk.StringVar(value="")
        self._dm_menu = ttk.Combobox(row, textvariable=self._dm_name, width=14, state="readonly")
        self._dm_menu.pack(side="left", padx=4)
        self._dm_menu.bind("<<ComboboxSelected>>", lambda _e: self._on_dm_picked())
        ttk.Label(row, text="TV").pack(side="left", padx=(6, 0))
        self._tv_menu = ttk.Combobox(row, textvariable=self._tv_name, width=14, state="readonly")
        self._tv_menu.pack(side="left", padx=4)
        self._tv_menu.bind("<<ComboboxSelected>>", lambda _e: self._on_tv_picked())
        self.fog_on = tk.BooleanVar(value=False)
        self.brush_btn = ttk.Button(row, text="Brush off", command=self.toggle_brush)
        self.brush_btn.pack(side="left", padx=4)
        self.canvas = tk.Canvas(mf, bg="#1a1c20", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, pady=(6, 0))
        self.canvas.bind("<Configure>", lambda _e: self._safe_draw())
        self.canvas.bind("<Button-1>", self._on_down)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_up)
        self.bind_all("<KeyPress>", self._wall_hotkey)
        for key in ("w", "W", "d", "D", "c", "C", "f", "F", "b", "B", "r", "R", "Escape"):
            self.bind_all(f"<KeyPress-{key}>", self._wall_hotkey)
            self.canvas.bind(f"<KeyPress-{key}>", self._wall_hotkey)
        self.bind_all("<Control-KeyPress-z>", self._wall_hotkey)
        self.bind_all("<Control-KeyPress-Z>", self._wall_hotkey)
        self.canvas.configure(takefocus=True)
        self.canvas.bind("<Button-3>", self._on_right)
        self.canvas.bind("<MouseWheel>", self._on_wheel)
        self.canvas.bind("<Button-4>", lambda e: self._on_wheel_dir(e, 1))
        self.canvas.bind("<Button-5>", lambda e: self._on_wheel_dir(e, -1))
        self.canvas.bind("<Button-2>", self._pan_start)
        self.canvas.bind("<B2-Motion>", self._pan_move)
        self._zoom = 1.0
        self._vision_cells = 0
        self._pan = [0.0, 0.0]  # fraction of displayed map width/height

        strip = ttk.Frame(body)
        body.add(strip, weight=1)
        canvas = tk.Canvas(strip, bg=BG, highlightthickness=0)
        scroll = ttk.Scrollbar(strip, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        def _widen(e):
            if canvas.find_all():
                canvas.itemconfigure(canvas.find_all()[0], width=max(e.width - 18, 200))
        strip.bind("<Configure>", _widen)
        self._build_now(inner)
        self._build_board(inner)
        self._build_notes(inner)
        self._build_log(inner)
        self._build_pull(inner)

    def _build_now(self, parent) -> None:
        box = ttk.LabelFrame(parent, text="1. Now", padding=8)
        box.pack(fill="x", pady=(0, 8))
        clk = ttk.Frame(box)
        clk.pack(fill="x")
        self.clock_var = tk.StringVar(value="Clock: —")
        ttk.Label(clk, textvariable=self.clock_var).pack(side="left")
        ttk.Button(clk, text="+1h", command=lambda: self.advance_clock(1)).pack(side="right")
        ttk.Button(clk, text="+8h", command=lambda: self.advance_clock(8)).pack(side="right", padx=4)
        rest = ttk.Frame(box)
        rest.pack(fill="x", pady=(4, 0))
        ttk.Button(rest, text="Short rest", command=lambda: self.offer_rest("short")).pack(side="left")
        ttk.Button(rest, text="Long rest", command=lambda: self.offer_rest("long")).pack(side="left", padx=4)
        self.rest_var = tk.StringVar(value="Rest: no party yet")
        ttk.Label(rest, textvariable=self.rest_var, wraplength=280).pack(side="left", padx=6)
        self.live_clock = tk.BooleanVar(value=False)
        ttk.Checkbutton(clk, text="Live 15m", variable=self.live_clock, command=self.toggle_live_clock).pack(side="right", padx=8)
        self.countdown_var = tk.StringVar(value="--:--")
        ttk.Label(clk, textvariable=self.countdown_var, font=("Consolas", 12, "bold")).pack(side="right", padx=8)
        ttk.Button(clk, text="Turn 1m", command=lambda: self.start_turn_timer(60)).pack(side="right")
        ttk.Button(clk, text="Turn 6m", command=lambda: self.start_turn_timer(360)).pack(side="right", padx=4)
        self.watch_night_var = tk.StringVar(value="Camp")
        self.watch_on_var = tk.StringVar()
        self.watch_asleep_var = tk.StringVar()
        self.watch_shift_var = tk.StringVar(value="1")
        self.watch_shifts_var = tk.StringVar(value="4")
        self.watch_hours_per_var = tk.StringVar(value="2")
        self.watch_hour_var = tk.StringVar(value="0")
        self.watch_status_var = tk.StringVar(value="Camp watch closed")
        self.watch_add_var = tk.StringVar()
        self.watch_con_var = tk.StringVar(value="0")
        self.watch_chance_var = tk.StringVar(value="6")
        self.watch_type_var = tk.StringVar(value="Any")
        self.watch_encounter_var = tk.StringVar(value="No encounter yet")
        self.watch_seconds_var = tk.StringVar(value="60")
        self.watch_sleep_var = tk.StringVar(value="Sleep: none yet")
        self._watch_marks = []
        self._watch_encounters = {}
        self._watch_sleep = {}
        self._watch_roster = []
        watch_line = ttk.Frame(box)
        watch_line.pack(fill="x", pady=(8, 0))
        ttk.Button(watch_line, text="Camp watch…", command=self.open_camp_watch).pack(side="left")
        ttk.Label(watch_line, textvariable=self.watch_status_var, wraplength=240).pack(side="left", padx=6)
        ttk.Label(box, text="Script").pack(anchor="w", pady=(6, 0))
        self.script_var = tk.StringVar()
        self.script_combo = ttk.Combobox(box, textvariable=self.script_var, state="readonly")
        self.script_combo.pack(fill="x")
        self.script_combo.bind("<<ComboboxSelected>>", lambda _e: self._select_script())
        self.script_now_var = tk.StringVar(value="")
        ttk.Label(box, textvariable=self.script_now_var, style="Gold.TLabel").pack(anchor="w", pady=(6, 0))
        self.beat_var = tk.StringVar(value="No beat")
        ttk.Label(box, textvariable=self.beat_var).pack(anchor="w", pady=(2, 0))
        self.beat_rest_btn = ttk.Button(box, text="Take rest", command=self.take_beat_rest)
        self.beat_rest_btn.pack(anchor="w", pady=(2, 0))
        self.beat_rest_btn.pack_forget()
        adv = ttk.Frame(box)
        adv.pack(fill="x", pady=(2, 0))
        self.beat_advance_label = ttk.Label(adv, text="This beat")
        self.beat_advance_label.pack(side="left")
        self.beat_advance_var = tk.StringVar()
        self.beat_advance_entry = ttk.Entry(adv, textvariable=self.beat_advance_var, width=6)
        self.beat_advance_entry.pack(side="left", padx=4)
        self.beat_advance_hint = ttk.Label(adv, text="min (blank uses the beat)")
        self.beat_advance_hint.pack(side="left")
        clips = ttk.LabelFrame(box, text="Beat audio", padding=4)
        clips.pack(fill="x", pady=(4, 0))
        self.beat_audio_list = tk.Listbox(clips, height=3, bg=PANEL, fg=FG, selectbackground=GOLD, selectforeground="#111")
        self.beat_audio_list.pack(fill="x")
        crow = ttk.Frame(clips)
        crow.pack(fill="x", pady=(4, 0))
        ttk.Button(crow, text="Play clip", command=self.play_beat_clip).pack(side="left")
        ttk.Button(crow, text="Stop clip", command=self.stop_beat_clip).pack(side="left", padx=4)
        self.beat_video_button = ttk.Button(crow, text="▶ Video", command=self.play_beat_video, state="disabled")
        self.beat_video_button.pack(side="left", padx=(12, 0))
        ttk.Label(box, text="Places").pack(anchor="w")
        self.places_box = tk.Text(box, height=3, wrap="word", bg="#2a2c30", fg=FG, insertbackground=FG)
        self.places_box.pack(fill="x", pady=(0, 4))
        self.places_box.bind("<Double-Button-1>", lambda _e: self.open_place_line())
        ttk.Label(box, text="Narration for this beat").pack(anchor="w", pady=(6, 0))
        self.narration = tk.Text(box, height=5, wrap="word", bg=PANEL, fg=FG, insertbackground=FG)
        self.narration.pack(fill="x", pady=(0, 4))
        ttk.Label(box, text="GM notes (this beat)").pack(anchor="w")
        self.gm_notes = tk.Text(box, height=4, wrap="word", bg="#2a2c30", fg=FG, insertbackground=FG)
        self.gm_notes.pack(fill="x", pady=(0, 4))
        ttk.Label(box, text="DM items (this beat)").pack(anchor="w")
        self.dm_items_box = tk.Text(box, height=3, wrap="word", bg="#2a2c30", fg=FG, insertbackground=FG)
        self.dm_items_box.pack(fill="x", pady=(0, 4))
        self.dm_items_box.bind("<Double-Button-1>", lambda _e: self.open_dm_item())
        ttk.Label(box, text="Related quests").pack(anchor="w")
        self.quests_box = tk.Text(box, height=3, wrap="word", bg="#2a2c30", fg=FG, insertbackground=FG)
        self.quests_box.pack(fill="x", pady=(0, 4))
        self.quests_box.bind("<Double-Button-1>", lambda _e: self.open_related_quest())
        nav = ttk.Frame(box)
        nav.pack(fill="x")
        ttk.Button(nav, text="Prev", command=lambda: self.show_beat(-1)).pack(side="left")
        ttk.Button(nav, text="Next", command=lambda: self.show_beat(1)).pack(side="left", padx=4)
        ttk.Button(nav, text="Mark done", command=self.mark_beat).pack(side="left")
        ttk.Button(nav, text="Play chapter", command=self.play_beat_music).pack(side="left", padx=4)
        ttk.Button(nav, text="Stop", command=lambda: self.audio.stop()).pack(side="left")
        ttk.Label(box, text="Choices").pack(anchor="w", pady=(8, 0))
        self.choice_box = ttk.Frame(box)
        self.choice_box.pack(fill="x", pady=(0, 6))


    def open_camp_watch(self) -> None:
        win = getattr(self, "_watch_win", None)
        if win is not None and win.winfo_exists():
            win.lift()
            return
        win = tk.Toplevel(self)
        win.title("Camp watch")
        win.geometry("460x560")
        self._watch_win = win
        watch = ttk.Frame(win, padding=10)
        watch.pack(fill="both", expand=True)
        ttk.Label(watch, text="Night").grid(row=0, column=0, sticky="w")
        ttk.Entry(watch, textvariable=self.watch_night_var).grid(row=0, column=1, columnspan=3, sticky="ew", padx=4)
        ttk.Label(watch, text="Add").grid(row=1, column=0, sticky="w", pady=(4, 0))
        add_row = ttk.Frame(watch)
        add_row.grid(row=1, column=1, columnspan=3, sticky="ew", pady=(4, 0))
        ttk.Entry(add_row, textvariable=self.watch_add_var).pack(side="left", fill="x", expand=True)
        ttk.Label(add_row, text="Con").pack(side="left", padx=(6, 2))
        ttk.Entry(add_row, textvariable=self.watch_con_var, width=4).pack(side="left")
        ttk.Button(add_row, text="Add", command=self.watch_add_person).pack(side="left", padx=4)
        self.watch_people = tk.Listbox(watch, height=4, exportselection=False)
        self.watch_people.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        roles = ttk.Frame(watch)
        roles.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        ttk.Button(roles, text="On watch", command=lambda: self.watch_set_role("watch")).pack(side="left")
        ttk.Button(roles, text="Asleep", command=lambda: self.watch_set_role("asleep")).pack(side="left", padx=4)
        ttk.Button(roles, text="Remove", command=self.watch_remove_person).pack(side="left")
        ttk.Button(roles, text="DC 10 Con", command=self.watch_con_save).pack(side="left", padx=4)
        encounter = ttk.Frame(watch)
        encounter.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        ttk.Button(encounter, text="Roll watch", command=self.watch_roll).pack(side="left")
        ttk.Label(encounter, text="1 in").pack(side="left", padx=(6, 2))
        ttk.Entry(encounter, textvariable=self.watch_chance_var, width=4).pack(side="left")
        ttk.Label(encounter, text="Type").pack(side="left", padx=(6, 2))
        ttk.Combobox(encounter, textvariable=self.watch_type_var, values=("Any",) + CREATURE_TYPES, state="readonly", width=12).pack(side="left")
        ttk.Label(watch, textvariable=self.watch_encounter_var, wraplength=280).grid(row=5, column=0, columnspan=4, sticky="w")
        ttk.Label(watch, text="Shift").grid(row=6, column=0, sticky="w", pady=(4, 0))
        ttk.Entry(watch, textvariable=self.watch_shift_var, width=4).grid(row=6, column=1, sticky="w", padx=4, pady=(4, 0))
        ttk.Label(watch, text="of").grid(row=6, column=2, sticky="w")
        ttk.Entry(watch, textvariable=self.watch_shifts_var, width=4).grid(row=6, column=3, sticky="w")
        ttk.Label(watch, text="Hours / shift").grid(row=7, column=0, sticky="w", pady=(4, 0))
        ttk.Entry(watch, textvariable=self.watch_hours_per_var, width=4).grid(row=7, column=1, sticky="w", padx=4, pady=(4, 0))
        ttk.Label(watch, text="Hour").grid(row=8, column=0, sticky="w", pady=(4, 0))
        ttk.Label(watch, textvariable=self.watch_hour_var, font=("Consolas", 14, "bold")).grid(row=8, column=1, sticky="w", padx=4)
        ttk.Label(watch, text="Checks").grid(row=9, column=0, sticky="nw", pady=(6, 0))
        self.watch_checks_frame = ttk.Frame(watch)
        self.watch_checks_frame.grid(row=9, column=1, columnspan=3, sticky="ew", pady=(6, 0))
        btns = ttk.Frame(watch)
        btns.grid(row=10, column=0, columnspan=4, sticky="ew", pady=(6, 0))
        ttk.Button(btns, text="Next hour", command=self.watch_next_hour).pack(side="left")
        ttk.Button(btns, text="Next shift", command=self.watch_next_shift).pack(side="left", padx=4)
        ttk.Button(btns, text="Next night", command=self.watch_reset).pack(side="left", padx=4)
        auto = ttk.Frame(watch)
        auto.grid(row=11, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        ttk.Button(auto, text="Start hours", command=self.watch_start_auto).pack(side="left")
        ttk.Button(auto, text="Pause", command=self.watch_pause_auto).pack(side="left", padx=4)
        ttk.Label(auto, text="sec / hour").pack(side="left", padx=(8, 4))
        ttk.Entry(auto, textvariable=self.watch_seconds_var, width=5).pack(side="left")
        ttk.Label(watch, textvariable=self.watch_sleep_var, wraplength=280).grid(row=12, column=0, columnspan=4, sticky="w", pady=(4, 0))
        ttk.Label(watch, textvariable=self.watch_status_var, wraplength=280).grid(row=13, column=0, columnspan=4, sticky="w", pady=(2, 0))
        watch.columnconfigure(1, weight=1)
        self._refresh_watch_people()
        self._refresh_watch_marks()

    def _build_board(self, parent) -> None:
        box = ttk.LabelFrame(parent, text="2. Board", padding=8)
        box.pack(fill="x", pady=(0, 8))
        cols = ttk.Frame(box)
        cols.pack(fill="x")
        self.add_kind = tk.StringVar(value="Monster")
        ttk.Combobox(cols, textvariable=self.add_kind, values=("PC", "NPC", "Monster", "Companion"), state="readonly", width=8).pack(side="left")
        self.add_search = tk.StringVar()
        ttk.Entry(cols, textvariable=self.add_search, width=8).pack(side="left", padx=4)
        self.add_search.trace_add("write", lambda *_: self._refill_add())
        self.add_pick = tk.StringVar()
        self.add_combo = ttk.Combobox(cols, textvariable=self.add_pick, width=12)
        self.add_combo.pack(side="left", padx=4)
        row2 = ttk.Frame(box)
        row2.pack(fill="x", pady=(4, 0))
        ttk.Button(row2, text="Add", command=self.add_to_board).pack(side="left")
        ttk.Label(row2, text="Tag").pack(side="left", padx=(8, 2))
        self.add_tag = tk.StringVar()
        ttk.Entry(row2, textvariable=self.add_tag, width=4).pack(side="left")
        ttk.Button(row2, text="Set tag", command=self.set_board_tag).pack(side="left", padx=4)
        self.board_list = tk.Listbox(box, height=10, bg=PANEL, fg=FG, selectbackground=GOLD, selectforeground="#111")
        self.board_list.pack(fill="x", pady=6)
        self.board_list.bind("<Double-Button-1>", lambda _e: self.open_board_record())
        btns = ttk.Frame(box)
        btns.pack(fill="x")
        ttk.Label(btns, text="Init").pack(side="left")
        self.init_entry = tk.StringVar()
        ttk.Entry(btns, textvariable=self.init_entry, width=4).pack(side="left", padx=2)
        ttk.Button(btns, text="Set", command=self.set_init).pack(side="left")
        ttk.Button(btns, text="Next turn", command=self.next_turn).pack(side="left", padx=4)
        ttk.Button(btns, text="-5 HP", command=lambda: self.adjust_hp(-5)).pack(side="left")
        ttk.Button(btns, text="+5 HP", command=lambda: self.adjust_hp(5)).pack(side="left", padx=4)
        ttk.Button(btns, text="Remove", command=self.remove_board).pack(side="left")
        ttk.Button(btns, text="Open record", command=self.open_board_record).pack(side="left", padx=4)
        self.turn_var = tk.StringVar(value="No turn")
        ttk.Label(box, textvariable=self.turn_var).pack(anchor="w")


    def _build_notes(self, parent) -> None:
        box = ttk.LabelFrame(parent, text="3. Notes (this beat)", padding=8)
        box.pack(fill="x", pady=(0, 8))
        ttk.Label(box, text="Double-click a line to read. Attach notes in Library → Scripts.").pack(anchor="w")
        self.stage_note_body = tk.Text(box, height=6, wrap="word", bg=PANEL, fg=FG, insertbackground=FG)
        self.stage_note_body.pack(fill="x", pady=(4, 0))
        self.stage_note_body.bind("<Double-Button-1>", lambda _e: self._open_beat_note_line())
        ttk.Button(box, text="Save notes on this beat", command=self._save_beat_notes).pack(anchor="w", pady=(4, 0))

    def _refresh_stage_notes(self) -> None:
        repo = self.repos.get("notes") if getattr(self, "repos", None) else None
        if repo is None or not hasattr(self, "note_combo"):
            return
        notes = repo.notes()
        self._stage_notes = notes
        self.note_combo["values"] = [n.title for n in notes] or ["(no notes)"]
        if notes and not self.note_pick.get():
            self.note_combo.current(0)

    def _load_stage_note(self) -> None:
        notes = getattr(self, "_stage_notes", [])
        idx = self.note_combo.current() if hasattr(self, "note_combo") else -1
        if idx < 0 or idx >= len(notes):
            return
        note = notes[idx]
        self._stage_note_id = note.note_id
        self.note_title_var.set(note.title)
        self.stage_note_body.delete("1.0", "end")
        self.stage_note_body.insert("1.0", note.body)

    def _new_stage_note(self) -> None:
        self._stage_note_id = None
        self.note_title_var.set("Session note")
        self.stage_note_body.delete("1.0", "end")
        self.note_pick.set("")


    def _add_workbook_note_to_beat(self) -> None:
        title = (self.note_pick.get() if hasattr(self, "note_pick") else "").strip()
        repo = self.repos.get("notes") if getattr(self, "repos", None) else None
        if repo is None or not title:
            return
        note = next((n for n in repo.notes() if n.title == title), None)
        if note is None:
            return
        line = f"{note.title} | Note | {note.note_id}"
        cur = self.stage_note_body.get("1.0", "end-1c").strip()
        self.stage_note_body.delete("1.0", "end")
        self.stage_note_body.insert("1.0", (cur + "\n" + line).strip() + "\n")
        self._save_beat_notes()

    def _open_beat_note_line(self) -> None:
        if not hasattr(self, "stage_note_body"):
            return
        try:
            line = self.stage_note_body.get("insert linestart", "insert lineend").strip()
        except tk.TclError:
            return
        if "| Note |" in line or line.startswith("NOTE-"):
            self.open_library_line(line if "|" in line else line)
            return
        # open workbook page by title
        repo = self.repos.get("notes") if getattr(self, "repos", None) else None
        if repo is None:
            return
        note = next((n for n in repo.notes() if n.title == line or n.title in line), None)
        if note is None:
            return
        self._popup_entry(note.title, "Note", note.note_id, note.body)

    def _save_beat_notes(self) -> None:
        scripts = getattr(self, "_scripts", [])
        idx = self.script_combo.current() if hasattr(self, "script_combo") else -1
        if idx < 0 or idx >= len(scripts) or not hasattr(self, "stage_note_body"):
            return
        script = scripts[idx]
        beats = list(script.details.beats or [])
        bidx = getattr(self, "_beat_index", 0)
        if bidx < 0 or bidx >= len(beats):
            return
        beats[bidx].table_notes = self.stage_note_body.get("1.0", "end-1c")
        self.repos["script"].update_script(
            script.record.record_id,
            script.record.name,
            script.record.status,
            script.record.description,
            linked_quest_id=getattr(script.details, "linked_quest_id", ""),
            linked_session_id=getattr(script.details, "linked_session_id", ""),
            beats=beats,
            next_script_id=getattr(script.details, "next_script_id", ""),
            music_path=getattr(script.details, "music_path", ""),
            music_loop=getattr(script.details, "music_loop", True),
        )
        self._scripts = self.repos["script"].scripts()
        self.status.set("Saved notes for this beat")

    def _save_stage_note(self) -> None:

        repo = self.repos.get("notes") if getattr(self, "repos", None) else None
        if repo is None:
            return
        note = CampaignNote(
            note_id=self._stage_note_id or new_note_id(),
            title=self.note_title_var.get().strip() or "Untitled",
            body=self.stage_note_body.get("1.0", "end-1c"),
        )
        note = repo.save(note)
        self._stage_note_id = note.note_id
        self._refresh_stage_notes()
        self.status.set(f"Saved note: {note.title}")

    def _build_log(self, parent) -> None:
        box = ttk.LabelFrame(parent, text="3. Log", padding=8)
        box.pack(fill="x", pady=(0, 8))
        self.log_box = tk.Text(box, height=8, wrap="word", bg=PANEL, fg=FG, insertbackground=FG)
        self.log_box.pack(fill="x")
        self.log_box.tag_configure("found", foreground="#e8c36a", underline=True)
        self.log_box.tag_configure("met", foreground="#8ec8ff")
        self.log_box.tag_configure("beat", foreground="#b8b8b8")
        self.log_box.bind("<Double-Button-1>", lambda _e: self.open_log_record())

    def _build_pull(self, parent) -> None:
        box = ttk.LabelFrame(parent, text="4. Pull", padding=8)
        box.pack(fill="x")
        ttk.Label(box, text="Table").pack(anchor="w")
        self.table_var = tk.StringVar()
        self.table_combo = ttk.Combobox(box, textvariable=self.table_var, state="readonly")
        self.table_combo.pack(fill="x")
        ttk.Button(box, text="Roll", command=self.roll_table).pack(anchor="w", pady=4)
        self.table_result = tk.StringVar(value="—")
        ttk.Label(box, textvariable=self.table_result, wraplength=360).pack(anchor="w")
        ttk.Label(box, text="SFX file").pack(anchor="w", pady=(8, 0))
        sfx = ttk.Frame(box)
        sfx.pack(fill="x")
        self.sfx_var = tk.StringVar()
        ttk.Entry(sfx, textvariable=self.sfx_var).pack(side="left", fill="x", expand=True)
        ttk.Button(sfx, text="Browse", command=self.browse_sfx).pack(side="left", padx=4)
        ttk.Button(sfx, text="Play", command=self.play_sfx).pack(side="left")

    def _ui_state(self) -> Path:
        return Path(__file__).resolve().parent / "forge_stage_ui.json"


    def set_text_size(self, size: int) -> None:
        self._font_size = int(size)
        font = ("Segoe UI", self._font_size)
        for widget in (getattr(self, "narration", None), getattr(self, "gm_notes", None), getattr(self, "dm_items_box", None), getattr(self, "quests_box", None), getattr(self, "log_box", None), getattr(self, "board_list", None)):
            if widget is None:
                continue
            try:
                widget.configure(font=font)
            except tk.TclError:
                pass
        try:
            ttk.Style(self).configure("TLabel", font=font)
            ttk.Style(self).configure("TButton", font=font)
        except tk.TclError:
            pass

    def set_brush_cells(self, cells: float) -> None:
        self._brush_cells = max(0.25, float(cells))
        self.status.set(f"Brush {self._brush_cells:g} grid")

    def set_reveal_size(self, size: float) -> None:

        self._reveal_size = float(size)
        self.status.set(f"Fog reveal size {int(self._reveal_size * 100)}% of map")

    def choose_root(self) -> None:
        path = filedialog.askdirectory(title="Select Forge folder (contains projects\\)")
        if not path:
            return
        self.forge_root = Path(path)
        self._save_ui_state()
        self.open_project()

    def _load_last_root(self) -> None:
        path = self._ui_state()
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                self._ui = data if isinstance(data, dict) else {}
                root = Path(self._ui.get("forge_root") or "")
                if root.exists():
                    self.forge_root = root
                    self.open_project()
                    if self._ui.get("live_clock") and hasattr(self, "live_clock"):
                        self.live_clock.set(True)
                        self.toggle_live_clock()
                    return
            except Exception:
                log_exception()
        here = Path(__file__).resolve().parent
        if (here / "projects").exists():
            self.forge_root = here
            self.open_project()

    def open_project(self) -> None:
        repo = ProjectRepository(self.forge_root)
        projects = repo.list()
        if not projects:
            self.status.set(f"No projects in {self.forge_root}")
            return
        active = repo.active_project_id()
        project = next((p for p in projects if p.project_id == active), projects[0])
        self.project = project
        records = RecordRepository(project)
        self.repos = {
            "pc": PlayerCharacterRepository(project, records),
            "npc": NPCRepository(project, records),
            "monster": MonsterRepository(project, records),
            "location": LocationRepository(project, records),
            "shop": ShopRepository(project, records),
            "faction": FactionRepository(project, records),
            "materials": MaterialsRepository(project),
            "map": MapRepository(project, records),
            "display": MapDisplayRepository(project),
            "script": ScriptRepository(project, records),
            "tracker": StoryTrackerRepository(project),
            "clock": WorldClockRepository(project),
            "calendar": CalendarRepository(project),
            "table": TableRepository(project),
            "companion": CompanionRepository(project, records),
            "notes": NotesRepository(project),
            "assets": AssetRepository(project),
            "quest": QuestRepository(project, records),
            "item": ItemRepository(project, records),
            "trap": TrapRepository(project, records),
            "weapon": WeaponRepository(project, records),
            "armor": ArmorRepository(project, records),
        }
        self.status.set(f"{project.name}  —  {self.forge_root}")
        self._fill()
        self.draw_map()
        self.refresh_log()

    def _fill(self) -> None:
        self._maps = self.repos["map"].maps()
        self._map_names = [m.record.name for m in self._maps] or ["(no maps)"]
        self._rebuild_map_menus()
        self._scripts = self.repos["script"].scripts()
        self.script_combo["values"] = [s.record.name for s in self._scripts] or ["(no scripts)"]
        if self._scripts:
            saved = self._read_ui()
            sid = saved.get("script_id") or ""
            bid = saved.get("beat_id") or ""
            idx = 0
            for i, sc in enumerate(self._scripts):
                if sc.record.record_id == sid:
                    idx = i
                    break
            self.script_combo.current(idx)
            beats = list(self._scripts[idx].details.beats or [])
            self._beat_index = 0
            for i, beat in enumerate(beats):
                if beat.id == bid:
                    self._beat_index = i
                    break
            self.show_beat(0)
        self._tables = self.repos["table"].tables()
        self._refresh_stage_notes()
        self.table_combo["values"] = [f"{t.name} [{t.table_type}]" for t in self._tables] or ["(no tables)"]
        if self._tables:
            self.table_combo.current(0)
        self._refresh_clock()
        self._refill_add()
        self.add_kind.trace_add("write", lambda *_: self._refill_add())

    def _refresh_clock(self) -> None:
        try:
            clock = self.repos["clock"]
            calendar = self.repos["calendar"].load() if "calendar" in self.repos else None
            clock.calendar = calendar
            self.clock_var.set("Clock: " + clock.load().summary(calendar))
            self._refresh_rest()
        except Exception:
            self.clock_var.set("Clock: —")


    def _read_ui(self) -> dict:
        path = self._ui_state()
        if not path.exists():
            return {}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _save_ui_state(self) -> None:
        data = self._read_ui()
        if self.forge_root is not None:
            data["forge_root"] = str(self.forge_root)
        if hasattr(self, "live_clock"):
            data["live_clock"] = bool(self.live_clock.get())
        data["live_next_unix"] = float(getattr(self, "_live_next_unix", 0) or 0)
        scripts = getattr(self, "_scripts", [])
        try:
            sidx = self.script_combo.current()
        except Exception:
            sidx = -1
        if 0 <= sidx < len(scripts):
            data["script_id"] = scripts[sidx].record.record_id
            beats = list(scripts[sidx].details.beats or [])
            bidx = int(getattr(self, "_beat_index", 0) or 0)
            if 0 <= bidx < len(beats):
                data["beat_id"] = beats[bidx].id
        self._ui_state().write_text(json.dumps(data, indent=2), encoding="utf-8")


    def start_turn_timer(self, seconds: int) -> None:
        import time as _time
        self._turn_until = _time.time() + int(seconds)
        self.status.set(f"Turn timer {seconds // 60}:{seconds % 60:02d}")

    def cancel_turn_timer(self) -> None:
        self._turn_until = 0
        self.status.set("Turn timer off — countdown is live clock again")

    def _tick_countdown(self) -> None:
        import time as _time
        now = _time.time()
        remain = None
        mode = ""
        turn_until = float(getattr(self, "_turn_until", 0) or 0)
        if turn_until > now:
            remain = turn_until - now
            mode = "turn"
        elif turn_until and turn_until <= now:
            self._turn_until = 0
            self.countdown_var.set("0:00")
            self.status.set("Turn time is up")
            self.bell()
            remain = None
        if remain is None and hasattr(self, "live_clock") and self.live_clock.get():
            nxt = float(getattr(self, "_live_next_unix", 0) or 0)
            if nxt <= 0:
                nxt = float(self._read_ui().get("live_next_unix") or 0)
                self._live_next_unix = nxt
            if nxt > now:
                remain = nxt - now
                mode = "clock"
        if remain is None:
            if hasattr(self, "countdown_var"):
                self.countdown_var.set("--:--")
        else:
            total = int(remain)
            self.countdown_var.set(f"{total // 60}:{total % 60:02d}")
        self.after(1000, self._tick_countdown)

    def toggle_live_clock(self) -> None:
        job = getattr(self, "_live_job", None)
        if job is not None:
            try:
                self.after_cancel(job)
            except Exception:
                log_exception()
            self._live_job = None
        if not self.live_clock.get():
            self._save_ui_state()
            self.status.set("Live clock paused — game time kept")
            return
        import time as _time
        now = _time.time()
        nxt = float(self._read_ui().get("live_next_unix") or 0)
        if nxt <= 0:
            nxt = now + 15 * 60
        wait_ms = int(max(1, (nxt - now) * 1000))
        if nxt <= now:
            self._live_next_unix = now + 15 * 60
            self._save_ui_state()
            self._live_tick()
            return
        self._live_next_unix = nxt
        self._save_ui_state()
        self._live_job = self.after(wait_ms, self._live_tick)
        mins = max(1, int(wait_ms / 60000))
        self.status.set(f"Live clock on — next tick in about {mins} min")

    def _live_tick(self) -> None:
        self._live_job = None
        if not getattr(self, "live_clock", None) or not self.live_clock.get():
            return
        if self.project is None:
            return
        import time as _time
        clock = self.repos["clock"]
        before = clock.load()
        before_day = (before.year, before.month_index, before.day, before.festival)
        state = before
        total = state.hour * 60 + state.minute + 15
        days, rem = divmod(total, 24 * 60)
        state.hour = rem // 60
        state.minute = rem % 60
        for _ in range(max(0, days)):
            state = clock.advance_days(state, 1)
        after_day = (state.year, state.month_index, state.day, state.festival)
        if after_day != before_day or random.random() < 0.25:
            state = clock.roll_weather(state)
        clock.save(state)
        self._live_next_unix = _time.time() + 15 * 60
        self._save_ui_state()
        self._refresh_clock()
        self._tracker_log("Live clock +15m — " + state.summary())
        self._live_job = self.after(15 * 60 * 1000, self._live_tick)


    def _rest_path(self):
        proj = getattr(self, "project", None)
        if proj is None:
            return None
        return proj.root / "data" / "rest.json"

    def _load_rest(self) -> dict:
        path = self._rest_path()
        if path is None or not path.exists():
            return {}
        try:
            data = __import__("json").loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {}
        return data if isinstance(data, dict) else {}

    def _save_rest(self, data: dict) -> None:
        path = self._rest_path()
        if path is None:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(__import__("json").dumps(data, indent=2) + "\n", encoding="utf-8")

    def _party_names(self) -> list[str]:
        repo = self.repos.get("pc") if hasattr(self, "repos") else None
        if repo is None:
            return []
        try:
            return [x.record.name for x in repo.player_characters() if x.record.name]
        except Exception:
            return []

    def _rest_status(self) -> str:
        names = self._party_names()
        if not names:
            return "Rest: no party yet"
        clock = self.repos.get("clock")
        tick = int(getattr(clock.load(), "tick", 0) or 0) if clock else 0
        stamps = self._load_rest()
        waiting = []
        for name in names:
            last = int((stamps.get(name) or {}).get("long", -1000))
            left = 24 - (tick - last)
            if last >= 0 and left > 0:
                waiting.append(f"{name} {left}h")
        if waiting:
            return "Long rest waiting: " + ", ".join(waiting)
        return "Long rest available"

    def _refresh_rest(self) -> None:
        if hasattr(self, "rest_var"):
            self.rest_var.set(self._rest_status())

    def _show_beat_rest(self, beat) -> None:
        btn = getattr(self, "beat_rest_btn", None)
        if btn is None:
            return
        kind = (getattr(beat, "rest", "") or "").lower()
        if "long" in kind:
            btn.configure(text="Go to sleep (+8 hours)", command=lambda: self._sleep_rest("long"))
            btn.pack(anchor="w", pady=(2, 0))
        elif "short" in kind:
            btn.configure(text="Take short rest (+1 hour)", command=lambda: self._sleep_rest("short"))
            btn.pack(anchor="w", pady=(2, 0))
        else:
            btn.pack_forget()

    def take_beat_rest(self) -> None:
        self.offer_rest("short")



    def _beat_time_path(self):
        proj = getattr(self, "project", None)
        if proj is None:
            return None
        return proj.root / "data" / "beat_time.json"

    def _load_beat_time(self) -> dict:
        path = self._beat_time_path()
        if path is None or not path.exists():
            return {"done": []}
        try:
            data = __import__("json").loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {"done": []}
        if not isinstance(data, dict):
            return {"done": []}
        data.setdefault("done", [])
        return data

    def _save_beat_time(self, data: dict) -> None:
        path = self._beat_time_path()
        if path is None:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(__import__("json").dumps(data, indent=2) + "\n", encoding="utf-8")

    def _show_beat_advance(self, beat) -> None:
        if not hasattr(self, "beat_advance_var"):
            return
        rest = (getattr(beat, "rest", "") or "").lower()
        if "long" in rest:
            self.beat_advance_label.configure(text="This beat: Long rest · 8 hours")
            self.beat_advance_entry.pack_forget()
            self.beat_advance_hint.pack_forget()
            self.beat_advance_var.set("")
            return
        if "short" in rest:
            self.beat_advance_label.configure(text="This beat: Short rest · 1 hour")
            self.beat_advance_entry.pack_forget()
            self.beat_advance_hint.pack_forget()
            self.beat_advance_var.set("")
            return
        self.beat_advance_label.configure(text="This beat")
        self.beat_advance_entry.pack(side="left", padx=4)
        self.beat_advance_hint.pack(side="left")
        minutes = int(getattr(beat, "advance_minutes", 0) or 0)
        override = getattr(self, "_beat_time_override", {}).get(beat.id)
        shown = override if override is not None else minutes
        self.beat_advance_var.set(str(shown) if shown else "")

    def _beat_minutes(self, beat) -> int:
        typed = self.beat_advance_var.get().strip() if hasattr(self, "beat_advance_var") else ""
        if typed:
            try:
                return max(0, int(typed))
            except ValueError:
                return 0
        return max(0, int(getattr(beat, "advance_minutes", 0) or 0))

    def _mark_rest_took_time(self) -> None:
        scripts = getattr(self, "_scripts", [])
        idx = self.script_combo.current() if hasattr(self, "script_combo") else -1
        if idx < 0 or idx >= len(scripts):
            return
        beats = list(scripts[idx].details.beats or [])
        index = max(0, min(len(beats) - 1, getattr(self, "_beat_index", 0)))
        if not beats:
            return
        data = self._load_beat_time()
        done = set(data.get("done") or [])
        done.add(beats[index].id)
        data["done"] = sorted(done)
        self._save_beat_time(data)

    def clear_beat_times(self) -> None:
        self._save_beat_time({"done": [], "rested": []})
        self.status.set("Beat times cleared. The next pass will move the clock again.")


    def _sleep_rest(self, kind: str) -> None:
        scripts = getattr(self, "_scripts", [])
        idx = self.script_combo.current() if hasattr(self, "script_combo") else -1
        beats = list(scripts[idx].details.beats or []) if 0 <= idx < len(scripts) else []
        index = max(0, min(len(beats) - 1, getattr(self, "_beat_index", 0))) if beats else 0
        beat = beats[index] if beats else None
        title = "Long rest" if kind == "long" else "Short rest"
        if not self._apply_rest_time(kind, title):
            return
        if beat is not None:
            data = self._load_beat_time()
            rested = set(data.get("rested") or [])
            rested.add(beat.id)
            data["rested"] = sorted(rested)
            self._save_beat_time(data)
        self.status.set(f"{title} taken. The clock moved. Next will not add it again.")

    def _apply_beat_time(self, beat) -> None:
        if beat is None:
            return
        data = self._load_beat_time()
        done = set(data.get("done") or [])
        rested = set(data.get("rested") or [])
        rest = (getattr(beat, "rest", "") or "").lower()
        self.status.set(f"{beat.title}: advance is {rest or 'time'}")
        if "long" in rest or "short" in rest:
            if beat.id in rested:
                return
            kind = "long" if "long" in rest else "short"
            if self._apply_rest_time(kind, beat.title):
                rested.add(beat.id)
                done.add(beat.id)
                data["rested"] = sorted(rested)
                data["done"] = sorted(done)
                self._save_beat_time(data)
                self.status.set(f"{beat.title}: went to sleep, clock +{'8' if kind == 'long' else '1'} hours")
            return
        if beat.id in done:
            self.status.set(f"{beat.title}: time already added")
            return
        minutes = int(getattr(beat, "_taken_minutes", 0) or 0) or self._beat_minutes(beat)
        if not minutes:
            self.status.set(f"{beat.title}: no time set")
            return
        clock = self.repos.get("clock") if hasattr(self, "repos") else None
        if clock is None or not hasattr(clock, "advance_minutes"):
            self.status.set("Clock cannot advance by minutes. Copy the core folder too.")
            return
        state = clock.advance_minutes(clock.load(), minutes)
        clock.save(state)
        done.add(beat.id)
        data["done"] = sorted(done)
        self._save_beat_time(data)
        self._refresh_clock()
        label = f"{minutes // 60}h" if minutes % 60 == 0 else f"{minutes} min"
        self.status.set(f"{beat.title}: clock +{label}")
        self._tracker_log(f"Beat time +{label} → {state.summary()}")

    def _apply_rest_time(self, kind: str, title: str) -> None:
        clock_repo = self.repos.get("clock") if hasattr(self, "repos") else None
        if clock_repo is None:
            return False
        names = self._party_names()
        state = clock_repo.load()
        tick = int(getattr(state, "tick", 0) or 0)
        stamps = self._load_rest()
        if kind == "short":
            state = clock_repo.advance_hours(state, 1)
            clock_repo.save(state)
            for name in names:
                stamps.setdefault(name, {})["short"] = int(getattr(state, "tick", tick + 1))
            self._save_rest(stamps)
            self._refresh_clock()
            self._refresh_rest()
            self.status.set(f"{title}: short rest, clock +1 hour")
            self._tracker_log(f"Short rest → {state.summary()}")
            return True
        ready, waiting = [], []
        for name in names:
            last = int((stamps.get(name) or {}).get("long", -1000))
            left = 24 - (tick - last)
            if last >= 0 and left > 0:
                waiting.append(f"{name} {left}h")
            else:
                ready.append(name)
        state = clock_repo.advance_hours(state, 8)
        if names and not ready:
            clock_repo.save(state)
            self._refresh_clock()
            self.status.set(f"{title}: clock +8 hours. No long rest yet. " + ", ".join(waiting))
            self._tracker_log(f"Long rest time only → {state.summary()}")
            return True
        clock_repo.save(state)
        now = tick
        for name in ready:
            stamps.setdefault(name, {})["long"] = now
        self._save_rest(stamps)
        self._refresh_clock()
        self._refresh_rest()
        skipped = f" Skipped: {', '.join(waiting)}." if waiting else ""
        self.status.set(f"{title}: long rest, clock +8 hours.{skipped}")
        self._tracker_log(f"Long rest → {state.summary()}")
        self.status.set(f"{title}: long rest, clock +8 hours.{skipped}")
        return True


    def open_calendar_settings(self) -> None:
        repo = self.repos.get("calendar") if hasattr(self, "repos") else None
        clock = self.repos.get("clock") if hasattr(self, "repos") else None
        if repo is None or clock is None:
            self.status.set("Open a project first.")
            return
        cal = repo.load()
        state = clock.load()
        win = tk.Toplevel(self)
        win.title("Calendar settings")
        win.geometry("640x560")
        name = tk.StringVar(value=cal.name)
        era = tk.StringVar(value=cal.era)
        year = tk.StringVar(value=str(state.year))
        day = tk.StringVar(value=str(state.day or 1))
        hour = tk.StringVar(value=str(state.hour))
        minute = tk.StringVar(value=str(state.minute))
        months = tk.StringVar(value="\n".join(
            f"{m.get('name','')}|{m.get('days',30)}|{m.get('season','')}" for m in cal.months
        ))
        week = tk.StringVar(value=", ".join(cal.weekdays))
        holidays = tk.StringVar(value="\n".join(
            f"{h.get('name','')}|after|{h.get('after_month','')}" if "after_month" in h else f"{h.get('name','')}|{h.get('month','')}|{h.get('day','')}"
            for h in cal.holidays
        ))
        frm = ttk.Frame(win, padding=10)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text="Name").grid(row=0, column=0, sticky="w")
        ttk.Entry(frm, textvariable=name, width=28).grid(row=0, column=1, sticky="w")
        ttk.Label(frm, text="Era").grid(row=0, column=2, sticky="w", padx=(8, 0))
        ttk.Entry(frm, textvariable=era, width=8).grid(row=0, column=3, sticky="w")
        ttk.Button(frm, text="Use Harptos", command=lambda: self._fill_harptos(name, era, month_box, week, hol_box)).grid(row=0, column=4, padx=8)
        ttk.Label(frm, text="Year").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Entry(frm, textvariable=year, width=8).grid(row=1, column=1, sticky="w")
        ttk.Label(frm, text="Day").grid(row=1, column=2, sticky="w")
        ttk.Entry(frm, textvariable=day, width=6).grid(row=1, column=3, sticky="w")
        ttk.Label(frm, text="Hour 0-23").grid(row=2, column=0, sticky="w")
        ttk.Entry(frm, textvariable=hour, width=6).grid(row=2, column=1, sticky="w")
        ttk.Label(frm, text="Minute").grid(row=2, column=2, sticky="w")
        ttk.Entry(frm, textvariable=minute, width=6).grid(row=2, column=3, sticky="w")
        ttk.Label(frm, text="Months: name|days|season").grid(row=3, column=0, columnspan=5, sticky="w", pady=(8, 0))
        month_box = tk.Text(frm, height=8, width=70)
        month_box.grid(row=4, column=0, columnspan=5, sticky="ew")
        month_box.insert("1.0", months.get())
        ttk.Label(frm, text="Weekdays, comma separated").grid(row=5, column=0, columnspan=5, sticky="w", pady=(8, 0))
        ttk.Entry(frm, textvariable=week, width=70).grid(row=6, column=0, columnspan=5, sticky="ew")
        ttk.Label(frm, text="Holidays: name|after|month index   or   name|month|day").grid(row=7, column=0, columnspan=5, sticky="w", pady=(8, 0))
        hol_box = tk.Text(frm, height=5, width=70)
        hol_box.grid(row=8, column=0, columnspan=5, sticky="ew")
        hol_box.insert("1.0", holidays.get())
        month_pick = tk.StringVar(value=cal.month_names()[state.month_index] if cal.months else "")
        ttk.Label(frm, text="Month").grid(row=9, column=0, sticky="w", pady=6)
        month_menu = ttk.Combobox(frm, textvariable=month_pick, values=cal.month_names(), width=18)
        month_menu.grid(row=9, column=1, sticky="w")

        def save() -> None:
            parsed = self._parse_calendar(name.get(), era.get(), month_box.get("1.0", "end"), week.get(), hol_box.get("1.0", "end"))
            repo.save(parsed)
            clock.calendar = parsed
            names = parsed.month_names()
            try:
                state.year = int(year.get() or state.year)
                state.day = max(1, int(day.get() or 1))
                state.hour = int(hour.get() or 0) % 24
                state.minute = int(minute.get() or 0) % 60
            except ValueError:
                pass
            if month_pick.get() in names:
                state.month_index = names.index(month_pick.get())
            state.festival = ""
            fresh = clock.load()
            state.tick = int(getattr(fresh, "tick", 0) or 0)
            parsed.start = {
                "year": state.year,
                "month_index": state.month_index,
                "day": state.day,
                "hour": state.hour,
                "minute": state.minute,
            }
            clock.save(state)
            self._refresh_clock()
            self.status.set(f"Calendar saved for this campaign. {state.summary(parsed)}")
            win.destroy()

        ttk.Button(frm, text="Save for this campaign", command=save).grid(row=10, column=4, sticky="e", pady=8)
        ttk.Label(frm, text="Saving changes the date only. It does not clear rests or add hours.").grid(row=10, column=0, columnspan=4, sticky="w")

    def _fill_harptos(self, name, era, month_box, week, hol_box) -> None:
        data = harptos()
        name.set(data["name"])
        era.set(data["era"])
        month_box.delete("1.0", "end")
        month_box.insert("1.0", "\n".join(f"{m['name']}|{m['days']}|{m['season']}" for m in data["months"]))
        week.set(", ".join(data["weekdays"]))
        hol_box.delete("1.0", "end")
        hol_box.insert("1.0", "\n".join(f"{h['name']}|after|{h['after_month']}" for h in data["holidays"]))

    def _parse_calendar(self, name, era, months_text, week_text, holiday_text):
        months = []
        for line in months_text.splitlines():
            line = line.strip()
            if not line or "|" not in line:
                continue
            parts = [p.strip() for p in line.split("|")]
            months.append({"name": parts[0], "days": int(parts[1] or 30), "season": parts[2] if len(parts) > 2 else ""})
        holidays = []
        for line in holiday_text.splitlines():
            line = line.strip()
            if not line or "|" not in line:
                continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) >= 3 and parts[1] == "after":
                holidays.append({"name": parts[0], "after_month": int(parts[2] or 0)})
            elif len(parts) >= 3:
                holidays.append({"name": parts[0], "month": parts[1], "day": int(parts[2] or 1)})
        weekdays = [p.strip() for p in week_text.split(",") if p.strip()]
        if not months:
            return CampaignCalendar.from_dict(harptos())
        return CampaignCalendar(name=name.strip() or "Calendar", era=era.strip(), weekdays=weekdays, months=months, holidays=holidays)


    def _calendar_start(self, cal) -> dict:
        start = getattr(cal, "start", None) or {}
        names = cal.month_names() if cal else []
        month_index = int(start.get("month_index", 8 if names else 0) or 0)
        if names:
            month_index = month_index % len(names)
        year = int(start.get("year", 1372) or 1372)
        day = int(start.get("day", 1) or 1)
        hour = int(start.get("hour", 9) or 9)
        minute = int(start.get("minute", 0) or 0)
        month = names[month_index] if names else "Eleint"
        era = f" {cal.era}" if cal and cal.era else ""
        return {
            "year": year, "month_index": month_index, "day": day,
            "hour": hour, "minute": minute,
            "label": f"{day} {month} {year}{era}, {hour:02d}:{minute:02d}",
        }

    def reset_clock(self) -> None:
        clock = self.repos.get("clock") if hasattr(self, "repos") else None
        if clock is None:
            self.status.set("Open a project first.")
            return
        cal = self.repos["calendar"].load() if "calendar" in self.repos else None
        start = self._calendar_start(cal)
        label = start["label"]
        if not messagebox.askyesno("Reset clock", f"Set the clock back to {label}, and clear rest stamps and beat times?", parent=self):
            return
        from core.world_clock import WorldClockState
        state = WorldClockState(
            year=start["year"], month_index=start["month_index"], day=start["day"],
            hour=start["hour"], minute=start["minute"],
        )
        clock.calendar = cal
        clock.save(state)
        self._save_rest({})
        self._save_beat_time({"done": [], "rested": []})
        self._refresh_clock()
        self.status.set(f"Clock reset to {label}. Rests and beat times cleared.")
        self._tracker_log("Clock reset")

    def offer_rest(self, kind: str) -> None:
        kind = "long" if kind == "long" else "short"
        names = self._party_names()
        if not names:
            self.status.set("Add player characters before resting.")
            return
        clock_repo = self.repos.get("clock")
        if clock_repo is None:
            return
        state = clock_repo.load()
        tick = int(getattr(state, "tick", 0) or 0)
        stamps = self._load_rest()
        if kind == "short":
            if not messagebox.askyesno("Short rest", "The party takes a short rest. Advance the clock 1 hour?", parent=self):
                return
            state = clock_repo.advance_hours(state, 1)
            clock_repo.save(state)
            for name in names:
                row = stamps.setdefault(name, {})
                row["short"] = int(getattr(state, "tick", tick + 1))
            self._save_rest(stamps)
            self._refresh_clock()
            self._refresh_rest()
            self._tracker_log(f"Short rest → {state.summary()}")
            self.status.set("Short rest taken. Clock +1 hour.")
            self._mark_rest_took_time()
            return
        ready, waiting = [], []
        for name in names:
            last = int((stamps.get(name) or {}).get("long", -1000))
            left = 24 - (tick - last)
            if last >= 0 and left > 0:
                waiting.append(f"{name}: {left}h left")
            else:
                ready.append(name)
        if not ready:
            messagebox.showinfo("Long rest", "No one can take a long rest yet.\n" + "\n".join(waiting), parent=self)
            self._refresh_rest()
            return
        note = "Advance the clock 8 hours?"
        if waiting:
            note += "\n\nNot yet: " + ", ".join(waiting)
        if not messagebox.askyesno("Long rest", f"{', '.join(ready)} can take a long rest. {note}", parent=self):
            return
        state = clock_repo.advance_hours(state, 8)
        clock_repo.save(state)
        now = int(getattr(state, "tick", tick + 8))
        for name in ready:
            row = stamps.setdefault(name, {})
            row["long"] = now
        self._save_rest(stamps)
        self._refresh_clock()
        self._refresh_rest()
        skipped = f" Skipped: {', '.join(n.split(':')[0] for n in waiting)}." if waiting else ""
        self._tracker_log(f"Long rest → {state.summary()}")
        self.status.set("Long rest taken. Clock +8 hours." + skipped)
        self._mark_rest_took_time()

    def advance_clock(self, hours: int) -> None:
        clock = self.repos["clock"]
        state = clock.advance_hours(clock.load(), hours)
        clock.save(state)
        self._refresh_clock()
        self._tracker_log(f"Time +{hours}h → {state.summary()}")

    def _refill_add(self) -> None:
        kind = self.add_kind.get()
        if kind == "PC":
            names = [x.record.name for x in self.repos["pc"].player_characters()]
        elif kind == "NPC":
            names = [x.record.name for x in self.repos["npc"].npcs()]
        elif kind == "Companion":
            names = [x.record.name for x in self.repos["companion"].companions()] if "companion" in self.repos else []
        else:
            names = [x.record.name for x in self.repos["monster"].monsters()]
        q = (self.add_search.get() if hasattr(self, "add_search") else "").strip().lower()
        if q:
            names = [n for n in names if q in n.lower()]
        self.add_combo["values"] = names
        if names:
            self.add_combo.current(0)


    def _rebuild_map_menus(self) -> None:
        names = getattr(self, "_map_names", []) or ["(no maps)"]
        dm = self._dm_name.get() if hasattr(self, "_dm_name") else ""
        tv = self._tv_name.get() if hasattr(self, "_tv_name") else ""
        if dm not in names:
            dm = names[0]
        if tv not in names:
            tv = names[1] if len(names) > 1 else names[0]
        self._dm_name.set(dm)
        self._tv_name.set(tv)
        if hasattr(self, "_dm_menu"):
            self._dm_menu["values"] = names
        if hasattr(self, "_tv_menu"):
            self._tv_menu["values"] = names

    def _on_dm_picked(self) -> None:
        self._reload_map_walls()
        self.draw_map()

    def _on_tv_picked(self) -> None:
        self.draw_map()

    def _reload_map_walls(self) -> None:
        m = self._selected_map()
        if m is None:
            return
        settings = self.repos["display"].reload(m.record.record_id)
        count = len(getattr(settings, "walls", []) or [])
        self.status.set(f"{m.record.name}: {count} saved wall lines loaded")

    def _pick_named_map(self, var, name: str) -> None:
        var.set(name)
        self.draw_map()

    def _map_by_name(self, name: str):
        for m in getattr(self, "_maps", []):
            if m.record.name == name:
                return m
        maps = getattr(self, "_maps", [])
        return maps[0] if maps else None

    def _selected_map(self):
        return self._map_by_name(self._dm_name.get() if hasattr(self, "_dm_name") else "")

    def _selected_player_map(self):
        return self._map_by_name(self._tv_name.get() if hasattr(self, "_tv_name") else "")

    def _settings_for(self, m):
        if m is None:
            return None
        return self.repos["display"].get(m.record.record_id)

    def _settings(self):
        return self._settings_for(self._selected_map())

    def _resolve_image(self, m, settings, prefer="dm"):
        if settings is not None:
            rels = (settings.dm_image, settings.player_image) if prefer == "dm" else (settings.player_image, settings.dm_image)
            for rel in rels:
                if not rel:
                    continue
                path = self.repos["display"].absolute(rel)
                if path and Path(path).is_file():
                    return Path(path)
        if m is None:
            return None
        for att in self.repos["assets"].attachments_for(m.record.record_id):
            path = self.repos["assets"].absolute_path(att.relative_path)
            if path.is_file():
                return path
        return None


    def set_vision(self, cells: int) -> None:
        self._vision_cells = max(0, int(cells))
        if self._vision_cells:
            self.status.set(f"Token vision {self._vision_cells * 5} ft ({self._vision_cells} squares)")
        else:
            self.status.set("Token vision off")
        self.draw_map()

    def ask_vision(self) -> None:
        raw = simpledialog.askinteger(
            "Token vision",
            "How many 5-ft squares in each direction?",
            initialvalue=max(1, int(getattr(self, "_vision_cells", 6) or 6)),
            minvalue=1, maxvalue=48, parent=self,
        )
        if raw:
            self.set_vision(int(raw))

    def _apply_fog(self, img, settings, player: bool = False, tokens=None, path=None, vision_cells: int = 0):
        from PIL import ImageEnhance, Image as PILImage, ImageDraw
        if player:
            dark = PILImage.new("RGB", img.size, (0, 0, 0))
        else:
            dark = ImageEnhance.Brightness(img).enhance(0.40)
        out = dark.copy()
        iw, ih = img.size
        mask = PILImage.new("L", img.size, 0)
        draw = ImageDraw.Draw(mask)
        if settings is not None:
            for rect in list(settings.revealed_regions or []):
                x = int(float(rect.get("x", 0)) * iw)
                y = int(float(rect.get("y", 0)) * ih)
                rw = max(8, int(float(rect.get("w", 0)) * iw))
                rh = max(8, int(float(rect.get("h", 0)) * ih))
                draw.rectangle((x, y, x + rw, y + rh), fill=255)
            mask_rel = getattr(settings, "fog_mask", "") or ""
            if mask_rel:
                mask_path = self.repos["display"].absolute(mask_rel)
                if mask_path and Path(mask_path).is_file():
                    try:
                        painted = Image.open(mask_path).convert("L").resize((iw, ih))
                        mask = PILImage.composite(painted, mask, painted)
                    except Exception:
                        log_exception()
        cells = int(vision_cells or 0)
        if cells and tokens:
            cell = max(8, self._cell_px(iw, path, settings))
            rad = cells * cell
            walls = list(getattr(settings, "walls", []) or [])
            viewers = [
                tok for tok in tokens
                if str(tok.get("kind") or "").lower() in ("pc", "companion", "player")
            ]
            if not viewers:
                viewers = [
                    tok for tok in tokens
                    if str(tok.get("kind") or "").lower() not in ("monster", "npc", "creature")
                ]
            for tok in viewers:
                tx = float(tok.get("x") or 0) * iw
                ty = float(tok.get("y") or 0) * ih
                draw.ellipse((tx - rad, ty - rad, tx + rad, ty + rad), fill=255)
                for wall in walls:
                    if wall.get("door") and wall.get("open"):
                        continue
                    shadow = self._wall_shadow(tx, ty, wall, iw, ih, rad * 3)
                    if shadow:
                        draw.polygon(shadow, fill=0)
        out = Image.composite(img, out, mask)
        return out


    def toggle_grid(self) -> None:
        m = self._selected_map()
        if m is None:
            return
        settings = self.repos["display"].get(m.record.record_id)
        settings.grid_enabled = not bool(settings.grid_enabled)
        self.repos["display"].save(settings)
        # keep player map grid in sync if different record
        ply = self._selected_player_map()
        if ply is not None and ply.record.record_id != m.record.record_id:
            ps = self.repos["display"].get(ply.record.record_id)
            ps.grid_enabled = settings.grid_enabled
            ps.grid_size_px = settings.grid_size_px
            self.repos["display"].save(ps)
        self.status.set("Grid on" if settings.grid_enabled else "Grid off")
        self.draw_map()

    def ask_grid_size(self) -> None:
        cur = 50
        m = self._selected_map() or self._selected_player_map()
        if m is not None:
            cur = int(getattr(self.repos["display"].get(m.record.record_id), "grid_size_px", 50) or 50)
        raw = simpledialog.askinteger("Grid size", "Pixels per square on the original map image:",
                                      initialvalue=cur, minvalue=8, maxvalue=512, parent=self)
        if raw:
            self.set_grid_size(int(raw))

    def nudge_grid(self, dx: int, dy: int, reset: bool = False) -> None:
        for m in (self._selected_map(), self._selected_player_map()):
            if m is None:
                continue
            settings = self.repos["display"].get(m.record.record_id)
            if reset:
                settings.grid_offset_x = 0
                settings.grid_offset_y = 0
            else:
                settings.grid_offset_x = int(getattr(settings, "grid_offset_x", 0) or 0) + int(dx)
                settings.grid_offset_y = int(getattr(settings, "grid_offset_y", 0) or 0) + int(dy)
            settings.grid_enabled = True
            self.repos["display"].save(settings)
        self.draw_map()
        self.status.set("Grid offset reset" if reset else f"Grid offset {dx:+d},{dy:+d}")

    def set_grid_size(self, px: int) -> None:
        for m in (self._selected_map(), self._selected_player_map()):
            if m is None:
                continue
            settings = self.repos["display"].get(m.record.record_id)
            settings.grid_size_px = int(px)
            settings.grid_enabled = True
            self.repos["display"].save(settings)
        self.status.set(f"Grid cell {px}px")
        self.draw_map()

    def set_grid_style(self, strong: bool) -> None:
        for m in (self._selected_map(), self._selected_player_map()):
            if m is None:
                continue
            settings = self.repos["display"].get(m.record.record_id)
            settings.grid_strong = bool(strong)
            settings.grid_enabled = True
            self.repos["display"].save(settings)
        self.status.set("Grid strong" if strong else "Grid soft")
        self.draw_map()

    def set_grid_color(self, color: str) -> None:
        for m in (self._selected_map(), self._selected_player_map()):
            if m is None:
                continue
            settings = self.repos["display"].get(m.record.record_id)
            settings.grid_color = color
            settings.grid_enabled = True
            self.repos["display"].save(settings)
        self.status.set(f"Grid {color}")
        self.draw_map()

    def _draw_grid(self, canvas, origin, iw, ih, settings, path) -> None:
        try:
            orig_w, orig_h = Image.open(path).size
        except Exception:
            orig_w, orig_h = iw, ih
        cell_src = max(8, int(getattr(settings, "grid_size_px", 50) or 50))
        cell = cell_src * (iw / max(orig_w, 1))
        if cell < 6:
            return
        ox, oy = origin
        color = getattr(settings, "grid_color", None) or "#e6c35c"
        width = 3 if getattr(settings, "grid_strong", False) else 1
        offx = int(getattr(settings, "grid_offset_x", 0) or 0) * (iw / max(orig_w, 1))
        offy = int(getattr(settings, "grid_offset_y", 0) or 0) * (ih / max(orig_h, 1))
        x = ox + offx
        while x <= ox + iw + 1:
            canvas.create_line(x, oy, x, oy + ih, fill=color, width=width)
            x += cell
        y = oy + offy
        while y <= oy + ih + 1:
            canvas.create_line(ox, y, ox + iw, y, fill=color, width=width)
            y += cell

    def _set_fog_enabled(self, on: bool) -> None:
        on = bool(on)
        if hasattr(self, "fog_on"):
            self.fog_on.set(on)
        for m in (self._selected_map(), self._selected_player_map()):
            if m is None:
                continue
            settings = self.repos["display"].get(m.record.record_id)
            settings.fog_enabled = on
            self.repos["display"].save(settings)
        self.status.set("Fog on" if on else "Fog off — full map")
        self.draw_map()

    def toggle_fog(self) -> None:
        current = False
        ply = self._selected_player_map() or self._selected_map()
        if ply is not None:
            current = bool(self.repos["display"].get(ply.record.record_id).fog_enabled)
        self._set_fog_enabled(not current)

    def fog_off(self) -> None:
        self._set_fog_enabled(False)

    def cover_all_fog(self) -> None:
        for m in (self._selected_map(), self._selected_player_map()):
            if m is None:
                continue
            self.repos["display"].clear_reveals(m.record.record_id)
        self._set_fog_enabled(True)


    def _cell_px(self, iw: int, path, settings) -> int:
        src = max(16, int(getattr(settings, "grid_size_px", 50) or 50)) if settings else 50
        try:
            orig_w = Image.open(path).size[0] if path else iw
        except Exception:
            orig_w = iw
        return max(12, int(src * (iw / max(orig_w, 1))))

    def _token_image_path(self, tok) -> Path | None:
        if self.project is None:
            return None
        assets = self.repos.get("assets")
        if assets is None:
            return None
        rid = str(tok.get("record_id") or tok.get("linked_record_id") or "")
        paths = []
        if rid:
            for att in assets.attachments_for(rid):
                paths.append(assets.absolute_path(att.relative_path))
        if not paths:
            name = (tok.get("name") or "").strip().lower()
            if name:
                for listing in (
                    self.repos["monster"].monsters(),
                    self.repos["npc"].npcs(),
                    self.repos["pc"].player_characters(),
                ):
                    for entry in listing:
                        if entry.record.name.strip().lower() == name:
                            for att in assets.attachments_for(entry.record.record_id):
                                paths.append(assets.absolute_path(att.relative_path))
                            break
        for path in paths:
            if path and Path(path).is_file() and Path(path).suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}:
                return Path(path)
        return None

    def _token_photo(self, path: Path, size: int = 28):
        key = f"{path}:{size}"
        cache = getattr(self, "_token_photos", {})
        if key in cache:
            return cache[key]
        if not HAS_PIL:
            return None
        img = Image.open(path).convert("RGBA")
        img.thumbnail((size, size))
        # circular mask
        mask = Image.new("L", img.size, 0)
        from PIL import ImageDraw
        ImageDraw.Draw(mask).ellipse((0, 0, img.size[0] - 1, img.size[1] - 1), fill=255)
        out = Image.new("RGBA", img.size, (0, 0, 0, 0))
        out.paste(img, (0, 0), mask)
        photo = ImageTk.PhotoImage(out)
        cache[key] = photo
        self._token_photos = cache
        return photo

    def _paint_map(self, canvas, photo_attr, m, prefer: str, *, tokens=True, fog=True, label_hp=True):
        canvas.delete("all")
        if m is None:
            canvas.create_text(12, 12, anchor="nw", fill=FG, text="No map")
            return (1, 1)
        settings = self._settings_for(m)
        path = self._resolve_image(m, settings, prefer)
        w = max(canvas.winfo_width(), 40)
        h = max(canvas.winfo_height(), 40)
        iw, ih = w, h
        origin = (0, 0)
        if HAS_PIL and path:
            raw = Image.open(path).convert("RGB")
            rw, rh = raw.size
            zoom = float(getattr(self, "_zoom", 1.0) or 1.0)
            cover = max(w / max(rw, 1), h / max(rh, 1)) * zoom
            tw, th = max(1, int(rw * cover)), max(1, int(rh * cover))
            cache_key = (str(path), tw, th)
            cache = getattr(self, "_bmp_cache", None)
            if cache is None:
                cache = {}
                self._bmp_cache = cache
            img = cache.get(cache_key)
            if img is None:
                img = raw.resize((tw, th), Image.BILINEAR)
                cache[cache_key] = img
                if len(cache) > 6:
                    cache.pop(next(iter(cache)))
            vision = int(getattr(self, "_vision_cells", 0) or 0)
            fog_on = bool(fog and settings is not None and settings.fog_enabled)
            if fog_on or vision:
                toks = list(getattr(settings, "tokens", []) or [])
                if prefer == "player" and not toks:
                    dm = self._selected_map()
                    if dm is not None:
                        toks = list(getattr(self._settings_for(dm), "tokens", []) or [])
                use_vision = vision if prefer == "player" else 0
                wall_settings = settings
                if prefer == "player" and not list(getattr(settings, "walls", []) or []):
                    dm = self._selected_map()
                    if dm is not None:
                        wall_settings = self._settings_for(dm) or settings
                img = self._apply_fog(
                    img, wall_settings, player=(prefer == "player"),
                    tokens=toks, path=path, vision_cells=use_vision,
                )
            iw, ih = img.size
            origin = (
                int((w - tw) / 2 + float(self._pan[0]) * tw),
                int((h - th) / 2 + float(self._pan[1]) * th),
            )
            photo = ImageTk.PhotoImage(img)
            setattr(self, photo_attr, photo)
            canvas.create_image(origin[0], origin[1], anchor="nw", image=photo)
            if canvas is getattr(self, "canvas", None):
                self._img_origin = origin
                self._img_disp = (iw, ih)
        else:
            which = "player/TV" if prefer == "player" else "DM"
            canvas.create_text(
                12, 12, anchor="nw", fill=FG,
                text=f"{m.record.name}\nNo {which} image. In Library → Maps attach an image.",
            )
            iw, ih = w, h
        if settings and getattr(settings, "grid_enabled", False) and HAS_PIL and path:
            self._draw_grid(canvas, origin, iw, ih, settings, path)
        if getattr(settings, "walls", None) and label_hp:
            ox, oy = origin
            for wall in settings.walls:
                x1 = ox + float(wall.get("x1") or 0) * iw
                y1 = oy + float(wall.get("y1") or 0) * ih
                x2 = ox + float(wall.get("x2") or 0) * iw
                y2 = oy + float(wall.get("y2") or 0) * ih
                if wall.get("door") and wall.get("open"):
                    color, dash = "#3dba6a", (6, 4)
                elif wall.get("door"):
                    color, dash = "#e0b15a", ()
                else:
                    color, dash = "#d04545", ()
                if dash:
                    canvas.create_line(x1, y1, x2, y2, fill=color, width=3, dash=dash)
                else:
                    canvas.create_line(x1, y1, x2, y2, fill=color, width=3)
        if tokens:
            ox, oy = origin
            cell = self._cell_px(iw, path, settings)
            self._token_hit_r = cell / 2
            shown = list(getattr(settings, "tokens", []) or [])
            if prefer == "player" and not shown:
                dm = self._selected_map()
                if dm is not None:
                    shown = list(getattr(self._settings_for(dm), "tokens", []) or [])
            for tok in shown:
                if prefer == "player" and not self._token_in_view(tok, shown, settings):
                    continue
                x = ox + float(tok.get("x") or 0) * iw
                y = oy + float(tok.get("y") or 0) * ih
                icon = self._token_image_path(tok)
                photo = self._token_photo(icon, size=cell) if icon else None
                if photo is not None:
                    canvas.create_image(x, y, image=photo)
                else:
                    r = cell / 2
                    canvas.create_oval(x - r, y - r, x + r, y + r, fill=tok.get("color") or GOLD, outline="white")
                label = tok.get("name") or "?"
                if label_hp and tok.get("hp"):
                    label += f" {tok.get('hp')}"
                canvas.create_text(x + 12, y, anchor="w", fill="white", text=label)
        return (iw, ih)

    def _safe_draw(self) -> None:
        try:
            self.draw_map()
        except Exception:
            log_exception()

    def draw_map(self, tv: bool = True) -> None:
        dm = self._selected_map()
        if dm is not None and not getattr(self, "_walls_noted", False):
            self._walls_noted = True
            count = len(getattr(self._settings_for(dm), "walls", []) or [])
            if count:
                self.status.set(f"{dm.record.name}: {count} saved wall lines")
        ply = self._selected_player_map()
        st = self._settings_for(ply)
        if hasattr(self, "fog_on") and st is not None:
            self.fog_on.set(bool(st.fog_enabled))
        self._img_size = self._paint_map(self.canvas, "_photo", dm, "dm", tokens=True, fog=True, label_hp=True)
        self._tokens = list(getattr(self._settings_for(dm), "tokens", []) or []) if dm else []
        if self._tv is None or not self._tv.winfo_exists():
            return
        if tv:
            self._tv_pending = False
            self._draw_tv()
        elif not getattr(self, "_tv_pending", False):
            self._tv_pending = True
            self.after(50, self._flush_tv)

    def _flush_tv(self) -> None:
        self._tv_pending = False
        if self._tv is not None and self._tv.winfo_exists():
            self._draw_tv()

    def _map_coords(self, ev):
        ox, oy = getattr(self, "_img_origin", (0, 0))
        iw, ih = getattr(self, "_img_disp", self._img_size)
        return (
            max(0.0, min(1.0, (ev.x - ox) / max(iw, 1))),
            max(0.0, min(1.0, (ev.y - oy) / max(ih, 1))),
        )

    def _hit_token(self, ev):
        ox, oy = getattr(self, "_img_origin", (0, 0))
        iw, ih = getattr(self, "_img_disp", self._img_size)
        for tok in reversed(getattr(self, "_tokens", [])):
            x = ox + float(tok.get("x") or 0) * iw
            y = oy + float(tok.get("y") or 0) * ih
            rad = float(getattr(self, "_token_hit_r", 14) or 14)
            if (ev.x - x) ** 2 + (ev.y - y) ** 2 <= rad ** 2:
                return tok
        return None


    def nudge_zoom(self, factor: float) -> None:
        self._zoom = max(0.4, min(6.0, float(getattr(self, "_zoom", 1.0)) * factor))
        self.status.set(f"Map zoom {int(self._zoom * 100)}%")
        self.draw_map()

    def reset_zoom(self) -> None:
        self._zoom = 1.0
        self._vision_cells = 0
        self._pan = [0.0, 0.0]  # fraction of displayed map width/height
        self.status.set("Map zoom 100%")
        self.draw_map()

    def _on_wheel(self, ev):
        self.nudge_zoom(1.15 if ev.delta > 0 else 0.87)

    def _on_wheel_dir(self, ev, direction: int):
        self.nudge_zoom(1.15 if direction > 0 else 0.87)

    def _pan_start(self, ev):
        self._pan_last = (ev.x, ev.y)

    def _pan_move(self, ev):
        last = getattr(self, "_pan_last", None)
        if last is None:
            self._pan_last = (ev.x, ev.y)
            return
        iw, ih = getattr(self, "_img_disp", (1, 1))
        self._pan[0] += (ev.x - last[0]) / max(int(iw), 1)
        self._pan[1] += (ev.y - last[1]) / max(int(ih), 1)
        self._pan_last = (ev.x, ev.y)
        self.draw_map(tv=False)



    def _wall_hotkey(self, ev):
        focused = self.focus_get()
        cls = focused.winfo_class() if focused is not None else ""
        key = (ev.keysym or "")
        if cls in ("Entry", "TEntry", "Text", "TCombobox", "Combobox"):
            return
        if hasattr(self, "status"):
            self.status.set(f"Key {key}")
        ctrl = bool(ev.state & 0x4)
        if ctrl and key.lower() == "z":
            self.undo_wall()
            return "break"
        if ctrl:
            return
        if key.lower() == "w":
            self.start_wall_trace(False)
            return "break"
        if key.lower() == "d":
            self.start_wall_trace(True)
            return "break"
        if key.lower() == "c":
            self.clear_walls()
            return "break"
        if key.lower() == "f":
            self.toggle_fog()
            return "break"
        if key.lower() == "b":
            self.toggle_brush()
            return "break"
        if key.lower() == "r":
            self.cover_all_fog()
            return "break"
        if key == "Escape":
            self.stop_wall_trace()
            return "break"

    def start_wall_trace(self, door: bool) -> None:
        self._wall_mode = True
        self._wall_door = bool(door)
        self._wall_start = None
        self._reveal_mode = False
        if hasattr(self, "brush_btn"):
            self.brush_btn.configure(text="Brush off")
        self.status.set("Door brush: drag to draw. It saves when you let go." if door else "Wall brush: drag to draw. It saves when you let go.")

    def stop_wall_trace(self) -> None:
        self._wall_mode = False
        self._wall_start = None
        self.status.set("Wall tracing off")

    def _wall_click(self, ev) -> None:
        x, y = self._map_coords(ev)
        self._wall_stroke = [(x, y)]
        self._wall_live = None

    def _wall_stroke_to(self, ev) -> None:
        stroke = getattr(self, "_wall_stroke", None)
        if not stroke:
            return
        x, y = self._map_coords(ev)
        lx, ly = stroke[-1]
        if ((x - lx) ** 2 + (y - ly) ** 2) ** 0.5 < 0.008:
            return
        stroke.append((x, y))
        self._draw_live_stroke()

    def _draw_live_stroke(self) -> None:
        canvas = getattr(self, "canvas", None)
        stroke = getattr(self, "_wall_stroke", None)
        if canvas is None or not stroke or len(stroke) < 2:
            return
        if getattr(self, "_wall_live", None):
            canvas.delete(self._wall_live)
        ox, oy = getattr(self, "_img_origin", (0, 0))
        iw, ih = getattr(self, "_img_disp", self._img_size)
        pts = []
        for x, y in stroke:
            pts.extend((ox + x * iw, oy + y * ih))
        color = "#e0b15a" if getattr(self, "_wall_door", False) else "#d04545"
        self._wall_live = canvas.create_line(*pts, fill=color, width=3, smooth=True)

    def _finish_wall_stroke(self) -> None:
        m = self._selected_map()
        stroke = list(getattr(self, "_wall_stroke", None) or [])
        self._wall_stroke = None
        if getattr(self, "_wall_live", None) and hasattr(self, "canvas"):
            self.canvas.delete(self._wall_live)
            self._wall_live = None
        if m is None or len(stroke) < 2:
            return
        door = bool(getattr(self, "_wall_door", False))
        for (x1, y1), (x2, y2) in zip(stroke, stroke[1:]):
            self.repos["display"].add_wall(m.record.record_id, x1, y1, x2, y2, door=door)
        self.status.set(f"Saved {len(stroke) - 1} lines with the map. Drag again, or stop tracing.")
        self.draw_map()

    def undo_wall(self) -> None:
        m = self._selected_map()
        if m is None:
            return
        self.repos["display"].pop_wall(m.record.record_id)
        self.draw_map()

    def clear_walls(self) -> None:
        m = self._selected_map()
        if m is None:
            return
        if messagebox.askyesno("Walls", "Remove every wall and door on this map?", parent=self):
            self.repos["display"].clear_walls(m.record.record_id)
            self.draw_map()

    def _hit_wall(self, ev):
        m = self._selected_map()
        settings = self._settings_for(m) if m else None
        if settings is None:
            return None
        ox, oy = getattr(self, "_img_origin", (0, 0))
        iw, ih = getattr(self, "_img_disp", self._img_size)
        best, best_d = None, 10
        for wall in getattr(settings, "walls", []) or []:
            x1 = ox + float(wall.get("x1") or 0) * iw
            y1 = oy + float(wall.get("y1") or 0) * ih
            x2 = ox + float(wall.get("x2") or 0) * iw
            y2 = oy + float(wall.get("y2") or 0) * ih
            dist = self._point_segment(ev.x, ev.y, x1, y1, x2, y2)
            if dist < best_d:
                best, best_d = wall, dist
        return best

    def _point_segment(self, px, py, x1, y1, x2, y2) -> float:
        dx, dy = x2 - x1, y2 - y1
        if dx == 0 and dy == 0:
            return ((px - x1) ** 2 + (py - y1) ** 2) ** 0.5
        t = max(0.0, min(1.0, ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)))
        return ((px - (x1 + t * dx)) ** 2 + (py - (y1 + t * dy)) ** 2) ** 0.5



    def _token_in_view(self, tok, tokens, settings) -> bool:
        kind = str(tok.get("kind") or "").lower()
        if kind in ("pc", "companion"):
            return True
        x = float(tok.get("x") or 0)
        y = float(tok.get("y") or 0)
        for rect in list(getattr(settings, "revealed_regions", []) or []):
            rx, ry = float(rect.get("x", 0)), float(rect.get("y", 0))
            rw, rh = float(rect.get("w", 0)), float(rect.get("h", 0))
            if rx <= x <= rx + rw and ry <= y <= ry + rh:
                return True
        cells = int(getattr(self, "_vision_cells", 0) or 0)
        if not cells:
            return False
        walls = list(getattr(settings, "walls", []) or [])
        if not walls:
            dm = self._selected_map()
            if dm is not None:
                walls = list(getattr(self._settings_for(dm), "walls", []) or [])
        grid = max(16, int(getattr(settings, "grid_size_px", 50) or 50))
        width = 1000
        m = self._selected_player_map() or self._selected_map()
        path = self._resolve_image(m, settings, "player") if m is not None else None
        try:
            from PIL import Image
            if path:
                width = Image.open(path).size[0]
        except Exception:
            width = 1000
        reach = cells * grid / max(width, 1)
        viewers = [t for t in tokens if str(t.get("kind") or "").lower() in ("pc", "companion")]
        if not viewers:
            viewers = tokens
        for other in viewers:
            if other is tok:
                continue
            ox = float(other.get("x") or 0)
            oy = float(other.get("y") or 0)
            if ((x - ox) ** 2 + (y - oy) ** 2) ** 0.5 > reach:
                continue
            if not self._vision_blocked(ox, oy, x, y, walls):
                return True
        return False

    def _wall_shadow(self, tx, ty, wall, iw, ih, reach):
        x1 = float(wall.get("x1") or 0) * iw
        y1 = float(wall.get("y1") or 0) * ih
        x2 = float(wall.get("x2") or 0) * iw
        y2 = float(wall.get("y2") or 0) * ih
        def far(x, y):
            dx, dy = x - tx, y - ty
            dist = max((dx * dx + dy * dy) ** 0.5, 1.0)
            scale = reach / dist
            return (x + dx * scale, y + dy * scale)
        return [ (x1, y1), (x2, y2), far(x2, y2), far(x1, y1) ]

    def _vision_blocked(self, x1, y1, x2, y2, walls) -> bool:
        for wall in walls:
            if wall.get("door") and wall.get("open"):
                continue
            if self._segments_cross(
                x1, y1, x2, y2,
                float(wall.get("x1") or 0), float(wall.get("y1") or 0),
                float(wall.get("x2") or 0), float(wall.get("y2") or 0),
            ):
                return True
        return False

    def _segments_cross(self, ax, ay, bx, by, cx, cy, dx, dy) -> bool:
        def side(x, y, x1, y1, x2, y2):
            return (x2 - x1) * (y - y1) - (y2 - y1) * (x - x1)
        s1 = side(ax, ay, cx, cy, dx, dy)
        s2 = side(bx, by, cx, cy, dx, dy)
        s3 = side(cx, cy, ax, ay, bx, by)
        s4 = side(dx, dy, ax, ay, bx, by)
        return s1 * s2 < 0 and s3 * s4 < 0

    def toggle_brush(self) -> None:
        self._reveal_mode = not bool(getattr(self, "_reveal_mode", False))
        on = bool(self._reveal_mode)
        if hasattr(self, "brush_btn"):
            self.brush_btn.configure(text="Brush ON" if on else "Brush off")
        try:
            self.canvas.configure(cursor="circle" if on else "")
        except tk.TclError:
            pass
        self.status.set("Brush on — click or drag to reveal. Click Brush off when done." if on else "Brush off")

    def _on_down(self, ev):
        try:
            self.focus_set()
        except tk.TclError:
            pass
        if getattr(self, "_wall_mode", False):
            self._wall_click(ev)
            return
        if getattr(self, "_reveal_mode", False):
            self._reveal_at(ev)
            return
        tok = self._hit_token(ev)
        if tok:
            self._drag = tok
            self._pan_last = None
            return
        self._drag = None
        self._pan_last = None
        self._pan_last = (ev.x, ev.y)

    def _on_drag(self, ev):
        if getattr(self, "_wall_mode", False) and getattr(self, "_wall_stroke", None):
            self._wall_stroke_to(ev)
            return
        if getattr(self, "_reveal_mode", False):
            self._reveal_at(ev)
            return
        if self._drag:
            nx, ny = self._map_coords(ev)
            self._drag["x"] = nx
            self._drag["y"] = ny
            self.draw_map(tv=False)
            return
        if getattr(self, "_pan_last", None):
            self._pan_move(ev)

    def _on_up(self, ev):
        if getattr(self, "_wall_mode", False) and getattr(self, "_wall_stroke", None):
            self._finish_wall_stroke()
            return
        if self._drag and self._selected_map() is not None:
            self.repos["display"].move_token_live(self._selected_map().record.record_id, self._drag["id"], self._drag["x"], self._drag["y"])
        self._drag = None
        self._pan_last = None

    def _on_right(self, ev):
        wall = self._hit_wall(ev)
        if wall is not None and self._selected_map() is not None:
            rid = self._selected_map().record.record_id
            if wall.get("door"):
                self.repos["display"].toggle_door(rid, wall["id"])
                self.status.set("Door open" if not wall.get("open") else "Door closed")
            elif messagebox.askyesno("Wall", "Remove this wall?", parent=self):
                self.repos["display"].remove_wall(rid, wall["id"])
            self.draw_map()
            return
        tok = self._hit_token(ev)
        m = self._selected_map()
        if tok is None or m is None:
            return
        if messagebox.askyesno("Token", f"Remove {tok.get('name')}?", parent=self):
            self.repos["display"].remove_token(m.record.record_id, tok["id"])
            self.board = [b for b in self.board if b.get("token_id") != tok["id"]]
            self.draw_map()
            self.refresh_board()

    def _reveal_at(self, ev):
        targets = [m for m in (self._selected_player_map(), self._selected_map()) if m is not None]
        if not targets:
            return
        ox, oy = getattr(self, "_img_origin", (0, 0))
        iw, ih = getattr(self, "_img_disp", self._img_size)
        settings = self.repos["display"].get(targets[0].record.record_id)
        span = float(getattr(self, "_reveal_size", 0.16))
        if settings is not None and getattr(settings, "grid_enabled", False):
            cells = float(getattr(self, "_brush_cells", 1) or 1)
            src = max(16, int(getattr(settings, "grid_size_px", 50) or 50))
            path = self._resolve_image(targets[0], settings, "dm") or self._resolve_image(targets[0], settings, "player")
            try:
                orig_w = Image.open(path).size[0] if path else iw
            except Exception:
                orig_w = iw
            span = max(0.02, (src * cells) / max(orig_w, 1))
        x = max(0.0, (ev.x - ox) / max(iw, 1) - span / 2)
        y = max(0.0, (ev.y - oy) / max(ih, 1) - span / 2)
        seen = set()
        for target in targets:
            rid = target.record.record_id
            if rid in seen:
                continue
            seen.add(rid)
            self.repos["display"].add_reveal(rid, x, y, span, span)
            settings = self.repos["display"].get(rid)
            settings.fog_enabled = True
            self.repos["display"].save(settings)
        if hasattr(self, "fog_on"):
            self.fog_on.set(True)
        self.draw_map()

    def clear_fog(self) -> None:
        m = self._selected_player_map()
        if m is None:
            return
        self.repos["display"].clear_reveals(m.record.record_id)
        settings = self.repos["display"].get(m.record.record_id)
        settings.fog_enabled = True
        self.repos["display"].save(settings)
        if hasattr(self, "fog_on"):
            self.fog_on.set(True)
        self.draw_map()

    def board_from_tokens(self) -> None:
        existing = {b.get("token_id") for b in self.board}
        for tok in getattr(self, "_tokens", []):
            if tok.get("id") in existing:
                continue
            hp = _safe_int(tok.get("hp") or tok.get("max_hp") or 10, 10)
            self.board.append({
                "name": tok.get("name") or "Token",
                "kind": tok.get("kind") or "Token",
                "init": 0,
                "hp": hp,
                "max_hp": _safe_int(tok.get("max_hp") or hp, hp),
                "ac": tok.get("ac") or "10",
                "token_id": tok.get("id"),
            })
        self._tracker_log("Board filled from map tokens")
        self.refresh_board()

    def set_board_tag(self) -> None:
        idx = self._sel_board()
        if idx is None:
            messagebox.showinfo("Board", "Select a row, type a tag, then Set tag.", parent=self)
            return
        tag = (self.add_tag.get() if hasattr(self, "add_tag") else "").strip()
        self.board[idx]["tag"] = tag
        token_id = self.board[idx].get("token_id")
        m = self._selected_map()
        if m is not None and token_id:
            settings = self.repos["display"].get(m.record.record_id)
            label = f"{self.board[idx].get('name')} {tag}".strip() if tag else self.board[idx].get("name")
            for tok in list(settings.tokens or []):
                if tok.get("id") == token_id:
                    tok["name"] = label
                    break
            self.repos["display"].save(settings)
            self.draw_map()
        self.refresh_board()

    def add_to_board(self) -> None:

        name = self.add_pick.get().strip()
        if not name:
            return
        hp, ac, rid = 10, "10", ""
        kind = self.add_kind.get()
        listing = []
        if kind == "Monster":
            listing = self.repos["monster"].monsters()
        elif kind == "NPC":
            listing = self.repos["npc"].npcs()
        else:
            listing = self.repos["pc"].player_characters()
        for entry in listing:
            if entry.record.name == name or entry.record.name.lower() == name.lower():
                rid = entry.record.record_id
                hp = _safe_int(getattr(entry.details, "hit_points", 10), 10)
                ac = str(getattr(entry.details, "armor_class", 10) or 10)
        tag = (self.add_tag.get() if hasattr(self, "add_tag") else "").strip()
        if not tag:
            used = {str(r.get("tag") or "").upper() for r in self.board if r.get("name") == name}
            for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
                if letter not in used:
                    tag = letter
                    break
        label = f"{name} {tag}".strip() if tag else name
        self.board.append({"name": name, "tag": tag, "kind": kind, "init": 0, "hp": hp, "max_hp": hp, "ac": ac, "record_id": rid})
        m = self._selected_map()
        if m is not None:
            settings = self.repos["display"].add_token(
                m.record.record_id, label, 0.5, 0.5, hp=str(hp), max_hp=str(hp), ac=str(ac),
                linked_record_id=rid, kind=kind.lower(),
            )
            if settings.tokens:
                self.board[-1]["token_id"] = settings.tokens[-1]["id"]
            self.draw_map()
        self._tracker_log(f"Added {name} to the board")
        self.refresh_board()

    def refresh_board(self) -> None:
        self.board_list.delete(0, "end")
        ordered = sorted(enumerate(self.board), key=lambda p: (-_safe_int(p[1].get("init")), p[0]))
        self._order = [i for i, _ in ordered]
        for display_i, src in enumerate(self._order):
            row = self.board[src]
            mark = "▶ " if self.board and display_i == (self.turn % max(len(self.board), 1)) else "   "
            shown = row.get("name") or ""
            if row.get("tag"):
                shown = f"{shown} {row.get('tag')}"
            self.board_list.insert("end", f"{mark}{row.get('init', 0):>2}  {shown}  HP {row.get('hp')}/{row.get('max_hp')}  AC {row.get('ac')}")
        if self.board:
            cur = self.board[self._order[self.turn % len(self.board)]]
            shown = cur.get("name") or ""
            if cur.get("tag"):
                shown = f"{shown} {cur.get('tag')}"
            self.turn_var.set("Turn: " + shown)
        else:
            self.turn_var.set("No turn")

    def set_init(self) -> None:
        idx = self._sel_board()
        if idx is None:
            messagebox.showinfo("Board", "Select a name on the board first.", parent=self)
            return
        self.board[idx]["init"] = _safe_int(self.init_entry.get(), 0)
        self.turn = 0
        self.refresh_board()

    def sort_board(self) -> None:
        self.turn = 0
        self.refresh_board()


    def _find_library_entry(self, row: dict):
        rid = (row.get("record_id") or "").strip()
        name = (row.get("name") or "").strip()
        kind = (row.get("kind") or "").strip()
        searches = []
        if kind == "Monster":
            searches = [("Monster", self.repos["monster"].monsters())]
        elif kind == "NPC":
            searches = [("NPC", self.repos["npc"].npcs())]
        elif kind == "PC":
            searches = [("PC", self.repos["pc"].player_characters())]
        elif kind == "Companion":
            searches = [("Companion", self.repos["companion"].companions())] if "companion" in self.repos else []
        else:
            searches = [
                ("Monster", self.repos["monster"].monsters()),
                ("NPC", self.repos["npc"].npcs()),
                ("PC", self.repos["pc"].player_characters()),
                ("Companion", self.repos["companion"].companions()) if "companion" in self.repos else ("PC", []),
            ]
        for label, listing in searches:
            for entry in listing:
                rec = entry.record
                if rid and rec.record_id == rid:
                    return label, entry
                if name and rec.name.lower() == name.lower():
                    return label, entry
        return None, None


    def _stat_sheet_text(self, kind, entry):
        """Readable stat block for Monster / PC entries (incl. Library's nested 'sheet'); else None."""
        key = (kind or "").strip().lower()
        if key in ("player character", "player_character"):
            key = "pc"
        if key not in ("monster", "pc") or entry is None or getattr(entry, "record", None) is None:
            return None
        try:
            from core.stat_sheet import format_monster, format_player_character
            rec = entry.record
            raw = {}
            repo = self.repos.get(key)
            reader = getattr(repo, "_read", None)
            if callable(reader):
                raw = next(
                    (r for r in reader() if isinstance(r, dict) and r.get("record_id") == rec.record_id),
                    {},
                )
            fmt = format_monster if key == "monster" else format_player_character
            return fmt(rec.name, (rec.description or "").strip(), entry.details, raw)
        except Exception:
            return None  # fall back to the old key: value dump

    POPUP_IMAGE_MAX = (360, 220)

    def _records_repo(self):
        repos = getattr(self, "repos", None) or {}
        return getattr(repos.get("monster"), "records", None)

    def _record_image_path(self, record_id: str):
        """First linked image for a record (portrait/token first). Lazy, popup-time only."""
        assets = (getattr(self, "repos", None) or {}).get("assets")
        if assets is None or not record_id:
            return None
        found = []
        for att in assets.attachments_for(record_id):
            path = assets.absolute_path(att.relative_path)
            if path.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"} and path.is_file():
                found.append((f"{att.label} {path.name}".lower(), path))
        if not found:
            return None
        def rank(entry):
            text = entry[0]
            return 0 if "portrait" in text else 1 if "token" in text else 2
        found.sort(key=rank)
        return found[0][1]

    def _load_popup_photo(self, path, max_w: int, max_h: int):
        try:
            from PIL import Image, ImageTk
            with Image.open(path) as image:
                image.thumbnail((max_w, max_h))
                return ImageTk.PhotoImage(image)
        except ImportError:
            if path.suffix.lower() not in (".png", ".gif"):
                return None
            photo = tk.PhotoImage(file=str(path))
            factor = max(1, -(-photo.width() // max_w), -(-photo.height() // max_h))
            return photo.subsample(factor) if factor > 1 else photo

    def _popup_add_videos(self, win, record_id: str) -> None:
        """'▶ Play video' buttons for a record's video attachments (popup-time only)."""
        assets = (getattr(self, "repos", None) or {}).get("assets")
        if assets is None or not record_id:
            return
        videos = [a for a in assets.attachments_for(record_id)
                  if getattr(a, "kind", "") == "video" or Path(a.relative_path).suffix.lower() in VIDEO_SUFFIXES]
        if not videos:
            return
        row = ttk.Frame(win)
        row.pack(side="top", fill="x", padx=8, pady=(4, 0))
        for att in videos[:4]:
            name = att.label or Path(att.relative_path).name
            ttk.Button(row, text=f"▶ Play video: {name[:28]}", command=lambda r=att.relative_path: self._play_video(r)).pack(side="left", padx=(0, 4))

    def _popup_add_image(self, win, record_id: str) -> None:
        """Image strip at the top of a record popup; silently skipped if none."""
        try:
            self._popup_add_videos(win, record_id)
        except Exception:
            log_exception()
        try:
            path = self._record_image_path(record_id)
            if path is None:
                return
            photo = self._load_popup_photo(path, *self.POPUP_IMAGE_MAX)
            if photo is None:
                return
            win._popup_photo = photo  # keep a reference
            tk.Label(win, image=photo, bg=BG, borderwidth=0).pack(side="top", pady=(8, 4))
        except Exception:
            log_exception()

    def _popup_connections_text(self, record_id: str) -> str:
        try:
            from core.stat_sheet import format_connections
            text = format_connections(self._records_repo(), record_id)
        except Exception:
            log_exception()
            return ""
        return f"\n\nCONNECTIONS\n{text}" if text else ""

    def _popup_entry(self, title: str, kind: str, record_id: str, body: str, table=None) -> None:
        win = tk.Toplevel(self)
        win.title(title)
        win.geometry("520x640")
        win.configure(bg=BG)
        if table is not None:
            bar = ttk.Frame(win)
            bar.pack(fill="x", padx=8, pady=6)
            result = tk.StringVar(value="")
            ttk.Button(bar, text="Roll this table", command=lambda: self._roll_named_table(table, result)).pack(side="left")
            ttk.Label(bar, textvariable=result, wraplength=360).pack(side="left", padx=8)
        self._popup_add_image(win, record_id)
        txt = tk.Text(win, wrap="word", bg=PANEL, fg=FG, insertbackground=FG, padx=10, pady=8)
        txt.pack(fill="both", expand=True)
        header = f"{title}\n[{kind}]  {record_id}\n\n"
        txt.insert("1.0", header + (body or "") + self._popup_connections_text(record_id))
        txt.tag_configure("crafted", foreground="#e0b15a")
        start = "1.0"
        while True:
            found = txt.search("→ ", start, stopindex="end")
            if not found:
                break
            item_start = f"{found}+2c"
            line_end = txt.index(f"{found} lineend")
            txt.tag_add("crafted", item_start, line_end)
            start = line_end
        txt.configure(state="disabled")

        def _open_crafted(_event, widget=txt):
            try:
                index = widget.index(f"@{_event.x},{_event.y}")
                line = widget.get(f"{index} linestart", f"{index} lineend")
            except tk.TclError:
                return
            if "→" not in line:
                return
            item = line.split("→", 1)[1].strip()
            if not item or item.lower() == "result":
                return
            if ": " in item:
                kind, name = item.split(": ", 1)
                self.open_library_line(f"{name} | {kind} |")
            else:
                self.open_library_line(f"{item} | Item |")

        txt.bind("<Double-Button-1>", _open_crafted)

    def _iter_library(self, kind: str):
        kind = (kind or "").strip().lower()
        mapping = {
            "monster": ("monster", "monsters"),
            "npc": ("npc", "npcs"),
            "pc": ("pc", "player_characters"),
            "item": ("item", "items"),
            "weapon": ("weapon", "weapons"),
            "armor": ("armor", "armor"),
            "trap": ("trap", "traps"),
            "quest": ("quest", "quests"),
            "companion": ("companion", "companions"),
            "note": ("notes", "notes"),
            "table": ("table", "tables"),
            "location": ("location", "locations"),
            "shop": ("shop", "shops"),
            "faction": ("faction", "factions"),
            "material": ("materials", "rows"),
        }
        spec = mapping.get(kind)
        if spec is None:
            return []
        repo = self.repos.get(spec[0])
        if repo is None:
            return []
        fn = getattr(repo, spec[1], None)
        return list(fn()) if callable(fn) else []

    def open_library_line(self, line: str) -> None:
        text = (line or "").strip()
        if text.startswith("Rolled ") or ("1d" in text and "(" in text and ":" in text):
            self._open_rolled_line(text)
            return
        for prefix in ("Found:", "Met:", "At:", "Choice:"):
            if text.startswith(prefix):
                text = text[len(prefix):].strip()
        parts = [p.strip() for p in text.split("|")]
        name, kind, rid = text, "", ""
        if len(parts) >= 3:
            name, kind, rid = parts[0], parts[1], parts[-1]
        elif len(parts) == 2:
            name, kind = parts[0], parts[1]
        kinds = [kind] if kind else ["Monster", "NPC", "PC", "Item", "Weapon", "Armor", "Trap", "Quest", "Note", "Table", "Location", "Shop", "Faction", "Material"]
        entry = None
        used = kind or "Record"
        for k in kinds:
            for row in self._iter_library(k):
                rec = getattr(row, "record", None) or row
                rec_id = getattr(rec, "record_id", "") or getattr(row, "table_id", "") or getattr(row, "note_id", "") or getattr(row, "material_id", "") or ""
                rec_name = getattr(rec, "name", "") or getattr(row, "name", "") or getattr(row, "title", "") or ""
                if (rid and rec_id == rid) or rec_name.strip().lower() == name.lower():
                    entry = row
                    used = k
                    break
            if entry is not None:
                break
        if entry is None:
            needle = (name or text).strip().lower()
            for table in self._iter_library("Table"):
                if needle and needle in (getattr(table, "name", "") or "").lower():
                    entry, used = table, "Table"
                    break
                for row in list(getattr(table, "rows", []) or []):
                    row_text = (getattr(row, "text", "") or "").strip().lower()
                    if needle and row_text and (needle in row_text or row_text in needle):
                        entry, used = table, "Table"
                        break
                if entry is not None:
                    break
        if entry is None:
            hit = self._best_srd(name or text)
            if hit is not None:
                self.status.set(f"SRD {hit.kind}: {hit.name}  (not in the campaign)")
                self._popup_srd(hit)
                return
            messagebox.showinfo("Library", f"No workbook row for {name or line}.", parent=self)
            return
        rec = getattr(entry, "record", None)
        details = getattr(entry, "details", None)
        title = getattr(rec, "name", None) or getattr(entry, "name", name)
        record_id = getattr(rec, "record_id", None) or getattr(entry, "table_id", None) or getattr(entry, "note_id", None) or getattr(entry, "material_id", rid)
        body = []
        if rec is not None and getattr(rec, "description", ""):
            body.append(rec.description.strip())
            body.append("")
        sheet_text = self._stat_sheet_text(used, entry)
        if sheet_text is not None:
            body = [sheet_text]
        elif details is not None:
            for key, val in vars(details).items():
                if key in ("record_id", "recipes") or val in ("", None, False, "[]"):
                    continue
                body.append(f"{key.replace('_', ' ')}: {val}")
            recipes = getattr(details, "recipes", "") or ""
            if recipes and recipes != "[]":
                try:
                    rows = json.loads(recipes)
                except json.JSONDecodeError:
                    rows = []
                if rows:
                    body.append("")
                    body.append("Recipes  (double-click a crafted item)")
                    for row in rows:
                        makes = row.get("makes") or "result"
                        body.append(f"• {row.get('name', 'Recipe')} → {makes}")
                        takes = ", ".join(f"{part.get('name')} x{part.get('qty', 1)}" for part in row.get("takes", []))
                        if takes:
                            body.append(f"    Takes: {takes}")
                        extra = "  ".join(part for part in (row.get("price", ""), row.get("time", "")) if part)
                        if extra:
                            body.append(f"    {extra}")
        elif getattr(entry, "body", None):
            body.append(str(entry.body))
        elif hasattr(entry, "notes"):
            body.append(getattr(entry, "notes") or "")
        if used.lower() == "table" or getattr(entry, "table_id", ""):
            body.append(f"Type: {getattr(entry, 'table_type', '')}   Die: 1d{getattr(entry, 'die', 20)}")
            if getattr(entry, "notes", ""):
                body.append(str(entry.notes))
            body.append("")
            for row in list(getattr(entry, "rows", []) or []):
                mark = "  [image]" if getattr(row, "image_path", "") else ""
                body.append(f"{row.low}–{row.high}  {row.text}{mark}")
        self._popup_entry(str(title), used.title(), str(record_id), "\n".join(body), table=entry if getattr(entry, "table_id", "") else None)

    def open_dm_item(self) -> None:
        if not hasattr(self, "dm_items_box"):
            return
        try:
            line = self.dm_items_box.get("insert linestart", "insert lineend").strip()
        except tk.TclError:
            line = ""
        if line:
            self.open_library_line(line)

    def _row_image_path(self, row):
        rel = str(getattr(row, "image_path", "") or "").strip()
        if not rel or self.project is None:
            return None
        candidates = [Path(rel), self.project.root / rel, self.project.root / "assets" / "images" / Path(rel).name]
        forge = getattr(self, "forge_root", None)
        if forge:
            candidates.append(Path(forge) / rel)
            candidates.append(Path(forge) / "projects" / self.project.root.name / rel)
        for path in candidates:
            try:
                if path.is_file():
                    return path
            except OSError:
                continue
        images = self.project.root / "assets" / "images"
        if images.is_dir():
            wanted = Path(rel).name.lower()
            for path in sorted(images.rglob("*")):  # includes type subfolders
                if path.name.lower() == wanted and path.is_file():
                    return path
        return None

    def _show_row_image(self, row, table=None) -> None:
        path = self._row_image_path(row)
        title = getattr(row, "text", "") or getattr(table, "name", "Row")
        stored = getattr(row, "image_path", "") or "(no image on this row)"
        if path is None:
            self.status.set(f"No image file for {title}: {stored}")
            messagebox.showinfo("Row image", f"No picture file for this row.\nSaved path: {stored}", parent=self)
            return
        self.status.set(f"Image: {path}")
        try:
            os.startfile(str(path))
        except Exception:
            self._show_dm_handout(path, str(title)[:80])
            self._handout.lift()
            self._handout.focus_force()

    def _roll_named_table(self, table, result_var) -> None:
        rolled = self.repos["table"].roll(table)
        if rolled is None:
            result_var.set("Table is empty")
            return
        pick, row = rolled
        text = f"1d{table.die}={pick} — no row" if row is None else f"1d{table.die}={pick} ({row.low}–{row.high}) {row.text}"
        result_var.set(text)
        self._tracker_log(f"Rolled {table.name}: {text}")
        self._show_row_image(row, table)

    def open_log_record(self) -> None:
        if not hasattr(self, "log_box"):
            return
        try:
            line = self.log_box.get("insert linestart", "insert lineend").strip()
        except tk.TclError:
            line = ""
        if line.startswith("Rolled ") or ("1d" in line and "(" in line):
            self._open_rolled_line(line)
            return
        if line:
            self.open_library_line(line)

    def _open_rolled_line(self, line: str) -> bool:
        text = (line or "").strip()
        if text.startswith("Rolled "):
            text = text[len("Rolled "):]
        name, _, rest = text.partition(":")
        name = name.strip()
        result = rest.strip()
        tables = []
        repo = self.repos.get("table") if getattr(self, "repos", None) else None
        if repo is not None:
            tables = list(repo.tables())
        table = next((t for t in tables if t.name == name), None)
        if table is None:
            table = next((t for t in tables if t.name and t.name in line), None)
        if table is None:
            self.status.set("Could not match that roll to a saved table. Open the same Forge folder as Library.")
            return True
        row = None
        for candidate in list(table.rows or []):
            label = (candidate.text or "").strip()
            if label and label in line:
                row = candidate
                break
        if row is None and result:
            # (1-1) or (1–1) Crystal Dome
            chunk = result.split(")", 1)[-1].strip()
            for candidate in list(table.rows or []):
                if (candidate.text or "").strip() == chunk:
                    row = candidate
                    break
        if row is None:
            self.status.set(f"Rolled {table.name}, but no row text matched. Save the table in Library 209.")
            self._popup_entry(table.name, "Table", table.table_id, result or "No matching row")
            return True
        self._show_row_image(row, table)
        return True


    def _open_record_images(self, record_id: str, title: str) -> None:
        repo = self.repos.get("assets") if getattr(self, "repos", None) else None
        if repo is None or not record_id or self.project is None:
            return
        exts = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff"}
        opened = 0
        for att in repo.attachments_for(record_id):
            rel = getattr(att, "relative_path", "") or ""
            path = Path(rel)
            if not path.is_file():
                path = self.project.root / rel
            if path.suffix.lower() not in exts or not path.is_file():
                continue
            try:
                os.startfile(str(path))
            except Exception:
                self._show_dm_handout(path, title)
            opened += 1
        if opened:
            self.status.set(f"Opened {opened} image(s) for {title}")
        else:
            self.status.set(f"No image asset on {title}")


    def open_place_line(self) -> None:
        if not hasattr(self, "places_box"):
            return
        try:
            line = self.places_box.get("insert linestart", "insert lineend").strip()
        except tk.TclError:
            line = ""
        if line:
            self.open_library_line(line)

    def open_related_quest(self) -> None:
        if not hasattr(self, "quests_box") or self.project is None:
            return
        try:
            line = self.quests_box.get("insert linestart", "insert lineend").strip()
        except tk.TclError:
            line = self.quests_box.get("1.0", "end-1c").strip().splitlines()[0] if self.quests_box.get("1.0", "end-1c").strip() else ""
        if not line:
            return
        rid = ""
        name = line.split("|")[0].strip()
        parts = [p.strip() for p in line.split("|")]
        if len(parts) >= 3:
            rid = parts[-1]
            name = parts[0]
        quest = None
        repo = self.repos.get("quest")
        if repo is not None:
            for entry in repo.quests():
                if (rid and entry.record.record_id == rid) or entry.record.name.strip().lower() == name.lower():
                    quest = entry
                    break
        if quest is None:
            messagebox.showinfo("Quest", f"No Quests workbook row for {name or line}.", parent=self)
            return
        rec = quest.record
        details = quest.details
        lines = []
        if rec.description:
            lines.append(rec.description.strip())
            lines.append("")
        for key, val in vars(details).items():
            if key == "record_id" or val in ("", None, False):
                continue
            lines.append(f"{key.replace('_', ' ')}: {val}")
        self._popup_entry(rec.name, "Quest", rec.record_id, "\n".join(lines))
        self._open_record_images(rec.record_id, rec.name)

    def open_board_record(self) -> None:
        idx = self._sel_board()
        if idx is None:
            messagebox.showinfo("Board", "Select someone on the board.", parent=self)
            return
        kind, entry = self._find_library_entry(self.board[idx])
        if entry is None:
            messagebox.showinfo("Library", "No workbook row matches that name. Add them from the dropdown so the record is linked.", parent=self)
            return
        rec = entry.record
        details = entry.details
        lines = [rec.name, f"[{kind}]  {rec.record_id}", ""]
        sheet_text = self._stat_sheet_text(kind, entry)
        if sheet_text is not None:
            lines.append(sheet_text)
        else:
            if rec.description:
                lines.append(rec.description.strip())
                lines.append("")
            for key, val in vars(details).items():
                if key == "record_id" or val in ("", None, False):
                    continue
                lines.append(f"{key.replace('_', ' ')}: {val}")
        win = tk.Toplevel(self)
        win.title(rec.name)
        win.geometry("520x640")
        win.configure(bg=BG)
        self._popup_add_image(win, rec.record_id)
        txt = tk.Text(win, wrap="word", bg=PANEL, fg=FG, insertbackground=FG, padx=10, pady=8)
        txt.pack(fill="both", expand=True)
        txt.insert("1.0", "\n".join(lines) + self._popup_connections_text(rec.record_id))
        txt.configure(state="disabled")

    def roll_init(self) -> None:
        for row in self.board:
            row["init"] = random.randint(1, 20)
        self.turn = 0
        self._tracker_log("Initiative rolled")
        self.refresh_board()

    def next_turn(self) -> None:
        if self.board:
            self.turn = (self.turn + 1) % len(self.board)
            self.refresh_board()

    def _sel_board(self):
        sel = self.board_list.curselection()
        if not sel:
            return None
        return self._order[sel[0]]

    def adjust_hp(self, delta: int) -> None:
        idx = self._sel_board()
        if idx is None:
            messagebox.showinfo("Board", "Select someone first.", parent=self)
            return
        row = self.board[idx]
        row["hp"] = max(0, _safe_int(row.get("hp")) + delta)
        m = self._selected_map()
        if m is not None and row.get("token_id"):
            self.repos["display"].update_token(m.record.record_id, row["token_id"], hp=str(row["hp"]))
            self.draw_map()
        self._tracker_log(f"{row['name']} {'healed' if delta > 0 else 'took'} {abs(delta)} → {row['hp']} HP")
        self.refresh_board()

    def remove_board(self) -> None:
        idx = self._sel_board()
        if idx is None:
            return
        row = self.board[idx]
        m = self._selected_map()
        if m is not None and row.get("token_id"):
            self.repos["display"].remove_token(m.record.record_id, row["token_id"])
        del self.board[idx]
        self.turn = 0
        self.draw_map()
        self.refresh_board()


    def _places_from_script_file(self, script, beat) -> str:
        try:
            import json
            path = self.project.root / "data" / "records" / "scripts.json"
            rows = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, AttributeError):
            return ""
        sid = getattr(getattr(script, "record", None), "record_id", "")
        bid = getattr(beat, "id", "")
        for row in rows if isinstance(rows, list) else []:
            if row.get("record_id") != sid and row.get("id") != sid:
                details = row.get("details") or row
                if details.get("record_id") != sid and row.get("record_id") != sid:
                    continue
            details = row.get("details") or row
            for item in details.get("beats") or []:
                if item.get("id") == bid or item.get("title") == getattr(beat, "title", ""):
                    return str(item.get("places") or "")
        return ""


    def _select_script(self) -> None:
        self._beat_index = 0
        self.show_beat(0)


    def _open_next_script(self, script) -> bool:
        target = (getattr(getattr(script, "details", None), "next_script_id", "") or "").strip()
        scripts = getattr(self, "_scripts", [])
        if not target:
            idx = self.script_combo.current() if hasattr(self, "script_combo") else -1
            if idx < 0 or idx + 1 >= len(scripts):
                return False
            target = scripts[idx + 1].record.record_id
        for i, other in enumerate(scripts):
            if other.record.record_id == target:
                self._beat_index = 0
                try:
                    self.script_combo.current(i)
                except tk.TclError:
                    return False
                self.status.set("Next script: " + other.record.name)
                self.show_beat(0)
                return True
        self.status.set("Next script is missing from this project.")
        return True


    def _watch_num(self, var, default=0) -> int:
        try:
            return int(var.get())
        except (tk.TclError, ValueError, AttributeError):
            return default

    def _watch_names(self, value: str) -> list[str]:
        return [part.strip() for part in value.replace(";", ",").split(",") if part.strip()]

    def watch_add_person(self) -> None:
        name = self.watch_add_var.get().strip()
        if not name:
            return
        if not hasattr(self, "_watch_roster") or not isinstance(self._watch_roster, list):
            self._watch_roster = []
        if any(isinstance(row, dict) and row.get("name") == name for row in self._watch_roster):
            self.watch_status_var.set(f"{name} is already in the watch.")
            return
        try:
            con = int(self.watch_con_var.get() or 0)
        except ValueError:
            con = 0
        self._watch_roster.append({"name": name, "role": "asleep", "con": con, "con_roll": "", "exhaustion": 0, "recovered": False})
        self._rest_row(name)
        self.watch_add_var.set("")
        self._refresh_watch_people()


    def watch_con_save(self) -> None:
        roster = [row for row in getattr(self, "_watch_roster", []) if isinstance(row, dict)]
        rolled = []
        for row in roster:
            rest = self._rest_row(row.get("name", ""))
            if rest.get("sleep", 0) >= 6 and rest.get("interrupted", 0) <= 1:
                row["con_roll"] = ""
                continue
            try:
                con = int(row.get("con", 0) or 0)
            except (TypeError, ValueError):
                con = 0
            die = random.randint(1, 20)
            total = die + con
            result = "pass" if total >= 10 else "fail"
            if result == "fail":
                row["exhaustion"] = int(row.get("exhaustion", 0) or 0) + 1
            row["con_roll"] = f"DC 10 Con {total} {result} (d20 {die}{con:+d})"
            rolled.append(f"{row.get('name')} {result}")
        self._watch_roster = roster
        self._refresh_watch_people()
        self.watch_status_var.set("DC 10 Con: " + (", ".join(rolled) if rolled else "everyone qualified"))

    def watch_set_role(self, role: str) -> None:
        sel = self.watch_people.curselection() if hasattr(self, "watch_people") else ()
        roster = [row for row in getattr(self, "_watch_roster", []) if isinstance(row, dict)]
        if not sel or sel[0] >= len(roster):
            self.watch_status_var.set("Select a person first.")
            return
        roster[sel[0]]["role"] = role
        self._watch_roster = roster
        self._refresh_watch_people()
        self.watch_status_var.set(f"{roster[sel[0]]['name']} is {'on watch' if role == 'watch' else 'asleep'}. Rest kept.")

    def watch_remove_person(self) -> None:
        sel = self.watch_people.curselection() if hasattr(self, "watch_people") else ()
        roster = [row for row in getattr(self, "_watch_roster", []) if isinstance(row, dict)]
        if not sel or sel[0] >= len(roster):
            return
        roster.pop(sel[0])
        self._watch_roster = roster
        self._refresh_watch_people()

    def _refresh_watch_people(self) -> None:
        box = getattr(self, "watch_people", None)
        if box is None:
            return
        sleep = getattr(self, "_watch_sleep", {})
        box.delete(0, "end")
        on, asleep = [], []
        for row in getattr(self, "_watch_roster", []):
            if not isinstance(row, dict):
                continue
            name = row.get("name", "")
            rest = sleep.get(name, {})
            if not isinstance(rest, dict):
                rest = {"sleep": int(rest or 0), "interrupted": 0}
            role = "on watch" if row.get("role") == "watch" else "asleep"
            sleep_h = rest.get("sleep", 0)
            interrupted = rest.get("interrupted", 0)
            qualified = sleep_h >= 6 and interrupted <= 1
            rest_mark = "long rest" if qualified else "not yet"
            save = ""
            if not qualified and row.get("con_roll"):
                save = " — " + row["con_roll"]
            exhaustion = int(row.get("exhaustion", 0) or 0)
            tired = f" — exhaustion {exhaustion}" if exhaustion else ""
            restored = " — exhaustion cleared" if row.get("recovered") and exhaustion == 0 else ""
            box.insert("end", f"{name} — {role} — {sleep_h}h, {interrupted} interrupted — {rest_mark}{save}{tired}{restored}")
            (on if row.get("role") == "watch" else asleep).append(name)
        if hasattr(self, "watch_on_var"):
            self.watch_on_var.set(", ".join(on))
        if hasattr(self, "watch_asleep_var"):
            self.watch_asleep_var.set(", ".join(asleep))
        if hasattr(self, "watch_sleep_var"):
            self.watch_sleep_var.set("")

    def _refresh_watch_marks(self) -> None:
        frame = getattr(self, "watch_checks_frame", None)
        if frame is None:
            return
        for child in frame.winfo_children():
            child.destroy()
        per = max(1, self._watch_num(self.watch_hours_per_var, 2))
        hour = self._watch_num(self.watch_hour_var)
        marks = getattr(self, "_watch_marks", [])
        for index in range(1, per + 1):
            if index > hour:
                label, colour = "not yet", "#8d9096"
            else:
                label = marks[index - 1] if index - 1 < len(marks) else "open"
                colour = {"checked": "#7dcea0", "stirred": "#e0b15a", "open": "#f4f1ea"}.get(label, "#f4f1ea")
                found = getattr(self, "_watch_encounters", {}).get(index, "")
                if found:
                    label = f"{label}: {found.split(' · ')[0]}"
            current = " *" if index == hour else ""
            ttk.Label(frame, text=f"H{index} {label}{current}", foreground=colour).pack(side="left", padx=(0, 8))
        sleep = getattr(self, "_watch_sleep", {})
        names = list(getattr(self, "_watch_roster", []))
        for name in sleep:
            if name not in names:
                names.append(name)
        parts = []
        for name in names:
            row = sleep.get(name, {})
            if not isinstance(row, dict):
                row = {"sleep": int(row or 0), "interrupted": 0}
            parts.append(f"{name} {row.get('sleep', 0)}h, {row.get('interrupted', 0)} interrupted")
        shown = "Rest: " + (" · ".join(parts) if parts else "none yet")
        if hasattr(self, "watch_sleep_var"):
            self.watch_sleep_var.set(shown)

    def _rest_row(self, name: str) -> dict:
        row = self._watch_sleep.get(name)
        if not isinstance(row, dict):
            row = {"sleep": int(row or 0), "interrupted": 0}
            self._watch_sleep[name] = row
        return row


    def _watch_commit_names(self) -> None:
        if not hasattr(self, "_watch_roster"):
            self._watch_roster = []
        for source in (getattr(self, "watch_on_var", None), getattr(self, "watch_asleep_var", None)):
            if source is None:
                continue
            for name in self._watch_names(source.get()):
                if name not in self._watch_roster:
                    self._watch_roster.append(name)
        self._refresh_watch_marks()

    def _add_sleep(self) -> None:
        for row in getattr(self, "_watch_roster", []):
            if isinstance(row, dict) and row.get("role") != "watch":
                self._rest_row(row.get("name", ""))["sleep"] += 1
        self._recover_long_rest()
        self._refresh_watch_people()

    def _recover_long_rest(self) -> None:
        for row in getattr(self, "_watch_roster", []):
            if not isinstance(row, dict) or row.get("recovered"):
                continue
            rest = self._rest_row(row.get("name", ""))
            if rest.get("sleep", 0) >= 6 and rest.get("interrupted", 0) <= 1:
                row["exhaustion"] = max(0, int(row.get("exhaustion", 0) or 0) - 1)
                row["recovered"] = True

    def _interrupt_rest(self) -> str:
        names = [row.get("name", "") for row in getattr(self, "_watch_roster", []) if isinstance(row, dict) and row.get("role") != "watch" and row.get("name")]
        if not names:
            return "No one asleep to interrupt."
        for name in names:
            row = self._rest_row(name)
            if row["sleep"] > 0:
                row["sleep"] -= 1
            row["interrupted"] += 1
        self._refresh_watch_people()
        return "Rest interrupted: " + ", ".join(names)

    def watch_next_hour(self) -> None:
        hour = self._watch_num(self.watch_hour_var) + 1
        per = max(1, self._watch_num(self.watch_hours_per_var, 2))
        on = self.watch_on_var.get().strip() or "no one"
        if hour > per:
            self.watch_next_shift()
            return
        while len(self._watch_marks) < hour:
            self._watch_marks.append("open")
        self.watch_hour_var.set(str(hour))
        self._add_sleep()
        self._refresh_watch_marks()
        self.watch_status_var.set(f"Hour {hour} of {per} open. On watch: {on}.")
        self._log_watch(f"Hour {hour} of {per} — on watch: {on}")

    def watch_next_shift(self) -> None:
        current = self._watch_num(self.watch_shift_var, 1)
        total = max(1, self._watch_num(self.watch_shifts_var, 4))
        if current >= total:
            self.watch_status_var.set(f"Night complete. Shift {current} of {total}.")
            self._watch_auto = False
            return
        shift = current + 1
        self.watch_shift_var.set(str(shift))
        self.watch_hour_var.set("0")
        self._watch_marks = []
        self._watch_encounters = {}
        self._refresh_watch_people()
        night = self.watch_night_var.get().strip() or "Camp"
        self.watch_status_var.set(f"{night}: shift {shift} of {total}. Rest kept. Change who is on watch.")
        self._log_watch(f"Shift {shift} of {total}")

    def watch_roll(self) -> None:
        hour = self._watch_num(self.watch_hour_var)
        if hour < 1:
            self.watch_status_var.set("Start an hour before rolling.")
            return
        sides = max(2, self._watch_num(self.watch_chance_var, 6))
        roll = random.randint(1, sides)
        mark = "stirred" if roll == 1 else "checked"
        while len(self._watch_marks) < hour:
            self._watch_marks.append("open")
        self._watch_marks[hour - 1] = mark
        on = self.watch_on_var.get().strip() or "no one"
        found = ""
        interrupted = ""
        if mark == "stirred":
            found = self._watch_pick_monster()
            if not hasattr(self, "_watch_encounters"):
                self._watch_encounters = {}
            self._watch_encounters[hour] = found or "No monster"
            interrupted = self._interrupt_rest()
        word = found or ("Encounter" if mark == "stirred" else "Quiet")
        extra = f" {interrupted}" if interrupted else ""
        line = f"Hour {hour} {mark}. {word}. Rolled {roll} on 1d{sides}."
        if hasattr(self, "watch_encounter_var"):
            self.watch_encounter_var.set(line)
        self.watch_status_var.set(f"{line} On watch: {on}.{extra}")
        self._refresh_watch_marks()
        self._refresh_watch_marks()
        self._log_watch(f"Hour {hour} {mark} — {word} — rolled {roll} on 1d{sides}")

    def _watch_pick_monster(self) -> str:
        repo = self.repos.get("monster") if hasattr(self, "repos") else None
        if repo is None:
            return "No monster list"
        wanted = self.watch_type_var.get().strip() if hasattr(self, "watch_type_var") else "Any"
        matches = []
        for monster in repo.monsters():
            kind = (monster.details.creature_type or "").strip()
            if wanted and wanted != "Any" and kind.lower() != wanted.lower():
                continue
            use = (getattr(monster.details, "watch_use", "") or "Quest only").strip()
            if use not in ("Wandering", "Either"):
                continue
            cr = (monster.details.challenge_rating or "").strip() or "?"
            matches.append(f"{monster.record.name} · {kind or 'Unknown'} · CR {cr} · {use}")
        if not matches:
            return f"No {wanted.lower()} monsters marked Wandering"
        return random.choice(matches)

    def watch_start_auto(self) -> None:
        self._watch_auto = True
        seconds = max(5, self._watch_num(self.watch_seconds_var, 60))
        self.watch_status_var.set(f"Hours running. {seconds}s per hour.")
        self._watch_tick()

    def watch_pause_auto(self) -> None:
        self._watch_auto = False
        self.watch_status_var.set("Hours paused.")

    def _watch_tick(self) -> None:
        if not getattr(self, "_watch_auto", False):
            return
        self.watch_next_hour()
        seconds = max(5, self._watch_num(self.watch_seconds_var, 60))
        self.after(seconds * 1000, self._watch_tick)

    def watch_reset(self) -> None:
        self._watch_auto = False
        self.watch_shift_var.set("1")
        self.watch_hour_var.set("0")
        self._watch_marks = []
        self._watch_encounters = {}
        self._watch_sleep = {}
        for row in getattr(self, "_watch_roster", []):
            if isinstance(row, dict):
                row["recovered"] = False
                row["con_roll"] = ""
                row["role"] = "asleep"
        self._refresh_watch_people()
        self._refresh_watch_marks()
        self.watch_status_var.set("New night. Party and exhaustion kept.")
        self._log_watch("New night")

    def _log_watch(self, line: str) -> None:
        if hasattr(self, "status"):
            self.status.set(line)

    def show_beat(self, delta: int) -> None:
        try:
            self._scripts = self.repos["script"].scripts()
        except Exception:
            log_exception()
        scripts = getattr(self, "_scripts", [])
        idx = self.script_combo.current()
        if idx < 0 or idx >= len(scripts):
            return
        beats = list(scripts[idx].details.beats or [])
        if not beats:
            self.beat_var.set("No beats")
            return
        current_index = max(0, min(len(beats) - 1, getattr(self, "_beat_index", 0)))
        current = beats[current_index]
        if delta > 0:
            self.status.set(f"Next from beat {current_index + 1}")
            current._taken_minutes = self._beat_minutes(current)
            link = (getattr(current, "continue_to_id", "") or "").strip()
            jumped = False
            if link:
                for i, other in enumerate(beats):
                    if other.id == link or (other.title or "").strip().lower() == link.lower():
                        self._beat_index = i
                        jumped = True
                        break
            if not jumped and not getattr(current, "choices", None) and current_index + 1 < len(beats):
                self._beat_index = current_index + 1
                jumped = True
            if not jumped:
                if getattr(current, "choices", None):
                    self.status.set("Pick a choice. Next stays on this beat until a path is chosen.")
                    return
                try:
                    self._apply_beat_time(current)
                except Exception as exc:
                    self.status.set(f"Time was not added: {exc}")
                if self._open_next_script(scripts[idx]):
                    return
                self.status.set("End of this path.")
                return
            self._pending_time_beat = current
        elif delta < 0:
            self._beat_index = max(0, current_index - 1)
        else:
            self._beat_index = current_index
        self._beat_index = max(0, min(len(beats) - 1, self._beat_index))
        beat = beats[self._beat_index]
        script_name = scripts[idx].record.name
        if hasattr(self, "script_now_var"):
            self.script_now_var.set("Script: " + script_name)
        when = ""
        day = int(getattr(beat, "day_number", 0) or 0)
        tod = getattr(beat, "time_of_day", "") or ""
        if day or tod:
            when = " ".join(p for p in (f"Day {day}" if day else "", tod) if p) + " — "
        self.beat_var.set(f"Beat {self._beat_index + 1}/{len(beats)} — {when}{beat.title}")
        self.narration.delete("1.0", "end")
        self.narration.insert("1.0", beat.read_aloud or "")
        if hasattr(self, "gm_notes"):
            self.gm_notes.delete("1.0", "end")
            notes = beat.gm_notes or ""
            self.gm_notes.insert("1.0", notes)
        if hasattr(self, "dm_items_box"):
            self.dm_items_box.delete("1.0", "end")
            self.dm_items_box.insert("1.0", getattr(beat, "dm_items", "") or "")
        if hasattr(self, "quests_box"):
            self.quests_box.delete("1.0", "end")
            self.quests_box.insert("1.0", getattr(beat, "quests", "") or "")
        places = getattr(beat, "places", "") or ""
        if not places:
            places = self._places_from_script_file(scripts[idx], beat)
        if hasattr(self, "places_box"):
            self.places_box.delete("1.0", "end")
            self.places_box.insert("1.0", places or "(no places on this beat)")
        if places:
            self.beat_var.set(self.beat_var.get() + "  ·  " + places.splitlines()[0].split("|")[0].strip())
        if hasattr(self, "stage_note_body"):
            self.stage_note_body.delete("1.0", "end")
            self.stage_note_body.insert("1.0", getattr(beat, "table_notes", "") or "")
        self._show_beat_rest(beat)
        self._show_beat_advance(beat)
        self._show_beat_audio(beat)
        self._render_choices(beats, beat)
        try:
            self._save_ui_state()
        except Exception:
            log_exception()
        self.play_beat_music(silent=True)
        pending = getattr(self, "_pending_time_beat", None)
        self._pending_time_beat = None
        if pending is not None:
            try:
                self._apply_beat_time(pending)
            except Exception as exc:
                self.status.set(f"Beat moved. Time was not added: {exc}")


    def _render_choices(self, beats, beat) -> None:
        box = getattr(self, "choice_box", None)
        if box is None:
            return
        for child in box.winfo_children():
            child.destroy()
        choices = list(getattr(beat, "choices", []) or [])
        if not choices:
            ttk.Label(box, text="(no choices on this beat)").pack(anchor="w")
            return
        for choice in choices:
            label = (choice.text or "Choice").strip()
            target = (choice.to_beat_id or "").strip()
            dest = ""
            for other in beats:
                if other.id == target:
                    dest = other.title
                    break
            shown = label if not dest else f"{label}  →  {dest}"
            ttk.Button(
                box,
                text=shown,
                command=lambda c=choice: self.take_choice(c),
            ).pack(fill="x", pady=2)

    def take_choice(self, choice) -> None:
        scripts = getattr(self, "_scripts", [])
        idx = self.script_combo.current()
        if idx < 0 or idx >= len(scripts):
            return
        beats = list(scripts[idx].details.beats or [])
        target = (getattr(choice, "to_beat_id", "") or "").strip()
        note = (getattr(choice, "consequence", "") or "").strip()
        if note:
            self._tracker_log(f"Choice: {choice.text} — {note}")
        else:
            self._tracker_log(f"Choice: {choice.text}")
        if note and hasattr(self, "gm_notes"):
            extra = self.gm_notes.get("1.0", "end-1c")
            if note not in extra:
                self.gm_notes.insert("end", "\n\nChoice: " + note)
        if not target:
            return
        for i, beat in enumerate(beats):
            if beat.id == target:
                self._beat_index = i
                self.show_beat(0)
                return
        self.status.set("Choice has no matching beat")

    def mark_beat(self) -> None:
        scripts = getattr(self, "_scripts", [])
        idx = self.script_combo.current()
        if idx < 0 or idx >= len(scripts):
            return
        beats = list(scripts[idx].details.beats or [])
        if not beats:
            return
        self._beat_index = max(0, min(len(beats) - 1, getattr(self, "_beat_index", 0)))
        beat = beats[self._beat_index]
        def _lines(value) -> list[str]:
            if isinstance(value, list):
                return [str(x).strip() for x in value if str(x).strip()]
            return [ln.strip() for ln in str(value or "").replace("\r", "").splitlines() if ln.strip()]
        self.repos["tracker"].mark_beat_done(
            scripts[idx].record.record_id,
            beat.id,
            note=beat.title,
            items=_lines(getattr(beat, "items", "")),
            cast=_lines(getattr(beat, "cast", "") or getattr(beat, "people", "")),
            places=_lines(getattr(beat, "places", "") or self._places_from_script_file(scripts[idx], beat)),
        )
        self._tracker_log(f"Beat done: {beat.title}")
        self.refresh_log()
        self.show_beat(1)


    def set_chapter_volume(self, level: float) -> None:
        self.audio.set_volume(level)
        self.status.set(f"Chapter volume {int(level * 100)}%")
        path = getattr(self, "_music_playing", "")
        if path:
            try:
                self.audio.play(str(self._resolve_media_path(path)), loop=bool(getattr(self.audio, "_loop", True)))
            except Exception:
                log_exception()

    def music_off(self) -> None:
        self._auto_music = False
        try:
            self.audio.stop()
        except Exception:
            log_exception()
        self.status.set("Music off — beats will not start a track")

    def music_on(self) -> None:
        self._auto_music = True
        self.status.set("Music on — next beat can start its track")
        self.play_beat_music(silent=True)


    def _show_beat_audio(self, beat) -> None:
        box = getattr(self, "beat_audio_list", None)
        if box is None:
            return
        box.delete(0, "end")
        clips = list(getattr(beat, "audio_clips", []) or [])
        if not clips and getattr(beat, "music_path", ""):
            clips = [{"name": "Audio", "path": beat.music_path, "loop": bool(getattr(beat, "music_loop", False))}]
        self._beat_clips = clips
        self._beat_videos = [str(v) for v in (getattr(beat, "videos", []) or []) if v]
        if hasattr(self, "beat_video_button"):
            n = len(self._beat_videos)
            self.beat_video_button.configure(state="normal" if n else "disabled", text=f"▶ Video ({n})" if n > 1 else "▶ Video")
        for clip in clips:
            name = clip.get("name") or Path(clip.get("path") or "").name or "Audio"
            mark = "  (loop)" if clip.get("loop") else ""
            box.insert("end", name + mark)

    def _resolve_media_path(self, stored: str) -> Path:
        """Absolute if it exists; else project-relative; else filename under assets/audio|videos."""
        stored = (stored or "").strip()
        if not stored:
            return Path()
        path = Path(stored)
        try:
            if path.is_absolute() and path.is_file():
                return path
        except OSError:
            pass
        root = getattr(self.project, "root", None) if self.project is not None else None
        if root is None:
            assets = (getattr(self, "repos", None) or {}).get("assets")
            if assets is not None:
                root = assets.project.root
        if root is not None:
            joined = root / stored
            if joined.is_file():
                return joined
            # Split on / and \ so Windows paths still yield a filename on any OS
            name = stored.replace("\\", "/").rstrip("/").rsplit("/", 1)[-1].lower()
            if name:
                for folder in ("audio", "videos"):
                    base = root / "assets" / folder
                    if not base.is_dir():
                        continue
                    for hit in base.rglob("*"):
                        if hit.is_file() and hit.name.lower() == name:
                            return hit
        return path

    def _play_video(self, path) -> None:
        """Open a video in the default player (os.startfile). Relative paths are project-relative."""
        path = Path(path)
        if not path.is_absolute():
            assets = (getattr(self, "repos", None) or {}).get("assets")
            if assets is not None:
                path = assets.project.root / path
        try:
            if not path.is_file():
                raise FileNotFoundError(f"Cannot find {path}")
            os.startfile(str(path))
            self.status.set("Video: " + path.name)
        except Exception as err:
            log_exception()
            self.status.set(f"Could not play {path.name}: {err}")

    def play_beat_video(self) -> None:
        videos = getattr(self, "_beat_videos", []) or []
        if len(videos) == 1:
            self._play_video(videos[0])
        elif videos:
            menu = tk.Menu(self, tearoff=0)
            for rel in videos:
                menu.add_command(label=Path(rel).name, command=lambda r=rel: self._play_video(r))
            btn = self.beat_video_button
            menu.tk_popup(btn.winfo_rootx(), btn.winfo_rooty() + btn.winfo_height())

    def play_beat_clip(self) -> None:
        clips = getattr(self, "_beat_clips", []) or []
        sel = self.beat_audio_list.curselection() if hasattr(self, "beat_audio_list") else ()
        if not sel or sel[0] >= len(clips):
            self.status.set("Select a clip first.")
            return
        clip = clips[sel[0]]
        try:
            resolved = self._resolve_media_path(clip.get("path") or "")
            self.sfx.play(str(resolved), loop=bool(clip.get("loop")))
            self.status.set("Clip: " + (clip.get("name") or "Audio"))
        except Exception as err:
            self.status.set(str(err))

    def stop_beat_clip(self) -> None:
        self.sfx.stop()
        self.status.set("Clip stopped. Chapter music still playing.")

    def play_beat_music(self, silent: bool = False) -> None:
        scripts = getattr(self, "_scripts", [])
        idx = self.script_combo.current()
        if idx < 0 or idx >= len(scripts):
            return
        script = scripts[idx]
        beats = list(script.details.beats or [])
        beat = beats[self._beat_index] if beats else None
        beat_path = (getattr(beat, "music_path", "") or "").strip() if beat is not None else ""
        if beat_path:
            path = beat_path
            loop = bool(getattr(beat, "music_loop", False))
            label = "Beat music"
        else:
            path = (getattr(script.details, "music_path", "") or "").strip()
            loop = bool(getattr(script.details, "music_loop", True))
            label = "Chapter music"
        if not path:
            if not silent:
                messagebox.showinfo("Music", "No music on this beat or chapter.", parent=self)
            self.status.set("No music on this beat or chapter.")
            return
        file_path = self._resolve_media_path(path)
        if not file_path.is_file():
            if not silent:
                messagebox.showwarning("Music", f"{label} file not found:\n{path}", parent=self)
            self.status.set(f"{label} file not found.")
            return
        resolved = str(file_path)
        playing = getattr(self, "_music_playing", "")
        if playing == resolved and getattr(self.audio, "_loop", False) == loop:
            return
        try:
            self.audio.play(resolved, loop=loop)
            self._music_playing = resolved
            self.status.set(f"{label}: " + file_path.name)
        except Exception as err:
            if not silent:
                messagebox.showwarning("Music", str(err), parent=self)
            self.status.set(str(err))

    def roll_table(self) -> None:
        tables = getattr(self, "_tables", [])
        idx = self.table_combo.current()
        if idx < 0 or idx >= len(tables):
            return
        table = tables[idx]
        rolled = self.repos["table"].roll(table)
        if rolled is None:
            return
        pick, row = rolled
        text = f"1d{table.die}={pick} — no row" if row is None else f"1d{table.die}={pick} ({row.low}–{row.high}) {row.text}"
        self.table_result.set(text)
        self._tracker_log(f"Rolled {table.name}: {text}")

    def browse_sfx(self) -> None:
        path = filedialog.askopenfilename(parent=self, title="SFX", filetypes=[("Audio", "*.mp3 *.wav *.ogg"), ("All", "*.*")])
        if path:
            self.sfx_var.set(path)

    def play_sfx(self) -> None:
        path = self.sfx_var.get().strip()
        if path:
            try:
                self.audio.play(str(self._resolve_media_path(path)), loop=False)
            except Exception as err:
                messagebox.showwarning("SFX", str(err), parent=self)

    def _tracker_log(self, text: str) -> None:
        try:
            self.repos["tracker"].add_log(text)
        except Exception:
            log_exception()
        self.refresh_log()

    def refresh_log(self) -> None:
        self.log_box.delete("1.0", "end")
        try:
            state = self.repos["tracker"].load()
            lines = []
            for item in list(getattr(state, "log", []) or [])[-60:]:
                if isinstance(item, dict):
                    lines.append(str(item.get("text") or item))
                else:
                    lines.append(str(item))
            lines.reverse()
            for line in lines:
                start = self.log_box.index("end-1c")
                self.log_box.insert("end", line + "\n")
                end = self.log_box.index("end-1c")
                low = line.lower()
                if low.startswith("found:") or " | item |" in low:
                    self.log_box.tag_add("found", start, end)
                elif low.startswith("met:"):
                    self.log_box.tag_add("met", start, end)
                elif low.startswith("at:"):
                    self.log_box.tag_add("found", start, end)
                elif low.startswith("beat done") or low.startswith("completed "):
                    self.log_box.tag_add("beat", start, end)
            self.log_box.see("1.0")
        except Exception:
            log_exception()

    def push_tv(self) -> None:
        if self._tv is not None and self._tv.winfo_exists():
            self._draw_tv()
            self._tv.lift()
            return
        win = tk.Toplevel(self)
        win.title("Player TV")
        win.configure(bg="black")
        win.geometry("960x540")
        cv = tk.Canvas(win, bg="black", highlightthickness=0)
        cv.pack(fill="both", expand=True)
        win.bind("<Configure>", lambda _e: self._draw_tv())
        self._tv = win
        self._tv_canvas = cv
        self._draw_tv()


    def push_narration(self) -> None:
        text = self.narration.get("1.0", "end-1c").strip() if hasattr(self, "narration") else ""
        self._tv_text = text
        if self._tv is None or not self._tv.winfo_exists():
            self.push_tv()
        else:
            self._draw_tv()

    def clear_tv_text(self) -> None:
        self._tv_text = ""
        if self._tv is not None and self._tv.winfo_exists():
            self._draw_tv()

    def _draw_tv(self) -> None:
        if self._tv is None or not self._tv.winfo_exists():
            return
        ply = self._selected_player_map()
        self._paint_map(self._tv_canvas, "_tv_photo", ply, "player", tokens=True, fog=True, label_hp=False)
        text = getattr(self, "_tv_text", "") or ""
        if text:
            cv = self._tv_canvas
            w = max(cv.winfo_width(), 40)
            cv.create_rectangle(8, max(cv.winfo_height() - 160, 8), w - 8, cv.winfo_height() - 8, fill="#111", outline=GOLD)
            cv.create_text(20, max(cv.winfo_height() - 148, 16), anchor="nw", fill="white", width=w - 48, text=text)



    def stage_maximize(self) -> None:
        try:
            self.state("zoomed")
        except tk.TclError:
            try:
                self.attributes("-zoomed", True)
            except tk.TclError:
                pass
        data = self._read_ui()
        data["stage_maximized"] = True
        data["stage_fit"] = False
        self._ui_state().write_text(json.dumps(data, indent=2), encoding="utf-8")

    def stage_window(self, geometry: str) -> None:
        try:
            self.state("normal")
        except tk.TclError:
            pass
        self.geometry(geometry)
        data = self._read_ui()
        data["stage_maximized"] = False
        data["stage_fit"] = False
        data["stage_geometry"] = geometry
        self._ui_state().write_text(json.dumps(data, indent=2), encoding="utf-8")

    def stage_fit_screen(self, save: bool = True) -> None:
        """~95% of the actual screen, centred, not maximized, Large text."""
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = int(sw * 0.95), int(sh * 0.95)
        try:
            self.state("normal")
        except tk.TclError:
            pass
        self.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")
        self.set_text_size(13)
        if save:
            data = self._read_ui()
            data.update(stage_maximized=False, stage_fit=True, stage_geometry="")
            self._ui_state().write_text(json.dumps(data, indent=2), encoding="utf-8")

    def remember_stage_size(self) -> None:
        data = self._read_ui()
        data["stage_maximized"] = str(self.state()) == "zoomed"
        data["stage_fit"] = False
        data["stage_geometry"] = self.geometry()
        self._ui_state().write_text(json.dumps(data, indent=2), encoding="utf-8")
        self.status.set("Saved Stage window size")

    def _restore_stage_size(self) -> None:
        data = self._read_ui()
        if data.get("stage_fit"):
            self.stage_fit_screen(save=False)
            return
        if data.get("stage_maximized"):
            self.after(200, self.stage_maximize)
            return
        geom = data.get("stage_geometry") or ""
        if geom:
            try:
                self.geometry(geom)
            except tk.TclError:
                pass



    def close_stage(self) -> None:
        try:
            self._save_ui_state()
        except Exception:
            log_exception()
        try:
            self.audio.stop()
        except Exception:
            log_exception()
        try:
            pygame = getattr(self.audio, "_pygame", None)
            if pygame is not None:
                pygame.mixer.music.stop()
                pygame.mixer.quit()
        except Exception:
            log_exception()
        try:
            if getattr(self, "_tv", None) is not None and self._tv.winfo_exists():
                self._tv.destroy()
        except Exception:
            log_exception()
        self.destroy()

    def clear_story_log(self) -> None:
        if self.project is None:
            return
        if not messagebox.askyesno("Story tracker", "Clear the log text only? Items and people met stay.", parent=self):
            return
        state = self.repos["tracker"].load()
        state.log = []
        self.repos["tracker"].save(state)
        self.refresh_log()

    def reset_story_tracker(self) -> None:
        if self.project is None:
            return
        if not messagebox.askyesno("Story tracker", "Reset completed beats, items found, people met, and the log?", parent=self):
            return
        from core.story_tracker import StoryTrackerState
        self.repos["tracker"].save(StoryTrackerState())
        self.refresh_log()

    def open_roll_tables(self) -> None:
        if self.project is None:
            messagebox.showinfo("Tables", "Open a Forge folder first.", parent=self)
            return
        win = tk.Toplevel(self)
        win.title("Roll tables — DM only")
        win.geometry("520x280")
        win.configure(bg=BG)
        ttk.Label(win, text="Search tables").pack(anchor="w", padx=8, pady=(8, 0))
        search_var = tk.StringVar()
        search_entry = ttk.Entry(win, textvariable=search_var)
        search_entry.pack(fill="x", padx=8)
        ttk.Label(win, text="Table").pack(anchor="w", padx=8, pady=(8, 0))
        var = tk.StringVar()
        all_tables = list(self.repos["table"].tables())
        tables = list(all_tables)
        combo = ttk.Combobox(win, textvariable=var, state="readonly")
        combo.pack(fill="x", padx=8)

        def refill(_event=None):
            nonlocal tables
            query = search_var.get().strip().lower()
            tables = []
            for table in all_tables:
                row_text = " ".join(getattr(row, "text", "") or "" for row in (table.rows or []))
                hay = f"{table.name} {table.table_type} {getattr(table, 'notes', '')} {row_text}".lower()
                if query and query not in hay:
                    continue
                tables.append(table)
            combo["values"] = [f"{t.name} [{t.table_type}]" for t in tables] or ["(no match)"]
            if tables:
                combo.current(0)
            else:
                var.set("(no match)")

        search_var.trace_add("write", lambda *_: refill())
        refill()
        search_entry.focus_set()
        result = tk.StringVar(value="—")
        ttk.Label(win, textvariable=result, wraplength=480).pack(fill="x", padx=8, pady=8)

        def _path_for(table):
            rel = getattr(table, "image_path", "") or ""
            if not rel:
                return None
            path = Path(rel)
            if not path.is_file():
                path = self.project.root / rel
            return path if path.is_file() else None

        def do_roll():
            idx = combo.current()
            if idx < 0 or idx >= len(tables):
                return
            table = tables[idx]
            rolled = self.repos["table"].roll(table)
            if rolled is None:
                result.set("Could not roll")
                return
            pick, row = rolled
            text = f"1d{table.die}={pick} — no row" if row is None else f"1d{table.die}={pick} ({row.low}–{row.high}) {row.text}"
            result.set(text)
            self._tracker_log(f"Rolled {table.name}: {text}")
            img = _path_for(table)
            if img is not None:
                self._show_dm_handout(img, table.name)

        def show_sheet():
            idx = combo.current()
            if idx < 0 or idx >= len(tables):
                return
            img = _path_for(tables[idx])
            if img is None:
                messagebox.showinfo("Sheet", "No sheet image on this table. Add one in Library → Tables.", parent=win)
                return
            self._show_dm_handout(img, tables[idx].name)

        btns = ttk.Frame(win)
        btns.pack(fill="x", padx=8, pady=8)
        ttk.Button(btns, text="Roll", command=do_roll).pack(side="left")
        ttk.Button(btns, text="Open sheet (DM)", command=show_sheet).pack(side="left", padx=6)

    def _show_dm_handout(self, path: Path, title: str) -> None:
        win = getattr(self, "_handout", None)
        if win is None or not win.winfo_exists():
            win = tk.Toplevel(self)
            win.title("DM handout")
            win.configure(bg="#1a1c20")
            lbl = tk.Label(win, bg="#1a1c20")
            lbl.pack(fill="both", expand=True)
            self._handout = win
            self._handout_label = lbl
        self._handout.title("DM handout — " + title)
        if HAS_PIL:
            img = Image.open(path)
            img.thumbnail((1100, 900))
            self._handout_photo = ImageTk.PhotoImage(img)
            self._handout_label.configure(image=self._handout_photo, text="")
        else:
            self._handout_label.configure(text=str(path))
        self._handout.lift()


    def _best_srd(self, name: str):
        needle = (name or "").strip().lower()
        if len(needle) < 2:
            return None
        try:
            from core.reference import search
        except Exception:
            return None
        hits = search(needle, "All", limit=12)
        exact = [hit for hit in hits if hit.name.lower() == needle]
        if exact:
            return exact[0]
        starts = [hit for hit in hits if hit.name.lower().startswith(needle)]
        return starts[0] if starts else None

    def _popup_srd(self, hit) -> None:
        win = tk.Toplevel(self)
        win.title(f"SRD — {hit.name}")
        win.geometry("560x620")
        win.configure(bg=BG)
        bar = ttk.Frame(win)
        bar.pack(fill="x", padx=8, pady=6)
        ttk.Label(bar, text=f"{hit.kind}  ·  {hit.summary}").pack(side="left")
        ttk.Button(bar, text="Copy into campaign", command=lambda: self._copy_srd_hit(hit)).pack(side="right")
        txt = tk.Text(win, wrap="word", bg=PANEL, fg=FG, insertbackground=FG, padx=10, pady=8)
        txt.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        txt.insert("1.0", hit.body)
        txt.configure(state="disabled")

    def open_srd_lookup(self) -> None:
        win = tk.Toplevel(self)
        win.title("SRD lookup")
        win.geometry("760x560")
        win.configure(bg=BG)
        bar = ttk.Frame(win)
        bar.pack(fill="x", padx=8, pady=8)
        query = tk.StringVar()
        ttk.Entry(bar, textvariable=query, width=28).pack(side="left")
        kind = tk.StringVar(value="All")
        ttk.Combobox(
            bar, textvariable=kind, state="readonly", width=14,
            values=["All", "Monster", "Spell", "Condition", "Rule", "Gear", "Magic item"],
        ).pack(side="left", padx=6)
        ttk.Label(bar, text="CR").pack(side="left", padx=(8, 2))
        cr = tk.StringVar()
        ttk.Entry(bar, textvariable=cr, width=8).pack(side="left")
        body = tk.Text(win, wrap="word", height=8, bg=PANEL, fg=FG, insertbackground=FG, padx=8, pady=6)
        listing = tk.Listbox(win, height=12, bg=PANEL, fg=FG, exportselection=False)
        listing.pack(fill="both", expand=True, padx=8)
        body.pack(fill="both", expand=True, padx=8, pady=8)
        hits = []

        def refill(*_a):
            nonlocal hits
            try:
                from core.reference import search
                hits = search(query.get(), kind.get(), limit=1500, cr=cr.get())
            except Exception as exc:
                hits = []
                body.delete("1.0", "end")
                body.insert("1.0", f"Reference files not found next to Stage.\n{exc}")
                return
            listing.delete(0, "end")
            for hit in hits:
                listing.insert("end", f"{hit.name}  [{hit.kind}]  {hit.summary}")
            win.title(f"SRD lookup — {len(hits)}")
            if hits:
                listing.selection_set(0)
                show()

        def current():
            sel = listing.curselection()
            if not sel or sel[0] >= len(hits):
                return None
            return hits[sel[0]]

        def show(_e=None):
            hit = current()
            body.delete("1.0", "end")
            if hit is not None:
                body.insert("1.0", hit.body)

        def copy():
            hit = current()
            if hit is not None:
                self._copy_srd_hit(hit)

        ttk.Button(bar, text="Copy into campaign", command=copy).pack(side="right")
        query.trace_add("write", lambda *_: None)
        ttk.Button(bar, text="Search", command=refill).pack(side="left", padx=6)
        kind.trace_add("write", refill)
        cr.trace_add("write", refill)
        listing.bind("<<ListboxSelect>>", show)
        listing.bind("<Double-Button-1>", lambda _e: show())
        refill()

    def _copy_srd_hit(self, hit) -> None:
        if self.project is None:
            messagebox.showinfo("SRD", "Open a Forge folder first.", parent=self)
            return
        row = hit.raw or {}
        try:
            if hit.kind == "Monster":
                from core.reference import format_cr
                actions = row.get("actions") or []
                attack = ""
                if actions and isinstance(actions[0], dict):
                    attack = f"{actions[0].get('name')}: {actions[0].get('desc') or ''}"[:240]
                self.repos["monster"].create_monster(
                    hit.name,
                    str(row.get("type") or "Other").title(),
                    str(row.get("size") or "Medium").title(),
                    str(row.get("alignment") or "Unaligned"),
                    format_cr(row.get("challenge_rating")),
                    "Draft",
                    hit.body,
                    ac=str((row.get("armor_class") or [{}])[0].get("value") if isinstance((row.get("armor_class") or [None])[0], dict) else ""),
                    hp=str(row.get("hit_points") or ""),
                    max_hp=str(row.get("hit_points") or ""),
                    attack=attack,
                    extra={"stat_block": hit.body, "xp": str(row.get("xp") or "")},
                )
                where = "Monsters"
            elif hit.kind == "Spell":
                from core.records import RecordRepository
                from core.spells import SpellRepository
                level = row.get("level")
                level_label = "Cantrip" if level in (0, "0") else {1: "1st", 2: "2nd", 3: "3rd"}.get(level, f"{level}th")
                school = (row.get("school") or {}).get("name") if isinstance(row.get("school"), dict) else "Other"
                SpellRepository(self.project, RecordRepository(self.project)).create_spell(
                    hit.name, str(school or "Other"), level_label,
                    str(row.get("casting_time") or "1 Action").title(),
                    str(row.get("range") or "Self"),
                    ", ".join(row.get("components") or []),
                    str(row.get("duration") or "Instantaneous"),
                    "Yes" if row.get("ritual") else "No",
                    "Yes" if row.get("concentration") else "No",
                    "Draft", hit.body,
                )
                where = "Spells"
            elif hit.kind == "Gear":
                cost = row.get("cost") or {}
                value = f"{cost.get('quantity')} {cost.get('unit')}" if isinstance(cost, dict) and cost.get("quantity") is not None else ""
                cat = (row.get("equipment_category") or {}).get("name") if isinstance(row.get("equipment_category"), dict) else "Equipment"
                self.repos["item"].create_item(
                    hit.name, "Equipment", str(cat or ""), "Common", "1", value,
                    str(row.get("weight") or ""), "No", "Draft", hit.body,
                )
                where = "Items"
            elif hit.kind == "Magic item":
                from core.artifacts import ArtifactRepository
                from core.records import RecordRepository
                rarity = (row.get("rarity") or {}).get("name") if isinstance(row.get("rarity"), dict) else "Unique"
                attune = "Yes" if "attunement" in hit.body.lower() else "No"
                ArtifactRepository(self.project, RecordRepository(self.project)).create_artifact(
                    hit.name, "Wondrous Item", str(rarity or "Unique"), attune, "SRD", hit.body, "Draft", hit.body,
                )
                where = "Artifacts"
            else:
                from core.notes import CampaignNote, new_note_id
                self.repos["notes"].save(CampaignNote(note_id=new_note_id(), title=f"SRD: {hit.name}", body=hit.body))
                where = "Notes"
        except Exception as exc:
            messagebox.showerror("SRD", f"Could not copy: {exc}", parent=self)
            return
        self.status.set(f"Copied {hit.name} into {where}.")


    def open_pdf_tool(self) -> None:
        picked = filedialog.askopenfilename(title="Open PDF", filetypes=[("PDF", "*.pdf"), ("All files", "*.*")])
        if not picked:
            return
        self._open_pdf_outside(Path(picked))

    def _open_pdf_outside(self, path: Path) -> None:
        if not path.is_file():
            messagebox.showerror("Open PDF", f"Cannot find {path}", parent=self)
            return
        try:
            os.startfile(path)
        except OSError as exc:
            messagebox.showerror("Open PDF", f"Could not open {path.name}.\n{exc}", parent=self)
            return
        self.status.set(f"Opened {path.name} in the default PDF viewer.")

def main() -> None:
    try:
        ForgeStage().mainloop()
    except Exception:
        Path(__file__).resolve().parent.joinpath("forge_stage_crash.log").write_text(traceback.format_exc(), encoding="utf-8")
        raise


if __name__ == "__main__":
    main()
