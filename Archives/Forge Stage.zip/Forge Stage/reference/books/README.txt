Drop your Towns & Villages PDF in this folder, or use Choose PDF inside Forge.
Forge does not ship the book.
