@echo off
cd /d "%~dp0"
where pyw >nul 2>&1 && start "" pyw -3 forge_stage.py && goto done
where pythonw >nul 2>&1 && start "" pythonw forge_stage.py && goto done
where py >nul 2>&1 && start "" py -3 forge_stage.py && goto done
where python >nul 2>&1 && start "" python forge_stage.py && goto done
echo Python not found. Install Python and try again.
pause
exit /b 1
:done
