"""Location-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


LOCATION_ARCHETYPES = (
    "Settlement",
    "District",
    "Building",
    "Landmark",
    "Wilderness",
    "Dungeon",
    "Region",
    "Other",
)


@dataclass(frozen=True)
class LocationDetails:
    record_id: str
    archetype: str = "Settlement"
    location_type: str = ""
    region: str = ""


@dataclass(frozen=True)
class ForgeNextLocation:
    record: ForgeNextRecord
    details: LocationDetails


class LocationRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "locations.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def locations(self) -> list[ForgeNextLocation]:
        records = {record.record_id: record for record in self.records.records() if record.record_type == "Location"}
        details_by_id = {row.get("record_id", ""): LocationDetails(**row) for row in self._read()}
        return [
            ForgeNextLocation(record, details_by_id.get(record.record_id, LocationDetails(record.record_id)))
            for record in records.values()
        ]

    def create_location(
        self,
        name: str,
        archetype: str,
        location_type: str,
        region: str,
        status: str,
        description: str,
    ) -> ForgeNextLocation:
        record = self.records.create_record("Location", name, status, description)
        details = LocationDetails(record.record_id, archetype or "Other", location_type.strip(), region.strip())
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextLocation(record, details)

    def update_location(
        self,
        record_id: str,
        name: str,
        archetype: str,
        location_type: str,
        region: str,
        status: str,
        description: str,
    ) -> ForgeNextLocation:
        record = self.records.update_record(record_id, name, status, description)
        details = LocationDetails(record_id, archetype or "Other", location_type.strip(), region.strip())
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextLocation(record, details)
