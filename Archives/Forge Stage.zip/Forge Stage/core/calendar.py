"""Per-campaign calendar. Harptos is the preset. Custom months are allowed."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from .projects import ForgeNextProject

HARPTOS_MONTHS = (
    ("Hammer", 30, "Winter"),
    ("Alturiak", 30, "Winter"),
    ("Ches", 30, "Spring"),
    ("Tarsakh", 30, "Spring"),
    ("Mirtul", 30, "Spring"),
    ("Kythorn", 30, "Summer"),
    ("Flamerule", 30, "Summer"),
    ("Eleasis", 30, "Summer"),
    ("Eleint", 30, "Autumn"),
    ("Marpenoth", 30, "Autumn"),
    ("Uktar", 30, "Autumn"),
    ("Nightal", 30, "Winter"),
)
HARPTOS_HOLIDAYS = (
    {"name": "Midwinter", "after_month": 0},
    {"name": "Greengrass", "after_month": 2},
    {"name": "Midsummer", "after_month": 5},
    {"name": "Highharvestide", "after_month": 8},
    {"name": "Feast of the Moon", "after_month": 10},
)
HARPTOS_WEEK = ("1st-day", "2nd-day", "3rd-day", "4th-day", "5th-day", "6th-day", "7th-day", "8th-day", "9th-day", "10th-day")


def harptos() -> dict:
    return {
        "name": "Calendar of Harptos",
        "era": "DR",
        "weekdays": list(HARPTOS_WEEK),
        "months": [{"name": n, "days": d, "season": s} for n, d, s in HARPTOS_MONTHS],
        "holidays": [dict(row) for row in HARPTOS_HOLIDAYS],
    }


@dataclass
class CampaignCalendar:
    name: str = "Calendar of Harptos"
    era: str = "DR"
    weekdays: list = field(default_factory=list)
    months: list = field(default_factory=list)
    holidays: list = field(default_factory=list)
    start: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "era": self.era,
            "weekdays": list(self.weekdays),
            "months": list(self.months),
            "holidays": list(self.holidays),
            "start": dict(self.start or {}),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "CampaignCalendar":
        if not isinstance(data, dict) or not data.get("months"):
            data = harptos()
        return cls(
            name=str(data.get("name") or "Calendar"),
            era=str(data.get("era") or ""),
            weekdays=[str(x) for x in (data.get("weekdays") or [])],
            months=[dict(x) for x in data.get("months") or []],
            holidays=[dict(x) for x in data.get("holidays") or []],
            start=dict(data.get("start") or {}),
        )

    def month_names(self) -> list[str]:
        return [str(m.get("name") or f"Month {i+1}") for i, m in enumerate(self.months)]

    def month_length(self, index: int) -> int:
        if not self.months:
            return 30
        row = self.months[index % len(self.months)]
        try:
            return max(1, int(row.get("days") or 30))
        except (TypeError, ValueError):
            return 30

    def season_for(self, index: int, festival: str = "") -> str:
        if not self.months:
            return ""
        row = self.months[index % len(self.months)]
        return str(row.get("season") or "")

    def holiday_after(self, index: int) -> str:
        for row in self.holidays:
            try:
                if int(row.get("after_month", -1)) == index and not row.get("month"):
                    return str(row.get("name") or "")
            except (TypeError, ValueError):
                continue
        return ""


class CalendarRepository:
    def __init__(self, project: ForgeNextProject) -> None:
        self.path = project.root / "data" / "calendar.json"

    def load(self) -> CampaignCalendar:
        if not self.path.exists():
            return CampaignCalendar.from_dict(harptos())
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError):
            return CampaignCalendar.from_dict(harptos())
        return CampaignCalendar.from_dict(data if isinstance(data, dict) else {})

    def save(self, calendar: CampaignCalendar) -> CampaignCalendar:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(json.dumps(calendar.to_dict(), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        temporary.replace(self.path)
        return calendar
