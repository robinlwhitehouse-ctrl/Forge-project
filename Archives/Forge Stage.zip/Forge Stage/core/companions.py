"""Companions — familiars, animal companions, sidekicks, mounts."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


COMPANION_TYPES = (
    "Animal Companion",
    "Familiar",
    "Sidekick",
    "Mount",
    "Hireling",
    "Summon",
    "Other",
)


@dataclass(frozen=True)
class CompanionDetails:
    record_id: str
    companion_type: str = "Animal Companion"
    linked_pc: str = ""
    size: str = "Medium"
    creature_type: str = "Beast"
    ac: str = ""
    hp: str = ""
    max_hp: str = ""
    attack: str = ""
    stat_block: str = ""


def _details_from_row(row: dict) -> CompanionDetails:
    return CompanionDetails(
        record_id=str(row.get("record_id", "") or ""),
        companion_type=str(row.get("companion_type", "Animal Companion") or "Animal Companion"),
        linked_pc=str(row.get("linked_pc", "") or ""),
        size=str(row.get("size", "Medium") or "Medium"),
        creature_type=str(row.get("creature_type", "Beast") or "Beast"),
        ac=str(row.get("ac", "") or ""),
        hp=str(row.get("hp", "") or ""),
        max_hp=str(row.get("max_hp", "") or ""),
        attack=str(row.get("attack", "") or ""),
        stat_block=str(row.get("stat_block", "") or ""),
    )


@dataclass(frozen=True)
class ForgeNextCompanion:
    record: ForgeNextRecord
    details: CompanionDetails


class CompanionRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "companions.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def companions(self) -> list[ForgeNextCompanion]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Companion"
        }
        details_by_id = {
            str(row.get("record_id", "")): _details_from_row(row)
            for row in self._read()
            if isinstance(row, dict)
        }
        return [
            ForgeNextCompanion(
                record,
                details_by_id.get(record.record_id, CompanionDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_companion(
        self,
        name: str,
        companion_type: str,
        linked_pc: str,
        size: str,
        creature_type: str,
        ac: str,
        hp: str,
        max_hp: str,
        attack: str,
        stat_block: str,
        status: str,
        description: str,
    ) -> ForgeNextCompanion:
        record = self.records.create_record("Companion", name, status, description)
        details = CompanionDetails(
            record.record_id,
            companion_type or "Animal Companion",
            linked_pc.strip(),
            size or "Medium",
            creature_type or "Beast",
            ac.strip(),
            hp.strip(),
            max_hp.strip(),
            attack.strip(),
            stat_block.strip(),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextCompanion(record, details)

    def update_companion(
        self,
        record_id: str,
        name: str,
        companion_type: str,
        linked_pc: str,
        size: str,
        creature_type: str,
        ac: str,
        hp: str,
        max_hp: str,
        attack: str,
        stat_block: str,
        status: str,
        description: str,
    ) -> ForgeNextCompanion:
        record = self.records.update_record(record_id, name, status, description)
        details = CompanionDetails(
            record_id,
            companion_type or "Animal Companion",
            linked_pc.strip(),
            size or "Medium",
            creature_type or "Beast",
            ac.strip(),
            hp.strip(),
            max_hp.strip(),
            attack.strip(),
            stat_block.strip(),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextCompanion(record, details)
