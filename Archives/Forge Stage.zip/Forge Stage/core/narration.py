"""Local OpenAI-compatible narration (LM Studio / Bionic runtime).

Default mode: grounded rewrite — polish the GM's existing text only.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass


DEFAULT_BASE_URL = "http://127.0.0.1:1234/v1"
DEFAULT_MODEL = ""


@dataclass
class NarrationSettings:
    base_url: str = DEFAULT_BASE_URL
    model: str = DEFAULT_MODEL
    temperature: float = 0.55
    max_tokens: int = 500


def _normalize_base(url: str) -> str:
    url = (url or DEFAULT_BASE_URL).strip().rstrip("/")
    if not url.endswith("/v1"):
        if url.endswith("/v1/"):
            url = url.rstrip("/")
        else:
            url = url + "/v1"
    return url


def list_models(settings: NarrationSettings, timeout: float = 5.0) -> list[str]:
    base = _normalize_base(settings.base_url)
    req = urllib.request.Request(
        base + "/models",
        headers={"Accept": "application/json"},
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    models = []
    for row in data.get("data") or []:
        mid = row.get("id")
        if mid:
            models.append(str(mid))
    return models


def _chat(settings: NarrationSettings, system: str, user: str, timeout: float = 120.0) -> str:
    base = _normalize_base(settings.base_url)
    body: dict = {
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": float(settings.temperature),
        "max_tokens": int(settings.max_tokens),
        "stream": False,
    }
    if (settings.model or "").strip():
        body["model"] = settings.model.strip()

    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        base + "/chat/completions",
        data=data,
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as err:
        raise RuntimeError(
            f"Cannot reach local AI at {base}.\n"
            "Start LM Studio, load a model, enable the local server "
            f"(default {DEFAULT_BASE_URL}).\n\n{err}"
        ) from err

    choices = payload.get("choices") or []
    if not choices:
        raise RuntimeError("Local AI returned no choices.")
    message = choices[0].get("message") or {}
    content = (message.get("content") or "").strip()
    if not content:
        content = str(choices[0].get("text") or "").strip()
    if not content:
        raise RuntimeError("Local AI returned empty text.")
    return content


def generate_read_aloud(
    settings: NarrationSettings,
    *,
    beat_title: str,
    summary: str = "",
    quest_name: str = "",
    session_name: str = "",
    gm_notes: str = "",
    existing_text: str = "",
    prior_beats: str = "",
    timeout: float = 120.0,
) -> str:
    """Grounded rewrite: polish the GM's text; do not invent plot."""
    source = (existing_text or "").strip()
    notes = (gm_notes or "").strip()
    if not source and not notes:
        raise RuntimeError(
            "Grounded rewrite needs something to work from.\n\n"
            "Write a rough read-aloud draft and/or GM notes for this beat, "
            "then try again."
        )

    system = (
        "You are a tabletop RPG editor, not a story inventor.\n"
        "Your only job is a GROUNDED REWRITE of the Game Master's material "
        "into polished player-facing read-aloud narration.\n\n"
        "STRICT RULES:\n"
        "1. Use ONLY facts, names, places, and events present in the SOURCE TEXT "
        "and GM NOTES. Do not invent new NPCs, locations, monsters, items, or plot twists.\n"
        "2. Do not resolve the scene or decide what the players do next.\n"
        "3. Do not address the GM. Do not list choices or ask questions.\n"
        "4. Keep the same situation and outcome implications as the source.\n"
        "5. You may improve clarity, flow, sensory detail, and spoken rhythm.\n"
        "6. Prefer 1-3 short paragraphs. No markdown headings. No bullet lists.\n"
        "7. If the source is sparse, stay sparse — do not pad with new plot."
    )

    parts = [f"Beat title: {beat_title or 'Untitled beat'}"]
    if quest_name:
        parts.append(
            f"Linked quest (context only — do not expand beyond source): {quest_name}"
        )
    if session_name:
        parts.append(f"Linked session (context only): {session_name}")
    if summary:
        parts.append(
            "Script summary (context only — do not invent beyond source):\n" + summary
        )
    if prior_beats:
        parts.append(
            "Prior beat text (continuity only — do not retell or add new events):\n"
            + prior_beats.strip()
        )
    if notes:
        parts.append(
            "GM NOTES (guidance; do not reveal pure secrets as player text unless "
            "already implied by the source):\n" + notes
        )
    if source:
        parts.append("SOURCE TEXT to rewrite (authoritative):\n" + source)
    else:
        parts.append(
            "No read-aloud draft yet. Rewrite ONLY the player-safe implications "
            "of the GM NOTES into short read-aloud text. Invent nothing extra."
        )
    parts.append(
        "Rewrite the source into polished read-aloud narration. "
        "Output only the narration."
    )

    return _chat(settings, system, "\n\n".join(parts), timeout=timeout)
