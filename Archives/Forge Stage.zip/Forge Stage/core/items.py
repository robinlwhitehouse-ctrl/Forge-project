"""Item-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


ITEM_CATEGORIES = (
    "Equipment", "Consumable", "Wondrous Item", "Container",
    "Tool", "Treasure", "Other",
)
ITEM_RARITIES = (
    "Common", "Uncommon", "Rare", "Very Rare",
    "Legendary", "Artifact",
)


@dataclass(frozen=True)
class ItemDetails:
    record_id: str
    category: str = "Equipment"
    item_type: str = ""
    rarity: str = "Common"
    quantity: str = "1"
    value: str = ""
    weight: str = ""
    requires_attunement: str = "No"


@dataclass(frozen=True)
class ForgeNextItem:
    record: ForgeNextRecord
    details: ItemDetails


class ItemRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "items.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def items(self) -> list[ForgeNextItem]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Item"
        }
        details_by_id = {
            row.get("record_id", ""): ItemDetails(**row)
            for row in self._read()
        }
        return [
            ForgeNextItem(
                record,
                details_by_id.get(record.record_id, ItemDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_item(
        self, name: str, category: str, item_type: str, rarity: str,
        quantity: str, value: str, weight: str, requires_attunement: str,
        status: str, description: str,
    ) -> ForgeNextItem:
        record = self.records.create_record("Item", name, status, description)
        details = ItemDetails(
            record.record_id, category or "Equipment", item_type.strip(),
            rarity or "Common", quantity.strip() or "1", value.strip(),
            weight.strip(), requires_attunement or "No",
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextItem(record, details)

    def update_item(
        self, record_id: str, name: str, category: str, item_type: str,
        rarity: str, quantity: str, value: str, weight: str,
        requires_attunement: str, status: str, description: str,
    ) -> ForgeNextItem:
        record = self.records.update_record(record_id, name, status, description)
        details = ItemDetails(
            record_id, category or "Equipment", item_type.strip(),
            rarity or "Common", quantity.strip() or "1", value.strip(),
            weight.strip(), requires_attunement or "No",
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextItem(record, details)
