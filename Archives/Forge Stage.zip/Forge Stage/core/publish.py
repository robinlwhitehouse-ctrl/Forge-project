"""Publish Forge Next projects as player handouts, session briefs, or DM packets."""

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
import json
from pathlib import Path

from .projects import ForgeNextProject
from .records import DETAIL_FILES, RECORD_TYPES, ForgeNextRecord, RecordRepository


# Types players are usually allowed to see
PLAYER_TYPES = (
    "Location", "NPC", "Map", "Faction", "Item", "Artifact",
    "Player Character", "Spell", "Weapon", "Armor",
)

# Types useful in a session brief when linked
SESSION_BRIEF_TYPES = RECORD_TYPES


def _now_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d_%H%M%S")


def _safe_filename(value: str) -> str:
    cleaned = "".join(ch if ch.isalnum() or ch in ("-", "_", " ") else "_" for ch in value)
    return cleaned.strip().replace(" ", "_") or "export"


class ProjectPublisher:
    """Write player handouts, session briefs, and DM packets into exports/."""

    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)

    # ---- public entry points -------------------------------------------------

    def publish_player_handout(self, formats: list[str] | None = None) -> Path:
        """Spoiler-safe packet: player-facing types, no Draft/Archived."""
        return self._publish(
            mode="player_handout",
            title=f"{self.project.name} — Player Handout",
            include_types=list(PLAYER_TYPES),
            exclude_statuses=["draft", "archived"],
            formats=formats,
            folder_prefix="player_handout",
            intro=(
                "Player-facing reference for this campaign. "
                "Draft and archived records are omitted."
            ),
        )

    def publish_session_brief(self, session_id: str, formats: list[str] | None = None) -> Path:
        """One session plus every record connected to it (direct links)."""
        sessions = [
            record for record in self.records.records()
            if record.record_type == "Session" and record.record_id == session_id
        ]
        if not sessions:
            raise ValueError("That session no longer exists.")
        session = sessions[0]

        linked_ids = {session_id}
        for link in self.records.links_for(session_id):
            linked_ids.add(link.source_id)
            linked_ids.add(link.target_id)

        return self._publish(
            mode="session_brief",
            title=f"Session Brief — {session.name}",
            include_ids=linked_ids,
            formats=formats,
            folder_prefix=f"session_{_safe_filename(session.name)}",
            intro=(
                f"Prep packet for **{session.name}**. "
                "Includes the session and every record linked to it."
            ),
            focus_record_id=session_id,
        )

    def publish_dm_packet(self, formats: list[str] | None = None, active_only: bool = False) -> Path:
        """Full DM binder: all types, optionally excluding Draft/Archived."""
        exclude = ["draft", "archived"] if active_only else []
        return self._publish(
            mode="dm_packet",
            title=f"{self.project.name} — DM Packet",
            include_types=list(RECORD_TYPES),
            exclude_statuses=exclude,
            formats=formats,
            folder_prefix="dm_packet",
            intro=(
                "Dungeon Master reference for the full campaign. "
                + ("Draft and archived records are omitted." if active_only else "All statuses included.")
            ),
        )

    def export(
        self,
        *,
        include_types: list[str] | None = None,
        exclude_statuses: list[str] | None = None,
        formats: list[str] | None = None,
        folder_name: str | None = None,
    ) -> Path:
        """Generic snapshot (kept for compatibility)."""
        return self._publish(
            mode="snapshot",
            title=f"{self.project.name} — Export",
            include_types=include_types or list(RECORD_TYPES),
            exclude_statuses=exclude_statuses or [],
            formats=formats,
            folder_prefix="export",
            folder_name=folder_name,
            intro="Project snapshot exported from Forge Next.",
        )

    # ---- core writer ---------------------------------------------------------

    def _publish(
        self,
        *,
        mode: str,
        title: str,
        include_types: list[str] | None = None,
        include_ids: set[str] | None = None,
        exclude_statuses: list[str] | None = None,
        formats: list[str] | None = None,
        folder_prefix: str = "export",
        folder_name: str | None = None,
        intro: str = "",
        focus_record_id: str | None = None,
    ) -> Path:
        formats = formats or ["markdown", "json"]
        exclude_statuses = [status.lower() for status in (exclude_statuses or [])]
        type_filter = set(include_types) if include_types else set(RECORD_TYPES)

        all_records = []
        for record in self.records.records():
            if include_ids is not None and record.record_id not in include_ids:
                continue
            if include_ids is None and record.record_type not in type_filter:
                continue
            if record.status.lower() in exclude_statuses:
                continue
            all_records.append(record)

        record_ids = {record.record_id for record in all_records}
        links = [
            link for link in self.records.links()
            if link.source_id in record_ids and link.target_id in record_ids
        ]
        details = self._load_details(record_ids)

        stamp = folder_name or f"{folder_prefix}_{_now_stamp()}"
        export_root = self.project.root / "exports" / stamp
        export_root.mkdir(parents=True, exist_ok=True)

        if "json" in formats:
            self._write_json(export_root, mode, title, all_records, links, details)
        if "markdown" in formats:
            self._write_markdown(
                export_root, title, intro, all_records, links, details, focus_record_id
            )
        if "pdf" in formats:
            self._write_pdf(
                export_root, title, intro, all_records, links, details, focus_record_id
            )

        return export_root

    def _load_details(self, record_ids: set[str]) -> dict[str, dict]:
        details: dict[str, dict] = {}
        for filename in DETAIL_FILES.values():
            path = self.project.root / "data" / "records" / filename
            if not path.exists():
                continue
            try:
                rows = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError, json.JSONDecodeError):
                continue
            if not isinstance(rows, list):
                continue
            for row in rows:
                record_id = row.get("record_id")
                if record_id in record_ids:
                    details[record_id] = row
        return details

    def _write_json(
        self,
        export_root: Path,
        mode: str,
        title: str,
        records: list[ForgeNextRecord],
        links: list,
        details: dict[str, dict],
    ) -> None:
        payload = {
            "format": "forge-next-publish",
            "format_version": 2,
            "mode": mode,
            "title": title,
            "project": {
                "name": self.project.name,
                "project_id": self.project.project_id,
            },
            "exported_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
            "records": [asdict(record) for record in records],
            "details": details,
            "relationships": [asdict(link) for link in links],
        }
        (export_root / "project_export.json").write_text(
            json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def _write_markdown(
        self,
        export_root: Path,
        title: str,
        intro: str,
        records: list[ForgeNextRecord],
        links: list,
        details: dict[str, dict],
        focus_record_id: str | None,
    ) -> None:
        by_type: dict[str, list[ForgeNextRecord]] = {record_type: [] for record_type in RECORD_TYPES}
        for record in records:
            by_type.setdefault(record.record_type, []).append(record)

        names = {record.record_id: record.name for record in records}
        types = {record.record_id: record.record_type for record in records}

        readme = [
            f"# {title}",
            "",
            f"Published from **Forge Next** on "
            f"`{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}`.",
            "",
        ]
        if intro:
            readme.extend([intro, ""])

        if focus_record_id:
            focus = next((r for r in records if r.record_id == focus_record_id), None)
            if focus is not None:
                readme.extend(["## Focus", "", f"**{focus.name}** ({focus.record_type})", ""])
                if focus.description.strip():
                    readme.extend([focus.description.strip(), ""])
                detail = details.get(focus.record_id, {})
                for key, value in detail.items():
                    if key == "record_id" or value in ("", None):
                        continue
                    readme.append(f"- **{key.replace('_', ' ').title()}:** {value}")
                readme.append("")

        readme.extend(["## Contents", ""])
        for record_type in RECORD_TYPES:
            items = by_type.get(record_type) or []
            if not items:
                continue
            # Skip writing a separate file for the focus session if it's the only purpose
            filename = f"{_safe_filename(record_type.lower())}.md"
            readme.append(f"- [{record_type}s]({filename}) ({len(items)})")
            self._write_type_markdown(export_root / filename, record_type, items, details)

        readme.extend(["", f"- [Relationships](relationships.md) ({len(links)})", ""])
        (export_root / "README.md").write_text("\n".join(readme) + "\n", encoding="utf-8")

        rel_lines = [f"# Relationships — {self.project.name}", ""]
        if not links:
            rel_lines.append("_No relationships in this packet._")
        else:
            for link in links:
                source = names.get(link.source_id, link.source_id)
                target = names.get(link.target_id, link.target_id)
                source_type = types.get(link.source_id, "?")
                target_type = types.get(link.target_id, "?")
                rel_lines.append(
                    f"- **{source}** [{source_type}] — *{link.relationship}* → "
                    f"**{target}** [{target_type}]"
                )
            rel_lines.append("")
        (export_root / "relationships.md").write_text(
            "\n".join(rel_lines) + "\n", encoding="utf-8"
        )

    def _write_type_markdown(
        self,
        path: Path,
        record_type: str,
        records: list[ForgeNextRecord],
        details: dict[str, dict],
    ) -> None:
        lines = [f"# {record_type}s", ""]
        for record in sorted(records, key=lambda item: item.name.casefold()):
            lines.append(f"## {record.name}")
            lines.append("")
            lines.append(f"- **ID:** `{record.record_id}`")
            lines.append(f"- **Status:** {record.status}")
            detail = details.get(record.record_id, {})
            for key, value in detail.items():
                if key == "record_id" or value in ("", None):
                    continue
                lines.append(f"- **{key.replace('_', ' ').title()}:** {value}")
            if record.description.strip():
                lines.append("")
                lines.append(record.description.strip())
            lines.append("")
            lines.append("---")
            lines.append("")
        path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")

    def _write_pdf(
        self,
        export_root: Path,
        title: str,
        intro: str,
        records: list[ForgeNextRecord],
        links: list,
        details: dict[str, dict],
        focus_record_id: str | None,
    ) -> None:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import inch
        from reportlab.platypus import (
            Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, PageBreak,
        )
        from reportlab.lib import colors

        path = export_root / "packet.pdf"
        doc = SimpleDocTemplate(
            str(path),
            pagesize=letter,
            leftMargin=0.75 * inch,
            rightMargin=0.75 * inch,
            topMargin=0.7 * inch,
            bottomMargin=0.7 * inch,
            title=title,
            author="Forge Next",
        )
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(
            name="CoverTitle", parent=styles["Title"], fontSize=22, spaceAfter=12,
        ))
        styles.add(ParagraphStyle(
            name="Section", parent=styles["Heading1"], fontSize=16, spaceBefore=16, spaceAfter=8,
            textColor=colors.HexColor("#3a2f1a"),
        ))
        styles.add(ParagraphStyle(
            name="RecordTitle", parent=styles["Heading2"], fontSize=12, spaceBefore=10, spaceAfter=4,
        ))
        styles.add(ParagraphStyle(
            name="BodyText2", parent=styles["BodyText"], fontSize=10, leading=13, spaceAfter=4,
        ))
        styles.add(ParagraphStyle(
            name="Meta", parent=styles["BodyText"], fontSize=9, textColor=colors.HexColor("#444444"),
            spaceAfter=2,
        ))

        def esc(text: str) -> str:
            return (
                str(text)
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
            )

        story: list = []
        story.append(Paragraph(esc(title), styles["CoverTitle"]))
        story.append(Paragraph(
            f"Published from Forge Next on "
            f"{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
            styles["Meta"],
        ))
        if intro:
            story.append(Spacer(1, 8))
            story.append(Paragraph(esc(intro), styles["BodyText2"]))
        story.append(Spacer(1, 12))

        by_type: dict[str, list[ForgeNextRecord]] = {t: [] for t in RECORD_TYPES}
        for record in records:
            by_type.setdefault(record.record_type, []).append(record)

        # Contents
        story.append(Paragraph("Contents", styles["Section"]))
        for record_type in RECORD_TYPES:
            items = by_type.get(record_type) or []
            if items:
                story.append(Paragraph(
                    f"• {esc(record_type)}s ({len(items)})", styles["BodyText2"]
                ))
        story.append(Paragraph(f"• Relationships ({len(links)})", styles["BodyText2"]))
        story.append(PageBreak())

        if focus_record_id:
            focus = next((r for r in records if r.record_id == focus_record_id), None)
            if focus is not None:
                story.append(Paragraph("Focus", styles["Section"]))
                story.append(Paragraph(esc(focus.name), styles["RecordTitle"]))
                story.append(Paragraph(
                    f"{esc(focus.record_type)} · {esc(focus.status)} · {esc(focus.record_id)}",
                    styles["Meta"],
                ))
                detail = details.get(focus.record_id, {})
                for key, value in detail.items():
                    if key == "record_id" or value in ("", None):
                        continue
                    story.append(Paragraph(
                        f"<b>{esc(key.replace('_', ' ').title())}:</b> {esc(value)}",
                        styles["BodyText2"],
                    ))
                if focus.description.strip():
                    story.append(Spacer(1, 6))
                    story.append(Paragraph(esc(focus.description.strip()), styles["BodyText2"]))
                story.append(PageBreak())

        for record_type in RECORD_TYPES:
            items = by_type.get(record_type) or []
            if not items:
                continue
            story.append(Paragraph(f"{esc(record_type)}s", styles["Section"]))
            for record in sorted(items, key=lambda item: item.name.casefold()):
                story.append(Paragraph(esc(record.name), styles["RecordTitle"]))
                story.append(Paragraph(
                    f"ID: {esc(record.record_id)} · Status: {esc(record.status)}",
                    styles["Meta"],
                ))
                detail = details.get(record.record_id, {})
                for key, value in detail.items():
                    if key == "record_id" or value in ("", None):
                        continue
                    story.append(Paragraph(
                        f"<b>{esc(key.replace('_', ' ').title())}:</b> {esc(value)}",
                        styles["BodyText2"],
                    ))
                if record.description.strip():
                    story.append(Paragraph(esc(record.description.strip()), styles["BodyText2"]))
            story.append(PageBreak())

        story.append(Paragraph("Relationships", styles["Section"]))
        if not links:
            story.append(Paragraph("No relationships in this packet.", styles["BodyText2"]))
        else:
            names = {record.record_id: record.name for record in records}
            types = {record.record_id: record.record_type for record in records}
            rows = [["Source", "Relationship", "Target"]]
            for link in links:
                rows.append([
                    f"{names.get(link.source_id, link.source_id)} "
                    f"[{types.get(link.source_id, '?')}]",
                    link.relationship,
                    f"{names.get(link.target_id, link.target_id)} "
                    f"[{types.get(link.target_id, '?')}]",
                ])
            table = Table(rows, colWidths=[2.4 * inch, 1.6 * inch, 2.4 * inch])
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#3a2f1a")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cccccc")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f2ea")]),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]))
            story.append(table)

        doc.build(story)
