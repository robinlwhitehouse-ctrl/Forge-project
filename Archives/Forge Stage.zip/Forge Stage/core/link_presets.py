"""Relationship label presets and two-way wording for record links.

Links are stored one way in links.json (source -> target, one label).  These
tables only affect display: when a link is viewed from the target's side the
reverse wording is shown.  Unknown labels are shown as-is.
"""

from __future__ import annotations

# forward label -> label as seen from the other record
REVERSE_LABELS = {
    "Connected to": "Connected to",
    "Ally of": "Ally of",
    "Enemy of": "Enemy of",
    "Rival of": "Rival of",
    "Family of": "Family of",
    "Friend of": "Friend of",
    "Located in": "Location of",
    "Lives in": "Home of",
    "Seen at": "Visited by",
    "Lairs in": "Lair of",
    "Member of": "Has member",
    "Leader of": "Led by",
    "Serves": "Served by",
    "Works at": "Employs",
    "Owns": "Owned by",
    "Owned by": "Owns",
    "Carried by": "Carries",
    "Sold at": "Sells",
    "Found at": "Holds",
    "Quest for": "Has quest",
    "Quest giver for": "Given by",
    "Target of": "Targets",
    "Reward for": "Rewards",
    "Appears in": "Features",
    "Takes place in": "Setting for",
    "Part of": "Contains",
    "Map of": "Mapped by",
    "Knows": "Known by",
    "Worships": "Worshipped by",
    "Guards": "Guarded by",
    "Hunts": "Hunted by",
    "Created by": "Creator of",
    "Summoned by": "Summoner of",
}

# (source type, target type) -> suggested forward labels, best first
PAIR_PRESETS = {
    ("NPC", "Location"): ("Lives in", "Located in", "Works at", "Seen at"),
    ("NPC", "Shop"): ("Works at", "Owns", "Seen at"),
    ("NPC", "Faction"): ("Member of", "Leader of", "Serves", "Enemy of"),
    ("NPC", "Quest"): ("Quest giver for", "Target of", "Appears in"),
    ("NPC", "NPC"): ("Ally of", "Enemy of", "Family of", "Friend of", "Rival of", "Serves"),
    ("NPC", "Player Character"): ("Ally of", "Enemy of", "Family of", "Friend of", "Rival of"),
    ("NPC", "Session"): ("Appears in",),
    ("Player Character", "Faction"): ("Member of", "Leader of", "Enemy of"),
    ("Player Character", "Location"): ("Lives in", "Seen at"),
    ("Player Character", "Player Character"): ("Ally of", "Rival of", "Family of", "Friend of"),
    ("Player Character", "Quest"): ("Quest for",),
    ("Monster", "Location"): ("Lairs in", "Seen at", "Located in"),
    ("Monster", "Encounter"): ("Appears in",),
    ("Monster", "Quest"): ("Target of", "Appears in"),
    ("Monster", "Faction"): ("Serves", "Member of"),
    ("Item", "NPC"): ("Owned by", "Carried by"),
    ("Item", "Player Character"): ("Owned by", "Carried by"),
    ("Item", "Monster"): ("Carried by",),
    ("Item", "Shop"): ("Sold at",),
    ("Item", "Location"): ("Found at",),
    ("Item", "Quest"): ("Reward for",),
    ("Weapon", "NPC"): ("Owned by", "Carried by"),
    ("Weapon", "Player Character"): ("Owned by", "Carried by"),
    ("Weapon", "Shop"): ("Sold at",),
    ("Armor", "NPC"): ("Owned by", "Carried by"),
    ("Armor", "Player Character"): ("Owned by", "Carried by"),
    ("Armor", "Shop"): ("Sold at",),
    ("Artifact", "NPC"): ("Owned by", "Carried by"),
    ("Artifact", "Player Character"): ("Owned by", "Carried by"),
    ("Artifact", "Location"): ("Found at",),
    ("Artifact", "Quest"): ("Reward for",),
    ("Location", "Location"): ("Part of",),
    ("Shop", "Location"): ("Located in",),
    ("Faction", "Location"): ("Located in",),
    ("Faction", "Faction"): ("Ally of", "Enemy of", "Rival of", "Part of"),
    ("Quest", "Location"): ("Takes place in",),
    ("Quest", "Quest"): ("Part of",),
    ("Quest", "Session"): ("Appears in",),
    ("Encounter", "Location"): ("Takes place in",),
    ("Encounter", "Quest"): ("Part of",),
    ("Encounter", "Session"): ("Appears in",),
    ("Trap", "Location"): ("Located in",),
    ("Map", "Location"): ("Map of",),
    ("Session", "Location"): ("Takes place in",),
}

GENERIC_LABELS = (
    "Connected to", "Located in", "Member of", "Ally of", "Enemy of",
    "Serves", "Owns", "Quest for", "Seen at", "Part of",
)


_REVERSE_LOWER = {k.lower(): v for k, v in REVERSE_LABELS.items()}


def label_from(label: str, outgoing: bool) -> str:
    """Wording of a link as seen from one end (outgoing = viewer is the source)."""
    label = (label or "").strip() or "Connected to"
    if outgoing:
        return label
    if label in REVERSE_LABELS:
        return REVERSE_LABELS[label]
    reverse = _REVERSE_LOWER.get(label.lower())
    if reverse is None:
        return label
    return reverse if label[:1].isupper() else reverse[:1].lower() + reverse[1:]


def presets_for(source_type: str, target_type: str) -> list[str]:
    """Suggested labels for a new link source -> target (pair presets first)."""
    out: list[str] = list(PAIR_PRESETS.get((source_type, target_type), ()))
    # a reverse pair preset can be offered as its reverse wording
    for label in PAIR_PRESETS.get((target_type, source_type), ()):
        rev = REVERSE_LABELS.get(label)
        if rev and rev not in out:
            out.append(rev)
    for label in GENERIC_LABELS:
        if label not in out:
            out.append(label)
    return out


def all_labels() -> list[str]:
    seen: list[str] = []
    for label in list(GENERIC_LABELS) + list(REVERSE_LABELS) + list(REVERSE_LABELS.values()):
        if label not in seen:
            seen.append(label)
    return seen
