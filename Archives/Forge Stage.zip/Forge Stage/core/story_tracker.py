
"""Lightweight campaign story tracker — current quest/script/beat, clues, log."""

from __future__ import annotations

from dataclasses import dataclass, field
import json
from datetime import datetime

from .projects import ForgeNextProject


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


@dataclass
class StoryTrackerState:
    current_quest_id: str = ""
    current_script_id: str = ""
    current_beat_id: str = ""
    completed: list = field(default_factory=list)  # "script_id::beat_id"
    clues: list = field(default_factory=list)
    items: list = field(default_factory=list)
    cast: list = field(default_factory=list)
    visits: dict = field(default_factory=dict)
    log: list = field(default_factory=list)  # {when, text}

    def to_dict(self) -> dict:
        return {
            "current_quest_id": self.current_quest_id,
            "current_script_id": self.current_script_id,
            "current_beat_id": self.current_beat_id,
            "completed": list(self.completed),
            "clues": list(self.clues),
            "items": list(self.items),
            "cast": list(self.cast),
            "visits": dict(self.visits),
            "log": list(self.log),
        }

    @classmethod
    def from_dict(cls, row: dict) -> "StoryTrackerState":
        if not isinstance(row, dict):
            return cls()
        log = row.get("log") or []
        if not isinstance(log, list):
            log = []
        clues = row.get("clues") or []
        if not isinstance(clues, list):
            clues = []
        items = row.get("items") or []
        if not isinstance(items, list):
            items = []
        cast = row.get("cast") or []
        if not isinstance(cast, list):
            cast = []
        visits = row.get("visits") or {}
        if not isinstance(visits, dict):
            visits = {}
        completed = row.get("completed") or []
        if not isinstance(completed, list):
            completed = []
        return cls(
            current_quest_id=str(row.get("current_quest_id") or ""),
            current_script_id=str(row.get("current_script_id") or ""),
            current_beat_id=str(row.get("current_beat_id") or ""),
            completed=[str(x) for x in completed if x],
            clues=[str(x) for x in clues if str(x).strip()],
            items=[str(x) for x in items if str(x).strip()],
            cast=[str(x) for x in cast if str(x).strip()],
            visits={str(k): int(v) for k, v in visits.items() if str(k)},
            log=[x for x in log if isinstance(x, dict)],
        )


class StoryTrackerRepository:
    def __init__(self, project: ForgeNextProject) -> None:
        self.project = project
        self.path = project.root / "data" / "story_tracker.json"

    def load(self) -> StoryTrackerState:
        if not self.path.exists():
            return StoryTrackerState()
        try:
            with self.path.open("r", encoding="utf-8") as handle:
                return StoryTrackerState.from_dict(json.load(handle))
        except Exception:
            return StoryTrackerState()

    def save(self, state: StoryTrackerState) -> StoryTrackerState:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(state.to_dict(), handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)
        return state

    def mark_beat_done(self, script_id: str, beat_id: str, note: str = "", items: list | None = None, cast: list | None = None, places: list | None = None) -> StoryTrackerState:
        state = self.load()
        key = f"{script_id}::{beat_id}"
        first = bool(key) and key not in state.completed
        if key and first:
            state.completed.append(key)
        state.visits[key] = int(state.visits.get(key, 0) or 0) + 1
        for item in items or []:
            line = str(item).strip()
            if line and line not in state.items:
                state.items.append(line)
                state.log.append({"when": _now(), "text": f"Found: {line}"})
        for person in cast or []:
            line = str(person).strip()
            if line and line not in state.cast:
                state.cast.append(line)
                state.log.append({"when": _now(), "text": f"Met: {line}"})
        state.places = list(getattr(state, "places", []) or [])
        for place in places or []:
            line = str(place).strip()
            if line and line not in state.places:
                state.places.append(line)
                state.log.append({"when": _now(), "text": f"At: {line}"})
        if note.strip():
            prefix = "Revisited" if not first else "Completed"
            if not note.lower().startswith("completed") and not note.lower().startswith("revisited"):
                note = f"{prefix} {note}"
            state.log.append({"when": _now(), "text": note.strip()})
        return self.save(state)

    def add_clue(self, text: str) -> StoryTrackerState:
        state = self.load()
        line = (text or "").strip()
        if line and line not in state.clues:
            state.clues.append(line)
            state.log.append({"when": _now(), "text": f"Clue: {line}"})
        return self.save(state)

    def add_log(self, text: str) -> StoryTrackerState:
        state = self.load()
        line = (text or "").strip()
        if line:
            state.log.append({"when": _now(), "text": line})
        return self.save(state)
