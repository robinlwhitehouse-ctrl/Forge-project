"""Weapon-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


WEAPON_CATEGORIES = (
    "Simple Melee", "Simple Ranged", "Martial Melee",
    "Martial Ranged", "Improvised", "Other",
)
DAMAGE_TYPES = (
    "Bludgeoning", "Piercing", "Slashing", "Acid", "Cold",
    "Fire", "Force", "Lightning", "Necrotic", "Poison",
    "Psychic", "Radiant", "Thunder", "Other",
)


@dataclass(frozen=True)
class WeaponDetails:
    record_id: str
    category: str = "Simple Melee"
    base_weapon: str = ""
    damage: str = ""
    damage_type: str = "Bludgeoning"
    properties: str = ""
    weapon_range: str = ""
    weight: str = ""
    value: str = ""


@dataclass(frozen=True)
class ForgeNextWeapon:
    record: ForgeNextRecord
    details: WeaponDetails


class WeaponRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "weapons.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def weapons(self) -> list[ForgeNextWeapon]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Weapon"
        }
        details_by_id = {
            row.get("record_id", ""): WeaponDetails(**row)
            for row in self._read()
        }
        return [
            ForgeNextWeapon(
                record,
                details_by_id.get(record.record_id, WeaponDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_weapon(
        self, name: str, category: str, base_weapon: str, damage: str,
        damage_type: str, properties: str, weapon_range: str, weight: str,
        value: str, status: str, description: str,
    ) -> ForgeNextWeapon:
        record = self.records.create_record("Weapon", name, status, description)
        details = WeaponDetails(
            record.record_id, category or "Simple Melee", base_weapon.strip(),
            damage.strip(), damage_type or "Bludgeoning", properties.strip(),
            weapon_range.strip(), weight.strip(), value.strip(),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextWeapon(record, details)

    def update_weapon(
        self, record_id: str, name: str, category: str, base_weapon: str,
        damage: str, damage_type: str, properties: str, weapon_range: str,
        weight: str, value: str, status: str, description: str,
    ) -> ForgeNextWeapon:
        record = self.records.update_record(record_id, name, status, description)
        details = WeaponDetails(
            record_id, category or "Simple Melee", base_weapon.strip(),
            damage.strip(), damage_type or "Bludgeoning", properties.strip(),
            weapon_range.strip(), weight.strip(), value.strip(),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextWeapon(record, details)
