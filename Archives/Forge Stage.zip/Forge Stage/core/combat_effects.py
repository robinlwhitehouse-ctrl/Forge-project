"""Session combat effects — spell/condition round counters."""

from __future__ import annotations

from dataclasses import dataclass
import json
from uuid import uuid4

from .projects import ForgeNextProject


@dataclass
class CombatEffect:
    id: str
    name: str
    rounds: int
    token_id: str = ""
    token_name: str = ""
    description: str = ""

    def to_row(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "rounds": int(self.rounds),
            "token_id": self.token_id,
            "token_name": self.token_name,
            "description": self.description,
        }

    @classmethod
    def from_row(cls, row: dict) -> "CombatEffect":
        try:
            rounds = int(row.get("rounds") or 0)
        except (TypeError, ValueError):
            rounds = 0
        return cls(
            id=str(row.get("id") or uuid4().hex[:8]),
            name=str(row.get("name") or "Effect"),
            rounds=rounds,
            token_id=str(row.get("token_id") or ""),
            token_name=str(row.get("token_name") or ""),
            description=str(row.get("description") or ""),
        )


class CombatEffectRepository:
    def __init__(self, project: ForgeNextProject) -> None:
        self.project = project
        self.path = project.root / "data" / "records" / "combat_effects.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return []
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(rows, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    def effects(self) -> list[CombatEffect]:
        return [CombatEffect.from_row(r) for r in self._read() if isinstance(r, dict)]

    def add(self, name: str, rounds: int, token_id: str = "", token_name: str = "", description: str = "") -> CombatEffect:
        effect = CombatEffect(
            id=uuid4().hex[:8],
            name=(name or "Effect").strip() or "Effect",
            rounds=max(0, int(rounds)),
            token_id=token_id or "",
            token_name=token_name or "",
            description=(description or "").strip(),
        )
        rows = self._read()
        rows.append(effect.to_row())
        self._write(rows)
        return effect

    def remove(self, effect_id: str) -> None:
        self._write([r for r in self._read() if r.get("id") != effect_id])

    def tick_round(self) -> list[CombatEffect]:
        """Decrement all timed effects; drop those that reach 0."""
        kept = []
        for row in self._read():
            try:
                rounds = int(row.get("rounds") or 0) - 1
            except (TypeError, ValueError):
                rounds = 0
            if rounds <= 0:
                continue
            row["rounds"] = rounds
            kept.append(row)
        self._write(kept)
        return [CombatEffect.from_row(r) for r in kept]

    def for_token(self, token_id: str) -> list[CombatEffect]:
        if not token_id:
            return []
        return [e for e in self.effects() if e.token_id == token_id]
