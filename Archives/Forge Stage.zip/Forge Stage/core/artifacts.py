"""Artifact-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


ARTIFACT_CATEGORIES = (
    "Wondrous Item", "Weapon", "Armor", "Tool", "Relic",
    "Document", "Key Item", "Other",
)
ARTIFACT_RARITIES = (
    "Common", "Uncommon", "Rare", "Very Rare",
    "Legendary", "Artifact", "Unique",
)


@dataclass(frozen=True)
class ArtifactDetails:
    record_id: str
    category: str = "Wondrous Item"
    rarity: str = "Unique"
    requires_attunement: str = "No"
    origin: str = ""
    powers: str = ""


@dataclass(frozen=True)
class ForgeNextArtifact:
    record: ForgeNextRecord
    details: ArtifactDetails


class ArtifactRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "artifacts.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def artifacts(self) -> list[ForgeNextArtifact]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Artifact"
        }
        details_by_id = {
            row.get("record_id", ""): ArtifactDetails(**row)
            for row in self._read()
        }
        return [
            ForgeNextArtifact(
                record,
                details_by_id.get(record.record_id, ArtifactDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_artifact(
        self, name: str, category: str, rarity: str,
        requires_attunement: str, origin: str, powers: str,
        status: str, description: str,
    ) -> ForgeNextArtifact:
        record = self.records.create_record("Artifact", name, status, description)
        details = ArtifactDetails(
            record.record_id, category or "Wondrous Item", rarity or "Unique",
            requires_attunement or "No", origin.strip(), powers.strip(),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextArtifact(record, details)

    def update_artifact(
        self, record_id: str, name: str, category: str, rarity: str,
        requires_attunement: str, origin: str, powers: str,
        status: str, description: str,
    ) -> ForgeNextArtifact:
        record = self.records.update_record(record_id, name, status, description)
        details = ArtifactDetails(
            record_id, category or "Wondrous Item", rarity or "Unique",
            requires_attunement or "No", origin.strip(), powers.strip(),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextArtifact(record, details)
