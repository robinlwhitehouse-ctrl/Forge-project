"""Feat-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


FEAT_TYPES = (
    "General",
    "Origin",
    "Fighting Style",
    "Epic Boon",
    "Racial / Species",
    "Class Feature",
    "Other",
)

FEAT_SOURCES = (
    "Player's Handbook",
    "Xanathar's Guide",
    "Tasha's Cauldron",
    "Homebrew",
    "Campaign",
    "Other",
)


@dataclass(frozen=True)
class FeatDetails:
    record_id: str
    feat_type: str = "General"
    source: str = "Homebrew"
    prerequisite: str = ""
    repeatable: str = "No"
    benefits: str = ""


def _details_from_row(row: dict) -> FeatDetails:
    return FeatDetails(
        record_id=str(row.get("record_id", "") or ""),
        feat_type=str(row.get("feat_type", "General") or "General"),
        source=str(row.get("source", "Homebrew") or "Homebrew"),
        prerequisite=str(row.get("prerequisite", "") or ""),
        repeatable=str(row.get("repeatable", "No") or "No"),
        benefits=str(row.get("benefits", "") or ""),
    )


@dataclass(frozen=True)
class ForgeNextFeat:
    record: ForgeNextRecord
    details: FeatDetails


class FeatRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "feats.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def feats(self) -> list[ForgeNextFeat]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Feat"
        }
        details_by_id = {
            str(row.get("record_id", "")): _details_from_row(row)
            for row in self._read()
            if isinstance(row, dict)
        }
        return [
            ForgeNextFeat(
                record,
                details_by_id.get(record.record_id, FeatDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_feat(
        self,
        name: str,
        feat_type: str,
        source: str,
        prerequisite: str,
        repeatable: str,
        benefits: str,
        status: str,
        description: str,
    ) -> ForgeNextFeat:
        record = self.records.create_record("Feat", name, status, description)
        details = FeatDetails(
            record.record_id,
            feat_type or "General",
            source or "Homebrew",
            prerequisite.strip(),
            repeatable or "No",
            benefits.strip(),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextFeat(record, details)

    def update_feat(
        self,
        record_id: str,
        name: str,
        feat_type: str,
        source: str,
        prerequisite: str,
        repeatable: str,
        benefits: str,
        status: str,
        description: str,
    ) -> ForgeNextFeat:
        record = self.records.update_record(record_id, name, status, description)
        details = FeatDetails(
            record_id,
            feat_type or "General",
            source or "Homebrew",
            prerequisite.strip(),
            repeatable or "No",
            benefits.strip(),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextFeat(record, details)
