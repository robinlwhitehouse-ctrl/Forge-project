"""Forgotten Realms (Harptos) calendar, clock, season, and weather for Forge Next."""

from __future__ import annotations

from dataclasses import dataclass
import json
import random
from pathlib import Path

from .calendar import CalendarRepository, CampaignCalendar, harptos
from .projects import ForgeNextProject

# 12 months × 30 days; festival days sit between months
MONTHS = (
    "Hammer",
    "Alturiak",
    "Ches",
    "Tarsakh",
    "Mirtul",
    "Kythorn",
    "Flamerule",
    "Eleasis",
    "Eleint",
    "Marpenoth",
    "Uktar",
    "Nightal",
)

# Festival day after month index 0, 2, 5, 8, 10 (before next month)
# Midwinter after Hammer, Greengrass after Ches, Midsummer after Kythorn,
# Highharvestide after Eleint, Feast of the Moon after Uktar
FESTIVALS = (
    (0, "Midwinter"),
    (2, "Greengrass"),
    (5, "Midsummer"),
    (8, "Highharvestide"),
    (10, "Feast of the Moon"),
)

SEASON_BY_MONTH = {
    "Nightal": "Winter",
    "Hammer": "Winter",
    "Alturiak": "Winter",
    "Ches": "Spring",
    "Tarsakh": "Spring",
    "Mirtul": "Spring",
    "Kythorn": "Summer",
    "Flamerule": "Summer",
    "Eleasis": "Summer",
    "Eleint": "Autumn",
    "Marpenoth": "Autumn",
    "Uktar": "Autumn",
}

WEATHER_BY_SEASON: dict[str, list[str]] = {
    "Spring": [
        "Clear",
        "Light rain",
        "Heavy rain",
        "Fog",
        "Windy",
        "Overcast",
        "Thunderstorm",
    ],
    "Summer": [
        "Clear",
        "Hot and clear",
        "Humid",
        "Thunderstorm",
        "Light breeze",
        "Haze",
        "Clear night",
    ],
    "Autumn": [
        "Clear",
        "Overcast",
        "Rain",
        "Wind",
        "Fog",
        "Cold drizzle",
        "Crisp and clear",
    ],
    "Winter": [
        "Clear and cold",
        "Snow",
        "Heavy snow",
        "Overcast",
        "Bitter wind",
        "Freezing fog",
        "Light flurries",
    ],
}


@dataclass
class WorldClockState:
    year: int = 1491
    month_index: int = 6  # Flamerule (0-based)
    day: int = 1  # 1-30 within month; 0 = festival day
    festival: str = ""  # non-empty when on a festival day
    hour: int = 9  # 0-23 internal
    minute: int = 0
    weather: str = "Clear"
    weather_log: list = None  # type: ignore
    tick: int = 0  # hours advanced, for rest checks

    def __post_init__(self) -> None:
        if self.weather_log is None:
            self.weather_log = []

    @property
    def month_name(self) -> str:
        if self.festival:
            return self.festival
        return MONTHS[self.month_index % 12]

    @property
    def season(self) -> str:
        if self.festival:
            # Festivals sit between months; use the season of the month just ended
            return SEASON_BY_MONTH.get(MONTHS[self.month_index % 12], "Summer")
        return SEASON_BY_MONTH.get(self.month_name, "Summer")

    def time_12h(self) -> str:
        h = self.hour % 24
        minute = max(0, min(59, self.minute))
        period = "AM" if h < 12 else "PM"
        display = h % 12
        if display == 0:
            display = 12
        return f"{display}:{minute:02d} {period}"

    def date_label(self, calendar: CampaignCalendar | None = None) -> str:
        era = f" {calendar.era}" if calendar and calendar.era else " DR"
        if self.festival:
            return f"{self.festival}, {self.year}{era}"
        name = self.month_name
        if calendar and calendar.months:
            names = calendar.month_names()
            if names:
                name = names[self.month_index % len(names)]
        return f"{self.day} {name} {self.year}{era}"

    def season_label(self, calendar: CampaignCalendar | None = None) -> str:
        if calendar and calendar.months:
            return calendar.season_for(self.month_index, self.festival) or self.season
        return self.season

    def summary(self, calendar: CampaignCalendar | None = None) -> str:
        return f"{self.date_label(calendar)} · {self.time_12h()} · {self.season_label(calendar)} · {self.weather}"

    def to_dict(self) -> dict:
        return {
            "year": self.year,
            "month_index": self.month_index,
            "day": self.day,
            "festival": self.festival,
            "hour": self.hour,
            "minute": self.minute,
            "weather": self.weather,
            "weather_log": list(self.weather_log[-20:]),
            "tick": int(self.tick or 0),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "WorldClockState":
        if not isinstance(data, dict):
            return cls()
        try:
            state = cls(
                year=int(data.get("year", 1491)),
                month_index=int(data.get("month_index", 6)) % 12,
                day=int(data.get("day", 1)),
                festival=str(data.get("festival", "") or ""),
                hour=int(data.get("hour", 9)) % 24,
                minute=int(data.get("minute", 0)) % 60,
                weather=str(data.get("weather", "Clear") or "Clear"),
                weather_log=list(data.get("weather_log") or []),
                tick=int(data.get("tick", 0) or 0),
            )
        except (TypeError, ValueError):
            return cls()
        if state.festival:
            state.day = 0
        elif state.day < 1:
            state.day = 1
        elif state.day > 30:
            state.day = 30
        return state


class WorldClockRepository:
    """Persists world date/time/weather under the project data folder."""

    def __init__(self, project: ForgeNextProject) -> None:
        self.project = project
        self.path = project.root / "data" / "world_clock.json"

    def load(self) -> WorldClockState:
        if not self.path.exists():
            return WorldClockState()
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError):
            return WorldClockState()
        return WorldClockState.from_dict(data if isinstance(data, dict) else {})

    def save(self, state: WorldClockState) -> WorldClockState:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(
            json.dumps(state.to_dict(), indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        temporary.replace(self.path)
        return state

    def advance_hours(self, state: WorldClockState, hours: int) -> WorldClockState:
        state.tick = int(getattr(state, "tick", 0) or 0) + max(0, int(hours))
        total = state.hour * 60 + state.minute + int(hours) * 60
        days, rem = divmod(total, 24 * 60)
        state.hour = rem // 60
        state.minute = rem % 60
        for _ in range(max(0, days)):
            state = self.advance_days(state, 1)
        return state

    def advance_minutes(self, state: WorldClockState, minutes: int) -> WorldClockState:
        minutes = max(0, int(minutes))
        if not minutes:
            return state
        old = state.hour * 60 + state.minute
        total = old + minutes
        days, rem = divmod(total, 24 * 60)
        gained = (total // 60) - (old // 60)
        state.tick = int(getattr(state, "tick", 0) or 0) + gained
        state.hour = rem // 60
        state.minute = rem % 60
        for _ in range(max(0, days)):
            state = self._next_day(state)
        return state

    def advance_days(self, state: WorldClockState, days: int) -> WorldClockState:
        for _ in range(max(0, int(days))):
            state = self._next_day(state)
        return state

    def _calendar(self) -> CampaignCalendar:
        return getattr(self, "calendar", None) or CampaignCalendar.from_dict(harptos())

    def _next_day(self, state: WorldClockState) -> WorldClockState:
        cal = self._calendar()
        count = max(1, len(cal.months) or 12)
        length = cal.month_length(state.month_index)

        if state.festival:
            state.festival = ""
            state.month_index = (state.month_index + 1) % count
            if state.month_index == 0:
                state.year += 1
            state.day = 1
            return state

        if state.day < length:
            state.day += 1
            return state

        holiday = cal.holiday_after(state.month_index)
        if holiday:
            state.festival = holiday
            state.day = 0
            return state

        state.month_index = (state.month_index + 1) % count
        if state.month_index == 0:
            state.year += 1
        state.day = 1
        return state

    def set_time_12h(
        self, state: WorldClockState, hour12: int, minute: int, period: str
    ) -> WorldClockState:
        hour12 = max(1, min(12, int(hour12)))
        minute = max(0, min(59, int(minute)))
        period = period.upper().strip()
        if period not in ("AM", "PM"):
            period = "AM"
        h = hour12 % 12
        if period == "PM":
            h += 12
        state.hour = h
        state.minute = minute
        return state

    def set_date(
        self,
        state: WorldClockState,
        year: int,
        month_name: str,
        day: int,
        festival: str = "",
    ) -> WorldClockState:
        state.year = int(year)
        if festival:
            state.festival = festival
            state.day = 0
            # month_index = month before the festival
            for idx, name in FESTIVALS:
                if name == festival:
                    state.month_index = idx
                    break
            return state
        state.festival = ""
        if month_name in MONTHS:
            state.month_index = MONTHS.index(month_name)
        state.day = max(1, min(30, int(day)))
        return state

    def roll_weather(self, state: WorldClockState) -> WorldClockState:
        season = state.season
        options = WEATHER_BY_SEASON.get(season) or WEATHER_BY_SEASON["Summer"]
        choice = random.choice(options)
        state.weather = choice
        state.weather_log.append(f"{state.date_label()} {state.time_12h()}: {choice}")
        state.weather_log = state.weather_log[-20:]
        return state
