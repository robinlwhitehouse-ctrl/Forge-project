"""Shared records and relationships for Forge Next projects."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
from uuid import uuid4

from .projects import ForgeNextProject


RECORD_TYPES = (
    "Location", "NPC", "Player Character", "Quest", "Session",
    "Monster", "Item", "Weapon", "Armor", "Spell", "Faction",
    "Encounter", "Trap", "Feat", "Map", "Artifact", "Shop", "Script",
)

# Type-specific detail files living under data/records/
DETAIL_FILES = {
    "Location": "locations.json",
    "NPC": "npcs.json",
    "Player Character": "player_characters.json",
    "Quest": "quests.json",
    "Session": "sessions.json",
    "Monster": "monsters.json",
    "Item": "items.json",
    "Weapon": "weapons.json",
    "Armor": "armor.json",
    "Spell": "spells.json",
    "Faction": "factions.json",
    "Encounter": "encounters.json",
    "Trap": "traps.json",
    "Feat": "feats.json",
    "Map": "maps.json",
    "Artifact": "artifacts.json",
    "Shop": "shops.json",
    "Script": "scripts.json",
}


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


@dataclass(frozen=True)
class ForgeNextRecord:
    record_id: str
    record_type: str
    name: str
    status: str
    description: str
    created_at: str


@dataclass(frozen=True)
class ForgeNextLink:
    link_id: str
    source_id: str
    target_id: str
    relationship: str
    created_at: str


class RecordRepository:
    """Project-scoped storage for the first Forge Next campaign graph."""

    def __init__(self, project: ForgeNextProject) -> None:
        self.project = project
        self.records_path = project.root / "data" / "records" / "records.json"
        self.links_path = project.root / "data" / "records" / "relationships.json"

    @staticmethod
    def _read(path: Path) -> list[dict]:
        if not path.exists():
            return []
        with path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    @staticmethod
    def _write(path: Path, rows: list[dict]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(path)

    def records(self) -> list[ForgeNextRecord]:
        rows = self._read(self.records_path)
        return [ForgeNextRecord(**row) for row in rows]

    def links(self) -> list[ForgeNextLink]:
        rows = self._read(self.links_path)
        return [ForgeNextLink(**row) for row in rows]

    def create_record(
        self, record_type: str, name: str, status: str = "Draft", description: str = ""
    ) -> ForgeNextRecord:
        if record_type not in RECORD_TYPES:
            raise ValueError("Choose a valid record type.")
        name = name.strip()
        if not name:
            raise ValueError("A record name is required.")
        record = ForgeNextRecord(
            record_id=f"{record_type[:3].upper()}-{uuid4().hex[:8].upper()}",
            record_type=record_type,
            name=name,
            status=status.strip() or "Draft",
            description=description.strip(),
            created_at=_now(),
        )
        rows = self._read(self.records_path)
        rows.append(asdict(record))
        self._write(self.records_path, rows)
        return record

    def create_link(self, source_id: str, target_id: str, relationship: str) -> ForgeNextLink:
        if not source_id or not target_id or source_id == target_id:
            raise ValueError("Choose two different records to link.")
        existing_ids = {record.record_id for record in self.records()}
        if source_id not in existing_ids or target_id not in existing_ids:
            raise ValueError("The selected record no longer exists.")
        relationship = relationship.strip() or "Connected to"
        rows = self._read(self.links_path)
        for row in rows:
            if (
                row.get("source_id") == source_id
                and row.get("target_id") == target_id
                and (row.get("relationship") or "Connected to") == relationship
            ):
                raise ValueError("That exact relationship already exists.")
        link = ForgeNextLink(
            link_id=f"LNK-{uuid4().hex[:8].upper()}",
            source_id=source_id,
            target_id=target_id,
            relationship=relationship,
            created_at=_now(),
        )
        rows.append(asdict(link))
        self._write(self.links_path, rows)
        return link

    def links_for(self, record_id: str) -> list[ForgeNextLink]:
        return [link for link in self.links() if record_id in (link.source_id, link.target_id)]

    def delete_link(self, link_id: str) -> None:
        rows = self._read(self.links_path)
        remaining = [row for row in rows if row.get("link_id") != link_id]
        if len(remaining) == len(rows):
            raise ValueError("The selected relationship no longer exists.")
        self._write(self.links_path, remaining)

    def update_link(
        self,
        link_id: str,
        *,
        target_id: str | None = None,
        relationship: str | None = None,
        reverse: bool = False,
    ) -> ForgeNextLink:
        """Edit an existing relationship (label and/or other record)."""
        rows = self._read(self.links_path)
        found = None
        for row in rows:
            if row.get("link_id") == link_id:
                found = row
                break
        if found is None:
            raise ValueError("The selected relationship no longer exists.")

        source_id = found.get("source_id", "")
        other_id = target_id if target_id else found.get("target_id", "")
        if reverse:
            # Swap direction: former target becomes source
            source_id, other_id = other_id, source_id
        if not source_id or not other_id or source_id == other_id:
            raise ValueError("Choose two different records to link.")
        existing_ids = {record.record_id for record in self.records()}
        if source_id not in existing_ids or other_id not in existing_ids:
            raise ValueError("The selected record no longer exists.")

        new_rel = (relationship if relationship is not None else found.get("relationship") or "Connected to")
        new_rel = str(new_rel).strip() or "Connected to"

        for row in rows:
            if row.get("link_id") == link_id:
                continue
            if (
                row.get("source_id") == source_id
                and row.get("target_id") == other_id
                and (row.get("relationship") or "Connected to") == new_rel
            ):
                raise ValueError("That exact relationship already exists.")

        found["source_id"] = source_id
        found["target_id"] = other_id
        found["relationship"] = new_rel
        self._write(self.links_path, rows)
        return ForgeNextLink(
            link_id=found["link_id"],
            source_id=source_id,
            target_id=other_id,
            relationship=new_rel,
            created_at=str(found.get("created_at") or _now()),
        )

    def update_record(self, record_id: str, name: str, status: str, description: str) -> ForgeNextRecord:
        name = name.strip()
        if not name:
            raise ValueError("A record name is required.")
        rows = self._read(self.records_path)
        updated: ForgeNextRecord | None = None
        for index, row in enumerate(rows):
            if row.get("record_id") != record_id:
                continue
            updated = ForgeNextRecord(
                record_id=record_id,
                record_type=row.get("record_type", "Location"),
                name=name,
                status=status.strip() or "Draft",
                description=description.strip(),
                created_at=row.get("created_at", _now()),
            )
            rows[index] = asdict(updated)
            break
        if updated is None:
            raise ValueError("The selected record no longer exists.")
        self._write(self.records_path, rows)
        return updated

    def delete_record(self, record_id: str) -> ForgeNextRecord:
        """Remove a record, its type-specific details, and all of its relationships."""
        rows = self._read(self.records_path)
        deleted: ForgeNextRecord | None = None
        remaining_records: list[dict] = []
        for row in rows:
            if row.get("record_id") == record_id:
                deleted = ForgeNextRecord(**row)
            else:
                remaining_records.append(row)
        if deleted is None:
            raise ValueError("The selected record no longer exists.")
        self._write(self.records_path, remaining_records)

        # Remove relationships that reference this record
        link_rows = self._read(self.links_path)
        remaining_links = [
            row for row in link_rows
            if record_id not in (row.get("source_id"), row.get("target_id"))
        ]
        self._write(self.links_path, remaining_links)

        # Remove type-specific detail row if present
        detail_name = DETAIL_FILES.get(deleted.record_type)
        if detail_name:
            detail_path = self.project.root / "data" / "records" / detail_name
            if detail_path.exists():
                detail_rows = self._read(detail_path)
                kept = [row for row in detail_rows if row.get("record_id") != record_id]
                if len(kept) != len(detail_rows):
                    self._write(detail_path, kept)

        return deleted
