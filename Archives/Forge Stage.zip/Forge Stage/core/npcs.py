"""NPC-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


NPC_ROLES = (
    "Ally",
    "Contact",
    "Quest Giver",
    "Merchant",
    "Authority",
    "Rival",
    "Villain",
    "Bystander",
    "Other",
)

# Attempt number → difficulty label (fixed table)
DUEL_DIFFICULTY_TABLE = {
    1: "Easy",
    2: "Medium",
    3: "Medium",
    4: "Hard",
    5: "Hard",
    6: "Deadly",
    7: "Deadly",
}


def duel_difficulty_for(attempt: int, max_attempts: int = 7) -> str:
    attempt = max(1, min(int(attempt or 1), max(1, int(max_attempts or 7))))
    if attempt in DUEL_DIFFICULTY_TABLE:
        return DUEL_DIFFICULTY_TABLE[attempt]
    # Beyond table: clamp to highest defined
    keys = sorted(DUEL_DIFFICULTY_TABLE)
    if attempt <= keys[0]:
        return DUEL_DIFFICULTY_TABLE[keys[0]]
    return DUEL_DIFFICULTY_TABLE[keys[-1]]


@dataclass(frozen=True)
class NPCDetails:
    record_id: str
    role: str = "Other"
    ancestry: str = ""
    occupation: str = ""
    faction: str = ""
    duel_enabled: bool = False
    duel_max: int = 7
    duel_attempt: int = 1
    duel_rewards: str = ""
    duel_scale_stats: bool = True  # auto +AC/+HP per attempt
    duel_base_ac: str = ""
    duel_base_hp: str = ""
    duel_base_max_hp: str = ""
    duel_base_attack: str = ""


def _details_from_row(row: dict) -> NPCDetails:
    try:
        dmax = int(row.get("duel_max", 7) or 7)
    except (TypeError, ValueError):
        dmax = 7
    dmax = max(1, min(20, dmax))
    try:
        dattempt = int(row.get("duel_attempt", 1) or 1)
    except (TypeError, ValueError):
        dattempt = 1
    dattempt = max(1, min(dmax, dattempt))
    return NPCDetails(
        record_id=str(row.get("record_id", "") or ""),
        role=str(row.get("role", "Other") or "Other"),
        ancestry=str(row.get("ancestry", "") or ""),
        occupation=str(row.get("occupation", "") or ""),
        faction=str(row.get("faction", "") or ""),
        duel_enabled=bool(row.get("duel_enabled", False)),
        duel_max=dmax,
        duel_attempt=dattempt,
        duel_rewards=str(row.get("duel_rewards", "") or ""),
        duel_scale_stats=bool(row.get("duel_scale_stats", True)),
        duel_base_ac=str(row.get("duel_base_ac", "") or ""),
        duel_base_hp=str(row.get("duel_base_hp", "") or ""),
        duel_base_max_hp=str(row.get("duel_base_max_hp", "") or ""),
        duel_base_attack=str(row.get("duel_base_attack", "") or ""),
    )


@dataclass(frozen=True)
class ForgeNextNPC:
    record: ForgeNextRecord
    details: NPCDetails


class NPCRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "npcs.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def npcs(self) -> list[ForgeNextNPC]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "NPC"
        }
        details_by_id = {
            row.get("record_id", ""): _details_from_row(row)
            for row in self._read()
            if isinstance(row, dict)
        }
        return [
            ForgeNextNPC(
                record,
                details_by_id.get(record.record_id, NPCDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def get(self, record_id: str) -> ForgeNextNPC | None:
        for npc in self.npcs():
            if npc.record.record_id == record_id:
                return npc
        return None

    def create_npc(
        self,
        name: str,
        role: str,
        ancestry: str,
        occupation: str,
        faction: str,
        status: str,
        description: str,
        *,
        duel_enabled: bool = False,
        duel_max: int = 7,
        duel_attempt: int = 1,
        duel_rewards: str = "",
        duel_scale_stats: bool = True,
        duel_base_ac: str = "",
        duel_base_hp: str = "",
        duel_base_max_hp: str = "",
        duel_base_attack: str = "",
    ) -> ForgeNextNPC:
        record = self.records.create_record("NPC", name, status, description)
        dmax = max(1, min(20, int(duel_max or 7)))
        dattempt = max(1, min(dmax, int(duel_attempt or 1)))
        details = NPCDetails(
            record.record_id,
            role or "Other",
            ancestry.strip(),
            occupation.strip(),
            faction.strip(),
            bool(duel_enabled),
            dmax,
            dattempt,
            (duel_rewards or "").strip(),
            bool(duel_scale_stats),
            (duel_base_ac or "").strip(),
            (duel_base_hp or "").strip(),
            (duel_base_max_hp or "").strip(),
            (duel_base_attack or "").strip(),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextNPC(record, details)

    def update_npc(
        self,
        record_id: str,
        name: str,
        role: str,
        ancestry: str,
        occupation: str,
        faction: str,
        status: str,
        description: str,
        *,
        duel_enabled: bool = False,
        duel_max: int = 7,
        duel_attempt: int = 1,
        duel_rewards: str = "",
        duel_scale_stats: bool = True,
        duel_base_ac: str = "",
        duel_base_hp: str = "",
        duel_base_max_hp: str = "",
        duel_base_attack: str = "",
    ) -> ForgeNextNPC:
        record = self.records.update_record(record_id, name, status, description)
        dmax = max(1, min(20, int(duel_max or 7)))
        dattempt = max(1, min(dmax, int(duel_attempt or 1)))
        details = NPCDetails(
            record_id,
            role or "Other",
            ancestry.strip(),
            occupation.strip(),
            faction.strip(),
            bool(duel_enabled),
            dmax,
            dattempt,
            (duel_rewards or "").strip(),
            bool(duel_scale_stats),
            (duel_base_ac or "").strip(),
            (duel_base_hp or "").strip(),
            (duel_base_max_hp or "").strip(),
            (duel_base_attack or "").strip(),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextNPC(record, details)

    def set_duel_progress(
        self,
        record_id: str,
        *,
        attempt: int | None = None,
        rewards: str | None = None,
        enabled: bool | None = None,
        max_attempts: int | None = None,
        scale_stats: bool | None = None,
        base_ac: str | None = None,
        base_hp: str | None = None,
        base_max_hp: str | None = None,
        base_attack: str | None = None,
    ) -> ForgeNextNPC:
        """Update only duel fields (Stage live controls)."""
        npc = self.get(record_id)
        if npc is None:
            raise ValueError("NPC not found.")
        d = npc.details
        dmax = d.duel_max if max_attempts is None else max(1, min(20, int(max_attempts)))
        dattempt = d.duel_attempt if attempt is None else max(1, min(dmax, int(attempt)))
        den = d.duel_enabled if enabled is None else bool(enabled)
        drew = d.duel_rewards if rewards is None else str(rewards)
        dscale = d.duel_scale_stats if scale_stats is None else bool(scale_stats)
        bac = d.duel_base_ac if base_ac is None else str(base_ac)
        bhp = d.duel_base_hp if base_hp is None else str(base_hp)
        bmx = d.duel_base_max_hp if base_max_hp is None else str(base_max_hp)
        bat = d.duel_base_attack if base_attack is None else str(base_attack)
        return self.update_npc(
            record_id,
            npc.record.name,
            d.role,
            d.ancestry,
            d.occupation,
            d.faction,
            npc.record.status,
            npc.record.description,
            duel_enabled=den,
            duel_max=dmax,
            duel_attempt=dattempt,
            duel_rewards=drew,
            duel_scale_stats=dscale,
            duel_base_ac=bac,
            duel_base_hp=bhp,
            duel_base_max_hp=bmx,
            duel_base_attack=bat,
        )
