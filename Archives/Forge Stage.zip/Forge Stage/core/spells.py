"""Spell-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


SPELL_SCHOOLS = (
    "Abjuration", "Conjuration", "Divination", "Enchantment",
    "Evocation", "Illusion", "Necromancy", "Transmutation", "Other",
)
SPELL_LEVELS = (
    "Cantrip", "1st", "2nd", "3rd", "4th", "5th",
    "6th", "7th", "8th", "9th",
)
CASTING_TIMES = (
    "1 Action", "1 Bonus Action", "1 Reaction", "1 Minute",
    "10 Minutes", "1 Hour", "8 Hours", "12 Hours", "24 Hours", "Other",
)
SPELL_RANGES = (
    "Self", "Touch", "5 feet", "10 feet", "30 feet", "60 feet",
    "90 feet", "120 feet", "150 feet", "300 feet", "1 mile", "Sight", "Unlimited", "Other",
)
SPELL_DURATIONS = (
    "Instantaneous", "1 Round", "1 Minute", "10 Minutes",
    "1 Hour", "8 Hours", "24 Hours", "Until Dispelled",
    "Concentration, up to 1 minute", "Concentration, up to 10 minutes",
    "Concentration, up to 1 hour", "Special", "Other",
)


@dataclass(frozen=True)
class SpellDetails:
    record_id: str
    school: str = "Evocation"
    level: str = "Cantrip"
    casting_time: str = "1 Action"
    spell_range: str = "Self"
    components: str = "V, S"
    duration: str = "Instantaneous"
    ritual: str = "No"
    concentration: str = "No"


@dataclass(frozen=True)
class ForgeNextSpell:
    record: ForgeNextRecord
    details: SpellDetails


class SpellRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "spells.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def spells(self) -> list[ForgeNextSpell]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Spell"
        }
        details_by_id = {
            row.get("record_id", ""): SpellDetails(**row)
            for row in self._read()
        }
        return [
            ForgeNextSpell(
                record,
                details_by_id.get(record.record_id, SpellDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_spell(
        self, name: str, school: str, level: str, casting_time: str,
        spell_range: str, components: str, duration: str,
        ritual: str, concentration: str, status: str, description: str,
    ) -> ForgeNextSpell:
        record = self.records.create_record("Spell", name, status, description)
        details = SpellDetails(
            record.record_id, school or "Evocation", level or "Cantrip",
            casting_time or "1 Action", spell_range or "Self",
            components.strip() or "V, S", duration or "Instantaneous",
            ritual or "No", concentration or "No",
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextSpell(record, details)

    def update_spell(
        self, record_id: str, name: str, school: str, level: str,
        casting_time: str, spell_range: str, components: str, duration: str,
        ritual: str, concentration: str, status: str, description: str,
    ) -> ForgeNextSpell:
        record = self.records.update_record(record_id, name, status, description)
        details = SpellDetails(
            record_id, school or "Evocation", level or "Cantrip",
            casting_time or "1 Action", spell_range or "Self",
            components.strip() or "V, S", duration or "Instantaneous",
            ritual or "No", concentration or "No",
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextSpell(record, details)
