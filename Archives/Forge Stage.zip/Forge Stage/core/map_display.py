"""Map display settings for dual-monitor play and fog of war."""

from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from uuid import uuid4

from .projects import ForgeNextProject
from .errorlog import log_exception


@dataclass
class MapDisplaySettings:
    record_id: str
    player_image: str = ""  # relative path under project root
    dm_image: str = ""
    fog_enabled: bool = False
    # Normalized 0-1 rectangles: {"x": 0.0, "y": 0.0, "w": 1.0, "h": 1.0}
    revealed_regions: list = field(default_factory=list)
    # Optional painted fog mask (L mode PNG, white=revealed, black=hidden)
    fog_mask: str = ""
    # Tokens on the DM map: {id, name, x, y, color} with x/y normalized 0-1
    tokens: list = field(default_factory=list)
    notes: str = ""
    # Grid overlay (Player Display / TV only)
    grid_enabled: bool = False
    grid_type: str = "square"  # square | hex
    grid_size_px: int = 50  # source-image pixels per 5 ft cell
    grid_feet: int = 5
    grid_color: str = "#88aacc"
    grid_offset_x: int = 0
    grid_offset_y: int = 0
    grid_strong: bool = False  # False=soft opacity, True=strong lines
    token_scale_tv: int = 100
    token_scale_dm: int = 100
    walls: list = field(default_factory=list)


class MapDisplayRepository:
    """Per-map player/DM image roles, fog mask, reveals, and tokens."""

    def __init__(self, project: ForgeNextProject) -> None:
        self.project = project
        self.path = project.root / "data" / "records" / "map_display.json"
        self.mask_root = project.root / "assets" / "images" / "fog_masks"
        self.mask_root.mkdir(parents=True, exist_ok=True)
        self._cache = {}

    def _read(self) -> dict:
        if not self.path.exists():
            return {}
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError):
            return {}
        return value if isinstance(value, dict) else {}

    def _write(self, data: dict) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        temporary.replace(self.path)

    def _walls_path(self, record_id: str) -> Path:
        folder = self.project.root / "data" / "walls"
        folder.mkdir(parents=True, exist_ok=True)
        return folder / f"{record_id}.json"

    def _read_walls(self, record_id: str) -> list:
        path = self._walls_path(record_id)
        if not path.exists():
            return []
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError):
            return []
        return value if isinstance(value, list) else []

    def _write_walls(self, record_id: str, walls: list) -> None:
        path = self._walls_path(record_id)
        path.write_text(json.dumps(walls, indent=2) + "\n", encoding="utf-8")

    def get(self, record_id: str) -> MapDisplaySettings:
        cached = self._cache.get(record_id)
        if cached is not None:
            return cached
        row = self._read().get(record_id, {})
        if not isinstance(row, dict):
            row = {}
        regions = row.get("revealed_regions") or []
        cleaned = []
        for region in regions:
            if not isinstance(region, dict):
                continue
            try:
                cleaned.append({
                    "x": float(region.get("x", 0)),
                    "y": float(region.get("y", 0)),
                    "w": float(region.get("w", 0)),
                    "h": float(region.get("h", 0)),
                })
            except (TypeError, ValueError):
                continue
        tokens = []
        for token in row.get("tokens") or []:
            if not isinstance(token, dict):
                continue
            try:
                entry = {
                    "id": str(token.get("id") or uuid4().hex[:10]),
                    "name": str(token.get("name") or "Token"),
                    "x": float(token.get("x", 0.5)),
                    "y": float(token.get("y", 0.5)),
                    "color": str(token.get("color") or "#c4a35a"),
                    "record_id": str(token.get("record_id") or ""),
                    "kind": str(token.get("kind") or "creature"),
                    "ac": str(token.get("ac") or ""),
                    "hp": str(token.get("hp") or ""),
                    "max_hp": str(token.get("max_hp") or ""),
                    "attack": str(token.get("attack") or ""),
                    "skills": str(token.get("skills") or ""),
                    "notes": str(token.get("notes") or ""),
                    "icon": str(token.get("icon") or ""),
                }
                for key in ("duel_base_ac", "duel_base_hp", "duel_base_max_hp", "duel_base_attack"):
                    if token.get(key) not in (None, ""):
                        entry[key] = str(token.get(key))
                tokens.append(entry)
            except (TypeError, ValueError):
                continue
        try:
            grid_size = int(row.get("grid_size_px", 50) or 50)
        except (TypeError, ValueError):
            grid_size = 50
        grid_size = max(8, min(512, grid_size))
        try:
            grid_feet = int(row.get("grid_feet", 5) or 5)
        except (TypeError, ValueError):
            grid_feet = 5
        try:
            gox = int(row.get("grid_offset_x", 0) or 0)
            goy = int(row.get("grid_offset_y", 0) or 0)
        except (TypeError, ValueError):
            gox, goy = 0, 0
        gtype = str(row.get("grid_type", "square") or "square").lower()
        if gtype not in ("square", "hex"):
            gtype = "square"
        walls = []
        for wall in row.get("walls") or []:
            if not isinstance(wall, dict):
                continue
            try:
                walls.append({
                    "id": str(wall.get("id") or uuid4().hex[:10]),
                    "x1": float(wall.get("x1", 0)),
                    "y1": float(wall.get("y1", 0)),
                    "x2": float(wall.get("x2", 0)),
                    "y2": float(wall.get("y2", 0)),
                    "door": bool(wall.get("door", False)),
                    "open": bool(wall.get("open", False)),
                })
            except (TypeError, ValueError):
                continue
        saved = self._read_walls(record_id)
        if saved:
            walls = saved
        settings = MapDisplaySettings(
            record_id=record_id,
            player_image=str(row.get("player_image", "") or ""),
            dm_image=str(row.get("dm_image", "") or ""),
            fog_enabled=bool(row.get("fog_enabled", False)),
            revealed_regions=cleaned,
            fog_mask=str(row.get("fog_mask", "") or ""),
            tokens=tokens,
            notes=str(row.get("notes", "") or ""),
            grid_enabled=bool(row.get("grid_enabled", False)),
            grid_type=gtype,
            grid_size_px=grid_size,
            grid_feet=max(1, grid_feet),
            grid_color=str(row.get("grid_color", "#88aacc") or "#88aacc"),
            grid_offset_x=gox,
            grid_offset_y=goy,
            grid_strong=bool(row.get("grid_strong", False)),
            token_scale_tv=max(25, min(300, int(row.get("token_scale_tv", 100) or 100))),
            token_scale_dm=max(25, min(300, int(row.get("token_scale_dm", 100) or 100))),
            walls=walls,
        )
        self._cache[record_id] = settings
        return settings

    def save(self, settings: MapDisplaySettings) -> MapDisplaySettings:
        self._cache[settings.record_id] = settings
        data = self._read()
        data[settings.record_id] = {
            "player_image": settings.player_image,
            "dm_image": settings.dm_image,
            "fog_enabled": settings.fog_enabled,
            "revealed_regions": list(settings.revealed_regions),
            "fog_mask": settings.fog_mask,
            "tokens": list(settings.tokens),
            "notes": settings.notes,
            "grid_enabled": bool(getattr(settings, "grid_enabled", False)),
            "grid_type": getattr(settings, "grid_type", "square") or "square",
            "grid_size_px": int(getattr(settings, "grid_size_px", 50) or 50),
            "grid_feet": int(getattr(settings, "grid_feet", 5) or 5),
            "grid_color": getattr(settings, "grid_color", "#88aacc") or "#88aacc",
            "grid_offset_x": int(getattr(settings, "grid_offset_x", 0) or 0),
            "grid_offset_y": int(getattr(settings, "grid_offset_y", 0) or 0),
            "grid_strong": bool(getattr(settings, "grid_strong", False)),
            "token_scale_tv": int(getattr(settings, "token_scale_tv", 100) or 100),
            "token_scale_dm": int(getattr(settings, "token_scale_dm", 100) or 100),
            "walls": list(getattr(settings, "walls", []) or []),
        }
        self._write(data)
        self._write_walls(settings.record_id, list(getattr(settings, "walls", []) or []))
        return settings

    def absolute(self, relative_path: str) -> Path | None:
        if not relative_path:
            return None
        path = (self.project.root / relative_path).resolve()
        return path if path.is_file() else None

    def add_reveal(self, record_id: str, x: float, y: float, w: float, h: float) -> MapDisplaySettings:
        settings = self.get(record_id)
        settings.revealed_regions.append({
            "x": max(0.0, min(1.0, x)),
            "y": max(0.0, min(1.0, y)),
            "w": max(0.01, min(1.0, w)),
            "h": max(0.01, min(1.0, h)),
        })
        return self.save(settings)

    def clear_reveals(self, record_id: str) -> MapDisplaySettings:
        settings = self.get(record_id)
        settings.revealed_regions = []
        # Also reset painted mask to fully hidden if present
        if settings.fog_mask:
            mask_path = self.absolute(settings.fog_mask)
            if mask_path is not None:
                try:
                    from PIL import Image
                    mask = Image.open(mask_path).convert("L")
                    Image.new("L", mask.size, 0).save(mask_path)
                except Exception:
                    log_exception()
        return self.save(settings)

    def reveal_all(self, record_id: str) -> MapDisplaySettings:
        settings = self.get(record_id)
        settings.revealed_regions = [{"x": 0.0, "y": 0.0, "w": 1.0, "h": 1.0}]
        if settings.fog_mask:
            mask_path = self.absolute(settings.fog_mask)
            if mask_path is not None:
                try:
                    from PIL import Image
                    mask = Image.open(mask_path).convert("L")
                    Image.new("L", mask.size, 255).save(mask_path)
                except Exception:
                    log_exception()
        return self.save(settings)

    def reveal_grid_cell(self, record_id: str, col: int, row: int, cols: int = 4, rows: int = 4) -> MapDisplaySettings:
        cols = max(1, cols)
        rows = max(1, rows)
        col = max(0, min(cols - 1, col))
        row = max(0, min(rows - 1, row))
        return self.add_reveal(record_id, col / cols, row / rows, 1 / cols, 1 / rows)

    def ensure_fog_mask(self, record_id: str, width: int, height: int, fill: int = 0) -> MapDisplaySettings:
        """Create a fog mask if missing. fill 0=hidden, 255=revealed."""
        settings = self.get(record_id)
        if settings.fog_mask:
            existing = self.absolute(settings.fog_mask)
            if existing is not None:
                return settings
        from PIL import Image
        mask = Image.new("L", (max(1, width), max(1, height)), fill)
        relative = f"assets/images/fog_masks/{record_id}.png"
        absolute = self.project.root / relative
        absolute.parent.mkdir(parents=True, exist_ok=True)
        mask.save(absolute)
        settings.fog_mask = relative
        return self.save(settings)

    def paint_fog_brush(
        self,
        record_id: str,
        image_width: int,
        image_height: int,
        cx: float,
        cy: float,
        radius: float,
        reveal: bool,
    ) -> MapDisplaySettings:
        """Paint a circular brush on the fog mask. cx/cy are image pixel coords."""
        from PIL import Image, ImageDraw

        settings = self.ensure_fog_mask(record_id, image_width, image_height, fill=0)
        mask_path = self.absolute(settings.fog_mask)
        if mask_path is None:
            settings = self.ensure_fog_mask(record_id, image_width, image_height, fill=0)
            mask_path = self.absolute(settings.fog_mask)
        if mask_path is None:
            return settings
        mask = Image.open(mask_path).convert("L")
        if mask.size != (image_width, image_height):
            mask = mask.resize((image_width, image_height), Image.NEAREST)
        draw = ImageDraw.Draw(mask)
        r = max(1, int(radius))
        x0, y0 = int(cx - r), int(cy - r)
        x1, y1 = int(cx + r), int(cy + r)
        fill = 255 if reveal else 0
        draw.ellipse((x0, y0, x1, y1), fill=fill)
        mask.save(mask_path)
        settings.fog_enabled = True
        return self.save(settings)

    def add_token(
        self,
        record_id: str,
        name: str,
        x: float,
        y: float,
        color: str = "#c4a35a",
        *,
        linked_record_id: str = "",
        kind: str = "creature",
        ac: str = "",
        hp: str = "",
        max_hp: str = "",
        attack: str = "",
        skills: str = "",
        notes: str = "",
        icon: str = "",
    ) -> MapDisplaySettings:
        settings = self.get(record_id)
        settings.tokens.append({
            "id": uuid4().hex[:10],
            "name": name or "Token",
            "x": max(0.0, min(1.0, x)),
            "y": max(0.0, min(1.0, y)),
            "color": color or "#c4a35a",
            "record_id": linked_record_id or "",
            "kind": kind or "creature",
            "ac": ac or "",
            "hp": hp or "",
            "max_hp": max_hp or "",
            "attack": attack or "",
            "skills": skills or "",
            "notes": notes or "",
            "icon": icon or "",
        })
        return self.save(settings)

    def move_token_live(self, map_record_id: str, token_id: str, x: float, y: float) -> None:
        settings = self.get(map_record_id)
        for token in settings.tokens:
            if token.get("id") == token_id:
                token["x"] = max(0.0, min(1.0, float(x)))
                token["y"] = max(0.0, min(1.0, float(y)))
                break
        self._cache[map_record_id] = settings

    def update_token(self, map_record_id: str, token_id: str, **fields) -> MapDisplaySettings:
        settings = self.get(map_record_id)
        allowed = {
            "name", "color", "record_id", "kind", "ac", "hp", "max_hp",
            "attack", "skills", "notes", "icon", "x", "y",
            "duel_base_ac", "duel_base_hp", "duel_base_max_hp", "duel_base_attack",
        }
        for token in settings.tokens:
            if token.get("id") == token_id:
                for key, value in fields.items():
                    if key in allowed:
                        token[key] = value
                break
        return self.save(settings)

    def clear_tokens(self, record_id: str) -> MapDisplaySettings:
        settings = self.get(record_id)
        settings.tokens = []
        return self.save(settings)

    def remove_token(self, record_id: str, token_id: str) -> MapDisplaySettings:
        settings = self.get(record_id)
        settings.tokens = [t for t in settings.tokens if t.get("id") != token_id]
        return self.save(settings)


    def reload(self, record_id: str) -> MapDisplaySettings:
        self._cache.pop(record_id, None)
        return self.get(record_id)

    def add_wall(self, record_id: str, x1: float, y1: float, x2: float, y2: float, door: bool = False) -> MapDisplaySettings:
        settings = self.get(record_id)
        settings.walls.append({
            "id": uuid4().hex[:10],
            "x1": x1, "y1": y1, "x2": x2, "y2": y2,
            "door": bool(door),
            "open": False,
        })
        return self.save(settings)

    def remove_wall(self, record_id: str, wall_id: str) -> MapDisplaySettings:
        settings = self.get(record_id)
        settings.walls = [w for w in settings.walls if w.get("id") != wall_id]
        return self.save(settings)

    def toggle_door(self, record_id: str, wall_id: str) -> MapDisplaySettings:
        settings = self.get(record_id)
        for wall in settings.walls:
            if wall.get("id") == wall_id and wall.get("door"):
                wall["open"] = not bool(wall.get("open"))
        return self.save(settings)

    def pop_wall(self, record_id: str) -> MapDisplaySettings:
        settings = self.get(record_id)
        if settings.walls:
            settings.walls.pop()
        return self.save(settings)

    def clear_walls(self, record_id: str) -> MapDisplaySettings:
        settings = self.get(record_id)
        settings.walls = []
        return self.save(settings)
