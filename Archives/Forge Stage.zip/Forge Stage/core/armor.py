"""Armor-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


ARMOR_CATEGORIES = (
    "Light Armor", "Medium Armor", "Heavy Armor", "Shield", "Other",
)
STEALTH_OPTIONS = (
    "None", "Disadvantage", "Advantage",
)


@dataclass(frozen=True)
class ArmorDetails:
    record_id: str
    category: str = "Light Armor"
    base_armor: str = ""
    armor_class: str = ""
    strength_requirement: str = ""
    stealth: str = "None"
    properties: str = ""
    weight: str = ""
    value: str = ""


@dataclass(frozen=True)
class ForgeNextArmor:
    record: ForgeNextRecord
    details: ArmorDetails


class ArmorRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "armor.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def armor(self) -> list[ForgeNextArmor]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Armor"
        }
        details_by_id = {
            row.get("record_id", ""): ArmorDetails(**row)
            for row in self._read()
        }
        return [
            ForgeNextArmor(
                record,
                details_by_id.get(record.record_id, ArmorDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_armor(
        self, name: str, category: str, base_armor: str, armor_class: str,
        strength_requirement: str, stealth: str, properties: str,
        weight: str, value: str, status: str, description: str,
    ) -> ForgeNextArmor:
        record = self.records.create_record("Armor", name, status, description)
        details = ArmorDetails(
            record.record_id, category or "Light Armor", base_armor.strip(),
            armor_class.strip(), strength_requirement.strip(),
            stealth or "None", properties.strip(),
            weight.strip(), value.strip(),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextArmor(record, details)

    def update_armor(
        self, record_id: str, name: str, category: str, base_armor: str,
        armor_class: str, strength_requirement: str, stealth: str,
        properties: str, weight: str, value: str, status: str, description: str,
    ) -> ForgeNextArmor:
        record = self.records.update_record(record_id, name, status, description)
        details = ArmorDetails(
            record_id, category or "Light Armor", base_armor.strip(),
            armor_class.strip(), strength_requirement.strip(),
            stealth or "None", properties.strip(),
            weight.strip(), value.strip(),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextArmor(record, details)
