"""Bridge between Forge Next and Legend Engine story packs."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class LegendChoice:
    choice_id: str
    text: str
    to_stage_id: str = ""
    consequence: str = ""
    state_changes: str = ""
    condition_type: str = "always"


@dataclass
class LegendStage:
    stage_id: str
    number: str
    name: str
    narrative: str = ""
    gm_notes: str = ""
    child_mode: str = "sequential"
    show_in_parent_choices: bool = True
    choices: list[LegendChoice] = field(default_factory=list)
    next_stage_id: str = ""
    complete_quest: bool = False
    xp: int = 0


@dataclass
class LegendQuest:
    quest_id: str
    title: str
    notes: str = ""
    stages: list[LegendStage] = field(default_factory=list)


@dataclass
class LegendPack:
    version: str = ""
    campaign_title: str = ""
    quests: list[LegendQuest] = field(default_factory=list)
    source_path: str = ""
    raw: dict = field(default_factory=dict)


def _as_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def _parse_choice(row: dict) -> LegendChoice:
    return LegendChoice(
        choice_id=_as_str(row.get("id")),
        text=_as_str(row.get("text")),
        to_stage_id=_as_str(row.get("toStageId")),
        consequence=_as_str(row.get("consequence")),
        state_changes=_as_str(row.get("stateChanges")),
        condition_type=_as_str(row.get("conditionType"), "always"),
    )


def _parse_stage(row: dict) -> LegendStage:
    choices = [
        _parse_choice(ch) for ch in (row.get("choices") or []) if isinstance(ch, dict)
    ]
    try:
        xp = int(row.get("xp") or 0)
    except (TypeError, ValueError):
        xp = 0
    return LegendStage(
        stage_id=_as_str(row.get("id")),
        number=_as_str(row.get("number")),
        name=_as_str(row.get("name")),
        narrative=_as_str(row.get("narrative")),
        gm_notes=_as_str(row.get("gmNotes")),
        child_mode=_as_str(row.get("childMode"), "sequential") or "sequential",
        show_in_parent_choices=bool(row.get("showInParentChoices", True)),
        choices=choices,
        next_stage_id=_as_str(row.get("nextStageId")),
        complete_quest=bool(row.get("completeQuest", False)),
        xp=xp,
    )


def _parse_quest(row: dict) -> LegendQuest:
    stages = [
        _parse_stage(st) for st in (row.get("stages") or []) if isinstance(st, dict)
    ]
    return LegendQuest(
        quest_id=_as_str(row.get("id")),
        title=_as_str(row.get("title")),
        notes=_as_str(row.get("notes")),
        stages=stages,
    )


def load_legend_pack(path: Path | str) -> LegendPack:
    path = Path(path)
    with path.open("r", encoding="utf-8") as handle:
        raw = json.load(handle)
    if not isinstance(raw, dict):
        raise ValueError("Story pack must be a JSON object.")
    campaign = raw.get("campaign") if isinstance(raw.get("campaign"), dict) else {}
    quests = [
        _parse_quest(q) for q in (raw.get("quests") or []) if isinstance(q, dict)
    ]
    return LegendPack(
        version=_as_str(raw.get("version")),
        campaign_title=_as_str(campaign.get("title")),
        quests=quests,
        source_path=str(path),
        raw=raw,
    )


def stage_by_id(pack: LegendPack, stage_id: str) -> LegendStage | None:
    for quest in pack.quests:
        for stage in quest.stages:
            if stage.stage_id == stage_id:
                return stage
    return None


def quest_for_stage(pack: LegendPack, stage_id: str) -> LegendQuest | None:
    for quest in pack.quests:
        for stage in quest.stages:
            if stage.stage_id == stage_id:
                return quest
    return None


def child_stages(quest: LegendQuest, parent: LegendStage) -> list[LegendStage]:
    prefix = parent.number.strip() + "."
    children: list[LegendStage] = []
    for st in quest.stages:
        num = st.number.strip()
        if not num.startswith(prefix):
            continue
        rest = num[len(prefix):]
        if rest and "." not in rest:
            children.append(st)

    def sort_key(st: LegendStage):
        try:
            return int(st.number.rsplit(".", 1)[-1])
        except ValueError:
            return 0

    children.sort(key=sort_key)
    return children


def decision_options(pack: LegendPack, stage: LegendStage) -> list[dict]:
    """GM-facing choice cards: explicit choices + child stages when parent is choices mode."""
    quest = quest_for_stage(pack, stage.stage_id)
    options: list[dict] = []
    for ch in stage.choices:
        target = stage_by_id(pack, ch.to_stage_id) if ch.to_stage_id else None
        summary_parts: list[str] = []
        if ch.consequence:
            summary_parts.append(ch.consequence)
        if ch.state_changes:
            summary_parts.append(ch.state_changes)
        if target is not None and target.narrative:
            text = target.narrative
            summary_parts.append(text[:220] + ("…" if len(text) > 220 else ""))
        options.append(
            {
                "label": ch.text or "(choice)",
                "consequence": " | ".join(summary_parts) if summary_parts else "(no consequence text yet)",
                "to_stage_id": ch.to_stage_id,
                "target_label": f"{target.number} — {target.name}" if target else "",
                "narrative": (target.narrative if target else "") or "",
                "gm_notes": (target.gm_notes if target else "") or stage.gm_notes,
                "source": "choice",
            }
        )
    if quest is not None and stage.child_mode == "choices":
        for child in child_stages(quest, stage):
            if not child.show_in_parent_choices:
                continue
            if any(o.get("to_stage_id") == child.stage_id for o in options):
                continue
            narr = child.narrative or ""
            options.append(
                {
                    "label": f"{child.number} — {child.name}",
                    "consequence": (narr[:220] + ("…" if len(narr) > 220 else "")) if narr else "(no narrative yet)",
                    "to_stage_id": child.stage_id,
                    "target_label": f"{child.number} — {child.name}",
                    "narrative": narr,
                    "gm_notes": child.gm_notes or "",
                    "source": "child_stage",
                }
            )
    return options
