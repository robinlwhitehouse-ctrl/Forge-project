"""Campaign notes shared by Library and Stage."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
from uuid import uuid4
import json

from .projects import ForgeNextProject


def new_note_id() -> str:
    return f"NOTE-{uuid4().hex[:8].upper()}"


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


@dataclass
class CampaignNote:
    note_id: str
    title: str = "Untitled"
    body: str = ""
    updated: str = ""

    @classmethod
    def from_dict(cls, row: dict) -> "CampaignNote":
        return cls(
            note_id=str(row.get("note_id") or new_note_id()),
            title=str(row.get("title") or "Untitled"),
            body=str(row.get("body") or ""),
            updated=str(row.get("updated") or ""),
        )


class NotesRepository:
    def __init__(self, project: ForgeNextProject) -> None:
        self.project = project
        self.path = project.root / "data" / "notes.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def notes(self) -> list[CampaignNote]:
        items = [CampaignNote.from_dict(row) for row in self._read() if isinstance(row, dict)]
        items.sort(key=lambda n: n.updated, reverse=True)
        return items

    def get(self, note_id: str) -> CampaignNote | None:
        for note in self.notes():
            if note.note_id == note_id:
                return note
        return None

    def save(self, note: CampaignNote) -> CampaignNote:
        note.updated = _now()
        if not note.note_id:
            note.note_id = new_note_id()
        rows = [asdict(n) for n in self.notes() if n.note_id != note.note_id]
        rows.append(asdict(note))
        self._write(rows)
        return note

    def delete(self, note_id: str) -> None:
        self._write([asdict(n) for n in self.notes() if n.note_id != note_id])
