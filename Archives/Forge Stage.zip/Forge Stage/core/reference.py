"""Offline D&D 5e SRD lookup for the Forge Library test workbook.

Data files live in reference/srd next to forge_next.py.
Content is SRD 5.1, CC-BY-4.0. Not affiliated with Wizards of the Coast.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import json

KINDS = ("Monster", "Spell", "Condition", "Rule", "Gear", "Magic item")


@dataclass
class ReferenceHit:
    kind: str
    index: str
    name: str
    summary: str
    body: str
    raw: dict = field(repr=False, default_factory=dict)
    cr: float | None = None

    @property
    def reference_id(self) -> str:
        return f"{self.kind}:{self.index}"


def cr_number(value) -> float | None:
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().lower().replace("cr", "").strip()
    if not text:
        return None
    try:
        if "/" in text:
            num, den = text.split("/", 1)
            return float(num) / float(den)
        return float(text)
    except (TypeError, ValueError):
        return None


def cr_span(text: str) -> tuple[float, float] | None:
    raw = (text or "").strip().lower().replace("cr", "").strip()
    if not raw:
        return None
    if "-" in raw:
        left, right = raw.split("-", 1)
        lo, hi = cr_number(left), cr_number(right)
        if lo is None or hi is None:
            return None
        return (min(lo, hi), max(lo, hi))
    value = cr_number(raw)
    return None if value is None else (value, value)


def data_dir() -> Path:
    root = Path(__file__).resolve().parent.parent / "reference" / "srd"
    if root.is_dir():
        return root
    return Path(__file__).resolve().parent / "srd"


def _load(name: str) -> list:
    path = data_dir() / name
    if not path.is_file():
        return []
    value = json.loads(path.read_text(encoding="utf-8"))
    return value if isinstance(value, list) else []


_CACHE: list[ReferenceHit] | None = None


def catalog() -> list[ReferenceHit]:
    global _CACHE
    if _CACHE is None:
        _CACHE = _build()
    return _CACHE


def _build() -> list[ReferenceHit]:
    hits: list[ReferenceHit] = []
    for row in _load("monsters.json"):
        if isinstance(row, dict) and row.get("name"):
            hits.append(_monster(row))
    for row in _load("spells.json"):
        if isinstance(row, dict) and row.get("name"):
            hits.append(_spell(row))
    for row in _load("conditions.json"):
        if isinstance(row, dict) and row.get("name"):
            hits.append(_condition(row))
    for row in _load("rule-sections.json"):
        if isinstance(row, dict) and row.get("name"):
            hits.append(_rule(row))
    for row in _load("equipment.json"):
        if isinstance(row, dict) and row.get("name"):
            hits.append(_gear(row))
    for row in _load("magic-items.json"):
        if isinstance(row, dict) and row.get("name"):
            hits.append(_magic(row))
    hits.sort(key=lambda h: (h.kind, h.name.lower()))
    return hits


def search(query: str, kind: str = "All", limit: int = 80, cr: str = "") -> list[ReferenceHit]:
    q = (query or "").strip().lower()
    kind = kind or "All"
    span = cr_span(cr)
    if span and kind == "All":
        kind = "Monster"
    named: list[ReferenceHit] = []
    other: list[ReferenceHit] = []
    for hit in catalog():
        if kind != "All" and hit.kind != kind:
            continue
        if span is not None:
            if hit.cr is None or not (span[0] - 0.001 <= hit.cr <= span[1] + 0.001):
                continue
        if not q:
            named.append(hit)
            continue
        if q in hit.name.lower():
            named.append(hit)
        elif q in hit.summary.lower() or q in hit.body.lower():
            other.append(hit)
    found = named + other
    if span is not None:
        found.sort(key=lambda h: (h.cr if h.cr is not None else 99, h.name.lower()))
    elif not q and kind == "All":
        order = {"Monster": 0, "Spell": 1, "Condition": 2, "Rule": 3, "Gear": 4, "Magic item": 5}
        found.sort(key=lambda h: (order.get(h.kind, 9), h.name.lower()))
    return found[:limit]


def format_cr(cr) -> str:
    try:
        value = float(cr)
    except (TypeError, ValueError):
        return str(cr or "")
    if value == 0:
        return "0"
    if value < 1:
        return f"1/{round(1 / value)}"
    if value == int(value):
        return str(int(value))
    return str(value)


def _join(value) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        parts = []
        for item in value:
            if isinstance(item, dict):
                parts.append(str(item.get("name") or item.get("index") or ""))
            else:
                parts.append(str(item))
        return ", ".join(p for p in parts if p)
    if isinstance(value, dict):
        return ", ".join(f"{k} {v}" for k, v in value.items() if v not in ("", None))
    return str(value)


def _ac(row: dict) -> str:
    parts = []
    for item in row.get("armor_class") or []:
        if isinstance(item, dict):
            parts.append(str(item.get("value") or ""))
        else:
            parts.append(str(item))
    return " / ".join(p for p in parts if p)


def _named(items) -> str:
    lines = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        name = item.get("name") or "Entry"
        desc = item.get("desc") or ""
        lines.append(f"{name}. {desc}".strip())
    return "\n".join(lines)


def _mod(score) -> str:
    try:
        n = int(score)
    except (TypeError, ValueError):
        return "—"
    mod = (n - 10) // 2
    return f"+{mod}" if mod >= 0 else str(mod)


def _monster(row: dict) -> ReferenceHit:
    cr = format_cr(row.get("challenge_rating"))
    subtype = row.get("subtype") or ""
    type_line = str(row.get("type") or "creature")
    if subtype:
        type_line = f"{type_line} ({subtype})"
    skills = []
    saves = []
    for prof in row.get("proficiencies") or []:
        if not isinstance(prof, dict):
            continue
        label = str((prof.get("proficiency") or {}).get("name") or "")
        value = prof.get("value")
        shown = f"+{value}" if isinstance(value, int) and value >= 0 else str(value)
        if label.lower().startswith("skill"):
            skills.append(f"{label.split(':', 1)[-1].strip()} {shown}")
        elif label.lower().startswith("saving"):
            saves.append(f"{label.split(':', 1)[-1].strip()} {shown}")
    abilities = "  ".join(
        f"{label} {row.get(key)} ({_mod(row.get(key))})"
        for label, key in (
            ("STR", "strength"), ("DEX", "dexterity"), ("CON", "constitution"),
            ("INT", "intelligence"), ("WIS", "wisdom"), ("CHA", "charisma"),
        )
    )
    lines = [
        f"{row.get('name')} — {row.get('size')} {type_line}, {row.get('alignment')}",
        f"AC {_ac(row)}    HP {row.get('hit_points')} ({row.get('hit_points_roll') or row.get('hit_dice')})",
        f"Speed {_join(row.get('speed'))}",
        abilities,
        f"Saves: {_join(saves) or '—'}",
        f"Skills: {', '.join(skills) or '—'}",
        f"Vulnerabilities: {_join(row.get('damage_vulnerabilities')) or '—'}",
        f"Resistances: {_join(row.get('damage_resistances')) or '—'}",
        f"Immunities: {_join(row.get('damage_immunities')) or '—'}",
        f"Condition immunities: {_join(row.get('condition_immunities')) or '—'}",
        f"Senses: {_join(row.get('senses')) or '—'}",
        f"Languages: {row.get('languages') or '—'}",
        f"CR {cr}    XP {row.get('xp') or '—'}",
        "",
    ]
    traits = _named(row.get("special_abilities"))
    actions = _named(row.get("actions"))
    bonus = _named(row.get("bonus_actions"))
    reactions = _named(row.get("reactions"))
    legendary = _named(row.get("legendary_actions"))
    if traits:
        lines.extend(["Traits", traits, ""])
    if actions:
        lines.extend(["Actions", actions, ""])
    if bonus:
        lines.extend(["Bonus actions", bonus, ""])
    if reactions:
        lines.extend(["Reactions", reactions, ""])
    if legendary:
        lines.extend(["Legendary actions", legendary, ""])
    lines.append("SRD 5.1 · CC-BY-4.0 · Wizards of the Coast")
    body = "\n".join(lines)
    return ReferenceHit("Monster", str(row.get("index") or row.get("name")), str(row["name"]), f"CR {cr}", body, row, cr_number(row.get("challenge_rating")))


def _spell(row: dict) -> ReferenceHit:
    level = row.get("level")
    level_label = "Cantrip" if level in (0, "0") else f"Level {level}"
    school = (row.get("school") or {}).get("name") if isinstance(row.get("school"), dict) else row.get("school")
    comps = ", ".join(row.get("components") or [])
    material = row.get("material") or ""
    if material:
        comps = f"{comps} ({material})" if comps else material
    desc = "\n\n".join(row.get("desc") or [])
    higher = "\n\n".join(row.get("higher_level") or [])
    lines = [
        f"{row.get('name')} — {level_label} {school}",
        f"Casting time: {row.get('casting_time')}",
        f"Range: {row.get('range')}",
        f"Components: {comps or '—'}",
        f"Duration: {row.get('duration')}"
        + (" (concentration)" if row.get("concentration") else "")
        + (" (ritual)" if row.get("ritual") else ""),
        "",
        desc,
    ]
    if higher:
        lines.extend(["", "At higher levels", higher])
    lines.extend(["", "SRD 5.1 · CC-BY-4.0 · Wizards of the Coast"])
    body = "\n".join(lines)
    return ReferenceHit("Spell", str(row.get("index") or row.get("name")), str(row["name"]), f"{level_label} {school or ''}".strip(), body, row)


def _condition(row: dict) -> ReferenceHit:
    desc = "\n".join(row.get("desc") or [])
    body = f"{row.get('name')}\n\n{desc}\n\nSRD 5.1 · CC-BY-4.0 · Wizards of the Coast"
    return ReferenceHit("Condition", str(row.get("index") or row.get("name")), str(row["name"]), "Condition", body, row)


def _rule(row: dict) -> ReferenceHit:
    desc = str(row.get("desc") or "")
    body = f"{desc}\n\nSRD 5.1 · CC-BY-4.0 · Wizards of the Coast"
    return ReferenceHit("Rule", str(row.get("index") or row.get("name")), str(row["name"]), "Rule", body, row)


def _gear(row: dict) -> ReferenceHit:
    cost = row.get("cost") or {}
    cost_text = ""
    if isinstance(cost, dict) and cost.get("quantity") is not None:
        cost_text = f"{cost.get('quantity')} {cost.get('unit') or ''}".strip()
    cat = ""
    if isinstance(row.get("equipment_category"), dict):
        cat = row["equipment_category"].get("name") or ""
    desc = "\n".join(row.get("desc") or [])
    body = "\n".join([
        f"{row.get('name')} — {cat}",
        f"Cost: {cost_text or '—'}    Weight: {row.get('weight') if row.get('weight') is not None else '—'}",
        "",
        desc,
        "",
        "SRD 5.1 · CC-BY-4.0 · Wizards of the Coast",
    ])
    return ReferenceHit("Gear", str(row.get("index") or row.get("name")), str(row["name"]), cat or "Gear", body, row)


def _magic(row: dict) -> ReferenceHit:
    rarity = ""
    if isinstance(row.get("rarity"), dict):
        rarity = row["rarity"].get("name") or ""
    desc = "\n\n".join(row.get("desc") or [])
    body = "\n".join([
        f"{row.get('name')} — {rarity}",
        "",
        desc,
        "",
        "SRD 5.1 · CC-BY-4.0 · Wizards of the Coast",
    ])
    return ReferenceHit("Magic item", str(row.get("index") or row.get("name")), str(row["name"]), rarity or "Magic item", body, row)
