"""Map-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


MAP_ARCHETYPES = (
    "World", "Region", "Settlement", "District", "Building",
    "Dungeon", "Encounter", "Travel", "Other",
)
MAP_TYPES = (
    "Campaign Map", "Player Map", "DM Map", "Battle Map",
    "Reference Map", "Other",
)


@dataclass(frozen=True)
class MapDetails:
    record_id: str
    archetype: str = "Region"
    map_type: str = "Campaign Map"
    region: str = ""
    scale: str = ""
    grid: str = "None"


@dataclass(frozen=True)
class ForgeNextMap:
    record: ForgeNextRecord
    details: MapDetails


class MapRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "maps.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def maps(self) -> list[ForgeNextMap]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Map"
        }
        details_by_id = {
            row.get("record_id", ""): MapDetails(**row)
            for row in self._read()
        }
        return [
            ForgeNextMap(
                record,
                details_by_id.get(record.record_id, MapDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_map(
        self, name: str, archetype: str, map_type: str, region: str,
        scale: str, grid: str, status: str, description: str,
    ) -> ForgeNextMap:
        record = self.records.create_record("Map", name, status, description)
        details = MapDetails(
            record.record_id, archetype or "Region", map_type or "Campaign Map",
            region.strip(), scale.strip(), grid or "None",
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextMap(record, details)

    def update_map(
        self, record_id: str, name: str, archetype: str, map_type: str,
        region: str, scale: str, grid: str, status: str, description: str,
    ) -> ForgeNextMap:
        record = self.records.update_record(record_id, name, status, description)
        details = MapDetails(
            record_id, archetype or "Region", map_type or "Campaign Map",
            region.strip(), scale.strip(), grid or "None",
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextMap(record, details)
