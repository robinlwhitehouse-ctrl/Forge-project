"""Simple project audio playback for Forge Next Table Tools.

Backends (first available wins):
  1. pygame.mixer
  2. Windows PowerShell / WPF MediaPlayer (MP3/WAV, no extra installs)
  3. Windows MCI (winmm)
  4. ffplay (ffmpeg)
  5. winsound (WAV only)
"""

from __future__ import annotations

from pathlib import Path
import shutil
import subprocess
import sys
import uuid
import tempfile
import time
from .errorlog import log_exception, log_message


class AudioPlayer:
    def __init__(self, role: str = "music") -> None:
        self._backend: str = "none"
        self._pygame = None
        self._proc: subprocess.Popen | None = None
        self._path: Path | None = None
        self._loop = False
        self._volume = 0.7  # 0.0–1.0
        self._role = role
        self._id = uuid.uuid4().hex[:8]
        self._mci_alias = f"forge_{role}_{self._id}"
        self._stop_flag: Path | None = None
        self._channel = None
        self._sound = None
        self._active = "none"  # backend actually playing the current file
        self._init_backend()

    def _init_backend(self) -> None:
        self._backend = "none"
        self._pygame = None
        try:
            import pygame

            if not pygame.mixer.get_init():
                pygame.mixer.init()
            self._pygame = pygame
            self._backend = "pygame"
            return
        except Exception:
            self._pygame = None

        if sys.platform.startswith("win"):
            # PowerShell + WPF MediaPlayer is the most reliable no-install MP3 path
            self._backend = "wpf"
            return

        if shutil.which("ffplay"):
            self._backend = "ffplay"
            return

        self._backend = "none"

    def refresh_backend(self) -> str:
        self.stop()
        self._init_backend()
        return self._backend

    @property
    def backend(self) -> str:
        return self._backend

    @property
    def available(self) -> bool:
        return self._backend != "none"

    @property
    def current_path(self) -> Path | None:
        return self._path

    def install_hint(self) -> str:
        return (
            "No audio backend found.\n"
            "On Windows, Build 72+ uses PowerShell media (no pygame needed).\n"
            "Or install ffmpeg and add ffplay to PATH."
        )

    def set_volume(self, volume: float) -> None:
        self._volume = max(0.0, min(1.0, float(volume)))
        if self._backend == "pygame" and self._pygame is not None:
            try:
                self._pygame.mixer.music.set_volume(self._volume)
            except Exception:
                log_exception()

    def _mci(self, command: str) -> int:
        import ctypes

        return int(ctypes.windll.winmm.mciSendStringW(command, None, 0, None))

    def _mci_stop_close(self) -> None:
        try:
            self._mci(f"stop {self._mci_alias}")
        except Exception:
            log_exception()
        try:
            self._mci(f"close {self._mci_alias}")
        except Exception:
            log_exception()

    def _short_path(self, path: Path) -> str:
        """8.3 short path helps older MCI APIs with spaces/long names."""
        try:
            import ctypes

            buf = ctypes.create_unicode_buffer(512)
            get = ctypes.windll.kernel32.GetShortPathNameW
            rc = get(str(path.resolve()), buf, 512)
            if rc:
                return buf.value
        except Exception:
            log_exception()
        return str(path.resolve())

    def _file_uri(self, path: Path) -> str:
        # file:///C:/path/with%20spaces.mp3
        resolved = path.resolve().as_posix()
        if not resolved.startswith("/"):
            # Windows drive letter
            return "file:///" + resolved
        return "file://" + resolved

    def _stop_flag_path(self) -> Path:
        if self._stop_flag is None:
            self._stop_flag = Path(tempfile.gettempdir()) / f"forge_audio_{self._id}.flag"
        return self._stop_flag

    def _clear_stop_flag(self) -> None:
        flag = self._stop_flag_path()
        try:
            if flag.exists():
                flag.unlink()
        except Exception:
            log_exception()

    def _write_stop_flag(self) -> None:
        try:
            self._stop_flag_path().write_text("stop", encoding="utf-8")
        except Exception:
            log_exception()

    def _play_wpf(self, file_path: Path, *, loop: bool) -> None:
        """Play via PowerShell System.Windows.Media.MediaPlayer."""
        self._clear_stop_flag()
        uri = self._file_uri(file_path).replace("'", "''")
        stop_flag = str(self._stop_flag_path()).replace("'", "''")
        vol = max(0.0, min(1.0, self._volume))
        loop_int = 1 if loop else 0
        # Single-quoted here-string body built carefully for PowerShell
        ps = f"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationCore
$uri = [Uri]::new('{uri}')
$stopFlag = '{stop_flag}'
$loop = {loop_int}
$player = New-Object System.Windows.Media.MediaPlayer
$player.Volume = {vol}
$player.Open($uri)
# Wait briefly for media to open
$deadline = (Get-Date).AddSeconds(8)
while (-not $player.NaturalDuration.HasTimeSpan) {{
  if ((Get-Date) -gt $deadline) {{ break }}
  if (Test-Path -LiteralPath $stopFlag) {{ exit 0 }}
  Start-Sleep -Milliseconds 100
}}
do {{
  $player.Position = [TimeSpan]::Zero
  $player.Play()
  while ($true) {{
    if (Test-Path -LiteralPath $stopFlag) {{
      $player.Stop()
      exit 0
    }}
    Start-Sleep -Milliseconds 200
    if ($player.NaturalDuration.HasTimeSpan) {{
      if ($player.Position -ge $player.NaturalDuration.TimeSpan) {{ break }}
    }}
  }}
  $player.Stop()
}} while ($loop -eq 1)
"""
        self._proc = subprocess.Popen(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                ps,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        # Brief settle; if process dies immediately, raise
        time.sleep(0.4)
        if self._proc.poll() is not None:
            raise RuntimeError(
                "Windows media player exited immediately.\n"
                "Check that the MP3 plays in Windows Media Player, then try again."
            )

    def _play_mci(self, file_path: Path, *, loop: bool) -> None:
        self._mci_stop_close()
        abs_path = self._short_path(file_path)
        attempts = [
            f'open "{abs_path}" type mpegvideo alias {self._mci_alias}',
            f'open "{abs_path}" type MPEGVideo alias {self._mci_alias}',
            f'open "{abs_path}" alias {self._mci_alias}',
        ]
        last_rc = 1
        for cmd in attempts:
            last_rc = self._mci(cmd)
            if last_rc == 0:
                break
        if last_rc != 0:
            raise RuntimeError(f"MCI open failed (error {last_rc}).")
        play_cmd = f"play {self._mci_alias} repeat" if loop else f"play {self._mci_alias}"
        rc = self._mci(play_cmd)
        if rc != 0:
            rc = self._mci(f"play {self._mci_alias}")
        if rc != 0:
            self._mci_stop_close()
            raise RuntimeError(f"MCI play failed (error {rc}).")

    # pygame-ce (SDL_mixer) cannot decode these; it then tries libxmp and fails with
    # "xmp: unrecognized file format". Send them straight to the Windows players.
    PYGAME_SKIP = {".m4a", ".aac", ".wma", ".mp4", ".m4b", ".3gp", ".m4v", ".mov", ".wmv"}

    def _backend_chain(self, suffix: str) -> list[str]:
        chain = []
        if self._pygame is not None and suffix not in self.PYGAME_SKIP:
            chain.append("pygame")
        if sys.platform.startswith("win"):
            chain += ["wpf", "mci"]
        if shutil.which("ffplay"):
            chain.append("ffplay")
        if sys.platform.startswith("win") and suffix == ".wav":
            chain.append("winsound")
        if self._backend not in chain and self._backend not in ("none", "pygame"):
            chain.insert(0, self._backend)
        return chain

    def play(self, path: str | Path, *, loop: bool = False) -> None:
        if self._backend == "none":
            self.refresh_backend()
        file_path = Path(path)
        if not file_path.is_file():
            raise FileNotFoundError(f"Audio file not found: {file_path}")
        self.stop()
        self._path = file_path
        self._loop = bool(loop)
        errors = []
        for name in self._backend_chain(file_path.suffix.lower()):
            try:
                getattr(self, f"_play_with_{name}")(file_path)
                self._active = name
                if errors:  # an earlier backend failed but this one works: log only, no popup
                    log_message(f"Audio: played {file_path.name} with {name} after: " + " | ".join(errors))
                return
            except Exception as error:
                errors.append(f"{name}: {error}")
                log_exception()
                try:
                    self._stop_active(name)
                except Exception:
                    log_exception()
        self._active = "none"
        if not errors:
            raise RuntimeError(self.install_hint())
        raise RuntimeError(
            f"Could not play {file_path.name}.\n" + "\n".join(errors)
            + "\n\nConfirm the file opens in Windows Media Player."
        )

    def _play_with_pygame(self, file_path: Path) -> None:
        pg = self._pygame
        if self._role == "sfx":
            self._sound = pg.mixer.Sound(str(file_path))
            self._sound.set_volume(self._volume)
            self._channel = pg.mixer.find_channel(True)
            if self._channel is not None:
                self._channel.play(self._sound, loops=-1 if self._loop else 0)
            return
        pg.mixer.music.load(str(file_path))
        pg.mixer.music.set_volume(self._volume)
        pg.mixer.music.play(-1 if self._loop else 0)

    def _play_with_wpf(self, file_path: Path) -> None:
        self._play_wpf(file_path, loop=self._loop)

    def _play_with_mci(self, file_path: Path) -> None:
        self._play_mci(file_path, loop=self._loop)

    def _play_with_ffplay(self, file_path: Path) -> None:
        cmd = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", "-volume", str(int(self._volume * 100))]
        if self._loop:
            cmd.extend(["-loop", "0"])
        cmd.append(str(file_path))
        kwargs = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
        if sys.platform.startswith("win"):
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self._proc = subprocess.Popen(cmd, **kwargs)

    def _play_with_winsound(self, file_path: Path) -> None:
        import winsound
        flags = winsound.SND_FILENAME | winsound.SND_ASYNC
        if self._loop:
            flags |= winsound.SND_LOOP
        winsound.PlaySound(str(file_path), flags)

    def _stop_active(self, name: str) -> None:
        """Quietly undo a half-started backend before trying the next one."""
        if name == "pygame" and self._pygame is not None:
            if self._role == "sfx" and self._channel is not None:
                self._channel.stop()
            elif self._role != "sfx":
                self._pygame.mixer.music.stop()
        elif name in ("wpf", "ffplay") and self._proc is not None:
            if self._proc.poll() is None:
                self._proc.terminate()
            self._proc = None
        elif name == "mci":
            self._mci_stop_close()

    def stop(self) -> None:
        self._write_stop_flag()
        if self._pygame is not None:
            try:
                if self._role == "sfx" and self._channel is not None:
                    self._channel.stop()
                elif self._role != "sfx":
                    self._pygame.mixer.music.stop()
            except Exception:
                log_exception()
        try:
            self._mci_stop_close()
        except Exception:
            log_exception()
        if self._proc is not None:
            try:
                self._proc.terminate()
                self._proc.wait(timeout=2.0)
            except Exception:
                try:
                    self._proc.kill()
                except Exception:
                    log_exception()
            self._proc = None
        try:
            import winsound

            winsound.PlaySound(None, winsound.SND_PURGE)
        except Exception:
            log_exception()
        # small delay so PS sees the flag
        time.sleep(0.15)
        self._clear_stop_flag()

    def is_playing(self) -> bool:
        if getattr(self, "_active", "") == "pygame" and self._pygame is not None:
            try:
                return bool(self._pygame.mixer.music.get_busy())
            except Exception:
                return False
        if self._proc is not None:
            return self._proc.poll() is None
        return False
