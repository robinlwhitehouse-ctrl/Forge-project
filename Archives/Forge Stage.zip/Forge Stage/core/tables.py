"""Universal random tables for Forge Next."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from uuid import uuid4
import json
import random

from .projects import ForgeNextProject

TABLE_TYPES = (
    "Encounter",
    "Treasure",
    "Rumor",
    "Weather",
    "Complication",
    "Dressing",
    "Reaction",
    "Name",
    "Other",
)

LINK_KINDS = (
    "",
    "Table",
    "Encounter",
    "Monster",
    "NPC",
    "Item",
    "Weapon",
    "Armor",
    "Artifact",
    "Spell",
    "Feat",
    "Location",
    "Map",
    "Script",
    "Quest",
)


def new_table_id() -> str:
    return f"TBL-{uuid4().hex[:8].upper()}"


def new_row_id() -> str:
    return f"TROW-{uuid4().hex[:8].upper()}"


@dataclass
class TableRow:
    id: str
    low: int = 1
    high: int = 1
    weight: int = 1
    text: str = ""
    link_kind: str = ""
    link_id: str = ""
    unique: bool = False
    image_path: str = ""

    @classmethod
    def from_dict(cls, row: dict) -> "TableRow":
        try:
            weight = int(row.get("weight") or 1)
        except (TypeError, ValueError):
            weight = 1
        try:
            low = int(row.get("low") or row.get("min") or 0)
        except (TypeError, ValueError):
            low = 0
        try:
            high = int(row.get("high") or row.get("max") or 0)
        except (TypeError, ValueError):
            high = 0
        if low <= 0 or high <= 0:
            low = 1
            high = max(1, weight)
        if high < low:
            low, high = high, low
        return cls(
            id=str(row.get("id") or new_row_id()),
            low=low,
            high=high,
            weight=max(1, high - low + 1),
            text=str(row.get("text") or ""),
            link_kind=str(row.get("link_kind") or ""),
            link_id=str(row.get("link_id") or ""),
            unique=bool(row.get("unique", False)),
            image_path=str(row.get("image_path") or ""),
        )

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class RandomTable:
    table_id: str
    name: str = "Untitled table"
    table_type: str = "Encounter"
    notes: str = ""
    die: int = 20
    image_path: str = ""
    rows: list[TableRow] = field(default_factory=list)

    @classmethod
    def from_dict(cls, row: dict) -> "RandomTable":
        rows = [
            TableRow.from_dict(r)
            for r in (row.get("rows") or [])
            if isinstance(r, dict)
        ]
        return cls(
            table_id=str(row.get("table_id") or new_table_id()),
            name=str(row.get("name") or "Untitled table"),
            table_type=str(row.get("table_type") or "Encounter"),
            notes=str(row.get("notes") or ""),
            die=int(row.get("die") or 20) if str(row.get("die") or "").isdigit() else 20,
            image_path=str(row.get("image_path") or ""),
            rows=rows,
        )

    def to_dict(self) -> dict:
        return {
            "table_id": self.table_id,
            "name": self.name,
            "table_type": self.table_type,
            "notes": self.notes,
            "die": int(self.die or 20),
            "image_path": self.image_path or "",
            "rows": [r.to_dict() for r in self.rows],
        }


class TableRepository:
    def __init__(self, project: ForgeNextProject) -> None:
        self.project = project
        self.path = project.root / "data" / "records" / "tables.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def tables(self) -> list[RandomTable]:
        return [RandomTable.from_dict(row) for row in self._read() if isinstance(row, dict)]

    def get(self, table_id: str) -> RandomTable | None:
        for table in self.tables():
            if table.table_id == table_id:
                return table
        return None

    def save_table(self, table: RandomTable) -> RandomTable:
        table.name = (table.name or "").strip() or "Untitled table"
        rows = [t.to_dict() for t in self.tables() if t.table_id != table.table_id]
        rows.append(table.to_dict())
        rows.sort(key=lambda r: str(r.get("name") or "").lower())
        self._write(rows)
        return table

    def delete_table(self, table_id: str) -> None:
        rows = [t.to_dict() for t in self.tables() if t.table_id != table_id]
        self._write(rows)

    def roll(self, table: RandomTable, used_ids: list[str] | None = None) -> tuple[int, TableRow] | None:
        used = set(used_ids or [])
        die = int(table.die or 20)
        if die < 2:
            die = 20
        pick = random.randint(1, die)
        available = [
            row for row in table.rows
            if not (row.unique and row.id in used)
        ]
        if not available:
            available = list(table.rows)
        for row in available:
            try:
                lo = int(getattr(row, "low", 0) or 0)
                hi = int(getattr(row, "high", 0) or 0)
            except (TypeError, ValueError):
                continue
            if lo <= pick <= hi:
                return pick, row
        return pick, None
