"""Harvested materials: herbs, animal parts, and the like."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
from uuid import uuid4
import json

from .projects import ForgeNextProject

KINDS = ("Herb", "Animal part", "Hide", "Bone", "Plant", "Fungus", "Mineral", "Other")
CONDITIONS = ("Fresh", "Dried", "Preserved", "Cured", "Spoiled")


def new_material_id() -> str:
    return f"MAT-{uuid4().hex[:8].upper()}"


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


@dataclass
class HarvestMaterial:
    material_id: str
    name: str = "Untitled"
    kind: str = "Herb"
    source: str = ""
    quantity: int = 0
    unit: str = ""
    condition: str = "Fresh"
    location: str = ""
    uses: str = ""
    notes: str = ""
    linked_id: str = ""
    linked_name: str = ""
    updated: str = ""

    @classmethod
    def from_dict(cls, row: dict) -> "HarvestMaterial":
        return cls(
            material_id=str(row.get("material_id") or new_material_id()),
            name=str(row.get("name") or "Untitled"),
            kind=str(row.get("kind") or "Herb"),
            source=str(row.get("source") or ""),
            quantity=int(row.get("quantity") or 0),
            unit=str(row.get("unit") or ""),
            condition=str(row.get("condition") or "Fresh"),
            location=str(row.get("location") or ""),
            uses=str(row.get("uses") or ""),
            notes=str(row.get("notes") or ""),
            linked_id=str(row.get("linked_id") or ""),
            linked_name=str(row.get("linked_name") or ""),
            updated=str(row.get("updated") or ""),
        )


class MaterialsRepository:
    def __init__(self, project: ForgeNextProject) -> None:
        self.project = project
        self.path = project.root / "data" / "materials.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        try:
            with self.path.open("r", encoding="utf-8") as handle:
                value = json.load(handle)
        except (OSError, json.JSONDecodeError):
            return []
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def rows(self) -> list[HarvestMaterial]:
        items = [HarvestMaterial.from_dict(row) for row in self._read() if isinstance(row, dict)]
        items.sort(key=lambda row: (row.kind, row.name.lower()))
        return items

    def get(self, material_id: str) -> HarvestMaterial | None:
        return next((row for row in self.rows() if row.material_id == material_id), None)

    def save(self, record: HarvestMaterial) -> HarvestMaterial:
        record.updated = _now()
        rows = self._read()
        payload = asdict(record)
        for index, row in enumerate(rows):
            if row.get("material_id") == record.material_id:
                rows[index] = payload
                self._write(rows)
                return record
        rows.append(payload)
        self._write(rows)
        return record

    def delete(self, material_id: str) -> None:
        self._write([row for row in self._read() if row.get("material_id") != material_id])
