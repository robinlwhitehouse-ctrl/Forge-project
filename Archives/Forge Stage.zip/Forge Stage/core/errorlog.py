"""Tiny never-raising error log shared by Library and Stage.

Appends timestamped tracebacks to <app folder>/logs/forge_errors.log, rotating
at ~1 MB with one backup (forge_errors.log.1).  Repeats from the same code
location are throttled (first 3, then every 100th) so hot paths stay cheap.
"""

from __future__ import annotations

import sys
import threading
import traceback
from datetime import datetime
from pathlib import Path

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
LOG_FILE = LOG_DIR / "forge_errors.log"
MAX_BYTES = 1_000_000
_lock = threading.Lock()
_counts: dict[str, int] = {}


def _site(depth: int = 2) -> str:
    try:
        frame = sys._getframe(depth)
        return f"{Path(frame.f_code.co_filename).name}:{frame.f_lineno} {frame.f_code.co_name}"
    except Exception:
        return "?"


def _should_log(key: str) -> tuple[bool, int]:
    count = _counts.get(key, 0) + 1
    _counts[key] = count
    return (count <= 3 or count % 100 == 0), count


def _write(text: str) -> None:
    try:
        with _lock:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            try:
                if LOG_FILE.exists() and LOG_FILE.stat().st_size > MAX_BYTES:
                    backup = LOG_FILE.with_name(LOG_FILE.name + ".1")
                    if backup.exists():
                        backup.unlink()
                    LOG_FILE.replace(backup)
            except OSError:
                pass
            with LOG_FILE.open("a", encoding="utf-8") as handle:
                handle.write(text)
    except Exception:
        pass  # logging must never raise


def log_exception(context: str = "") -> None:
    """Call inside an except block. Logs the current traceback; never raises."""
    try:
        site = context or _site()
        ok, count = _should_log(site)
        if not ok:
            return
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        repeat = f" (occurrence {count})" if count > 1 else ""
        _write(f"[{stamp}] {site}{repeat}\n{traceback.format_exc()}\n")
    except Exception:
        pass


def log_message(message: str, context: str = "") -> None:
    try:
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        _write(f"[{stamp}] {context or _site()}: {message}\n")
    except Exception:
        pass


def _log_triplet(kind: str, exc_type, exc, tb) -> None:
    try:
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        body = "".join(traceback.format_exception(exc_type, exc, tb))
        _write(f"[{stamp}] {kind}\n{body}\n")
    except Exception:
        pass


def install(tk_root=None) -> None:
    """Log unhandled errors (sys.excepthook and Tk callbacks), keeping old behavior."""
    try:
        previous = sys.excepthook

        def hook(exc_type, exc, tb):
            _log_triplet("Unhandled exception", exc_type, exc, tb)
            previous(exc_type, exc, tb)

        if not getattr(sys.excepthook, "_forge_errorlog", False):
            hook._forge_errorlog = True  # type: ignore[attr-defined]
            sys.excepthook = hook
        if tk_root is not None and not getattr(tk_root, "_forge_errorlog", False):
            original = tk_root.report_callback_exception

            def report(exc_type, exc, tb):
                _log_triplet("Unhandled Tk callback error", exc_type, exc, tb)
                original(exc_type, exc, tb)

            tk_root.report_callback_exception = report
            tk_root._forge_errorlog = True
    except Exception:
        pass
