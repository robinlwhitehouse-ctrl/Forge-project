"""Encounter-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


ENCOUNTER_TYPES = (
    "Combat", "Social", "Exploration", "Puzzle", "Trap",
    "Chase", "Ambush", "Boss", "Random", "Mixed", "Other",
)
ENCOUNTER_DIFFICULTIES = (
    "Trivial", "Easy", "Moderate", "Hard", "Deadly", "Deadly+",
)
ENCOUNTER_ENVIRONMENTS = (
    "Dungeon", "Wilderness", "Urban", "Underground", "Aquatic",
    "Aerial", "Planar", "Indoor", "Outdoor", "Other",
)


@dataclass(frozen=True)
class EncounterDetails:
    record_id: str
    encounter_type: str = "Combat"
    difficulty: str = "Moderate"
    environment: str = "Dungeon"
    party_level: str = ""
    challenge_rating: str = ""
    location_note: str = ""


@dataclass(frozen=True)
class ForgeNextEncounter:
    record: ForgeNextRecord
    details: EncounterDetails


class EncounterRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "encounters.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def encounters(self) -> list[ForgeNextEncounter]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Encounter"
        }
        details_by_id = {
            row.get("record_id", ""): EncounterDetails(**row)
            for row in self._read()
        }
        return [
            ForgeNextEncounter(
                record,
                details_by_id.get(record.record_id, EncounterDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_encounter(
        self, name: str, encounter_type: str, difficulty: str,
        environment: str, party_level: str, challenge_rating: str,
        location_note: str, status: str, description: str,
    ) -> ForgeNextEncounter:
        record = self.records.create_record("Encounter", name, status, description)
        details = EncounterDetails(
            record.record_id, encounter_type or "Combat", difficulty or "Moderate",
            environment or "Dungeon", party_level.strip(),
            challenge_rating.strip(), location_note.strip(),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextEncounter(record, details)

    def update_encounter(
        self, record_id: str, name: str, encounter_type: str, difficulty: str,
        environment: str, party_level: str, challenge_rating: str,
        location_note: str, status: str, description: str,
    ) -> ForgeNextEncounter:
        record = self.records.update_record(record_id, name, status, description)
        details = EncounterDetails(
            record_id, encounter_type or "Combat", difficulty or "Moderate",
            environment or "Dungeon", party_level.strip(),
            challenge_rating.strip(), location_note.strip(),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextEncounter(record, details)
