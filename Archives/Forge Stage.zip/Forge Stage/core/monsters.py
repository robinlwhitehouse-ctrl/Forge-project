"""Monster-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


CREATURE_TYPES = (
    "Aberration", "Beast", "Celestial", "Construct", "Dragon", "Elemental",
    "Fey", "Fiend", "Giant", "Humanoid", "Monstrosity", "Ooze", "Plant", "Undead", "Other",
)
CREATURE_SIZES = ("Tiny", "Small", "Medium", "Large", "Huge", "Gargantuan")


@dataclass(frozen=True)
class MonsterDetails:
    record_id: str
    creature_type: str = "Other"
    size: str = "Medium"
    alignment: str = "Unaligned"
    challenge_rating: str = ""
    # Combat snapshot for tokens / stage
    ac: str = ""
    hp: str = ""
    max_hp: str = ""
    attack: str = ""
    skills: str = ""
    speed: str = ""
    str_score: str = ""
    dex_score: str = ""
    con_score: str = ""
    int_score: str = ""
    wis_score: str = ""
    cha_score: str = ""
    damage_vulnerabilities: str = ""
    damage_resistances: str = ""
    damage_immunities: str = ""
    condition_immunities: str = ""
    senses: str = ""
    languages: str = ""
    xp: str = ""
    traits: str = ""
    actions: str = ""
    bonus_actions: str = ""
    reactions: str = ""
    legendary: str = ""
    watch_use: str = "Quest only"


def _details_from_row(row: dict) -> MonsterDetails:
    return MonsterDetails(
        record_id=str(row.get("record_id", "") or ""),
        creature_type=str(row.get("creature_type", "Other") or "Other"),
        size=str(row.get("size", "Medium") or "Medium"),
        alignment=str(row.get("alignment", "Unaligned") or "Unaligned"),
        challenge_rating=str(row.get("challenge_rating", "") or ""),
        ac=str(row.get("ac", "") or ""),
        hp=str(row.get("hp", "") or ""),
        max_hp=str(row.get("max_hp", "") or ""),
        attack=str(row.get("attack", "") or ""),
        skills=str(row.get("skills", "") or ""),
        speed=str(row.get("speed", "") or ""),
        str_score=str(row.get("str_score", "") or ""),
        dex_score=str(row.get("dex_score", "") or ""),
        con_score=str(row.get("con_score", "") or ""),
        int_score=str(row.get("int_score", "") or ""),
        wis_score=str(row.get("wis_score", "") or ""),
        cha_score=str(row.get("cha_score", "") or ""),
        damage_vulnerabilities=str(row.get("damage_vulnerabilities", "") or ""),
        damage_resistances=str(row.get("damage_resistances", "") or ""),
        damage_immunities=str(row.get("damage_immunities", "") or ""),
        condition_immunities=str(row.get("condition_immunities", "") or ""),
        senses=str(row.get("senses", "") or ""),
        languages=str(row.get("languages", "") or ""),
        xp=str(row.get("xp", "") or ""),
        traits=str(row.get("traits", "") or ""),
        actions=str(row.get("actions", "") or ""),
        bonus_actions=str(row.get("bonus_actions", "") or ""),
        reactions=str(row.get("reactions", "") or ""),
        legendary=str(row.get("legendary", "") or ""),
        watch_use=str(row.get("watch_use", "") or "Quest only"),
    )


@dataclass(frozen=True)
class ForgeNextMonster:
    record: ForgeNextRecord
    details: MonsterDetails


class MonsterRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "monsters.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def monsters(self) -> list[ForgeNextMonster]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Monster"
        }
        details_by_id = {
            row.get("record_id", ""): _details_from_row(row)
            for row in self._read()
            if isinstance(row, dict)
        }
        return [
            ForgeNextMonster(
                record,
                details_by_id.get(record.record_id, MonsterDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_monster(
        self,
        name: str,
        creature_type: str,
        size: str,
        alignment: str,
        challenge_rating: str,
        status: str,
        description: str,
        ac: str = "",
        hp: str = "",
        max_hp: str = "",
        attack: str = "",
        skills: str = "",
        extra: dict | None = None,
    ) -> ForgeNextMonster:
        extra = extra or {}
        record = self.records.create_record("Monster", name, status, description)
        details = MonsterDetails(
            record.record_id,
            creature_type or "Other",
            size or "Medium",
            alignment.strip() or "Unaligned",
            challenge_rating.strip(),
            ac.strip(),
            hp.strip(),
            max_hp.strip(),
            attack.strip(),
            skills.strip(),
            extra.get("speed", ""),
            extra.get("str_score", ""),
            extra.get("dex_score", ""),
            extra.get("con_score", ""),
            extra.get("int_score", ""),
            extra.get("wis_score", ""),
            extra.get("cha_score", ""),
            extra.get("damage_vulnerabilities", ""),
            extra.get("damage_resistances", ""),
            extra.get("damage_immunities", ""),
            extra.get("condition_immunities", ""),
            extra.get("senses", ""),
            extra.get("languages", ""),
            extra.get("xp", ""),
            extra.get("traits", ""),
            extra.get("actions", ""),
            extra.get("bonus_actions", ""),
            extra.get("reactions", ""),
            extra.get("legendary", ""),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextMonster(record, details)

    def update_monster(
        self,
        record_id: str,
        name: str,
        creature_type: str,
        size: str,
        alignment: str,
        challenge_rating: str,
        status: str,
        description: str,
        ac: str = "",
        hp: str = "",
        max_hp: str = "",
        attack: str = "",
        skills: str = "",
        extra: dict | None = None,
    ) -> ForgeNextMonster:
        extra = extra or {}
        record = self.records.update_record(record_id, name, status, description)
        details = MonsterDetails(
            record_id,
            creature_type or "Other",
            size or "Medium",
            alignment.strip() or "Unaligned",
            challenge_rating.strip(),
            ac.strip(),
            hp.strip(),
            max_hp.strip(),
            attack.strip(),
            skills.strip(),
            extra.get("speed", ""),
            extra.get("str_score", ""),
            extra.get("dex_score", ""),
            extra.get("con_score", ""),
            extra.get("int_score", ""),
            extra.get("wis_score", ""),
            extra.get("cha_score", ""),
            extra.get("damage_vulnerabilities", ""),
            extra.get("damage_resistances", ""),
            extra.get("damage_immunities", ""),
            extra.get("condition_immunities", ""),
            extra.get("senses", ""),
            extra.get("languages", ""),
            extra.get("xp", ""),
            extra.get("traits", ""),
            extra.get("actions", ""),
            extra.get("bonus_actions", ""),
            extra.get("reactions", ""),
            extra.get("legendary", ""),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextMonster(record, details)
