"""Session scripts — ordered story narrations with optional choices."""

from __future__ import annotations

import re

from dataclasses import dataclass, field
import json
from uuid import uuid4

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository
from .errorlog import log_exception


def new_beat_id() -> str:
    return f"beat_{uuid4().hex[:10]}"


def new_choice_id() -> str:
    return f"ch_{uuid4().hex[:8]}"


@dataclass
class BeatChoice:
    id: str
    text: str = ""
    to_beat_id: str = ""
    consequence: str = ""

    @classmethod
    def from_dict(cls, row: dict) -> "BeatChoice":
        return cls(
            id=str(row.get("id") or new_choice_id()),
            text=str(row.get("text") or ""),
            to_beat_id=str(row.get("to_beat_id") or row.get("toBeatId") or ""),
            consequence=str(row.get("consequence") or ""),
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "text": self.text,
            "to_beat_id": self.to_beat_id,
            "consequence": self.consequence,
        }


@dataclass
class ScriptBeat:
    id: str
    title: str = "Beat"
    read_aloud: str = ""
    gm_notes: str = ""
    table_notes: str = ""
    items: str = ""
    dm_items: str = ""
    quests: str = ""
    cast: str = ""
    places: str = ""
    revisit_read_aloud: str = ""
    revisit_gm_notes: str = ""
    music_path: str = ""
    music_loop: bool = False
    continue_to_id: str = ""
    day_number: int = 0
    time_of_day: str = ""
    rest: str = ""
    advance_minutes: int = 0
    audio_clips: list = field(default_factory=list)
    videos: list = field(default_factory=list)  # project-relative video paths (optional)
    choices: list[BeatChoice] = field(default_factory=list)

    @classmethod
    def from_dict(cls, row: dict) -> "ScriptBeat":
        choices = [
            BeatChoice.from_dict(c)
            for c in (row.get("choices") or [])
            if isinstance(c, dict)
        ]
        return cls(
            id=str(row.get("id") or new_beat_id()),
            title=str(row.get("title") or "Beat"),
            read_aloud=str(row.get("read_aloud") or row.get("readAloud") or ""),
            gm_notes=str(row.get("gm_notes") or row.get("gmNotes") or ""),
            table_notes=str(row.get("table_notes") or ""),
            items=str(row.get("items") or ""),
            dm_items=str(row.get("dm_items") or ""),
            quests=str(row.get("quests") or ""),
            cast=str(row.get("cast") or ""),
            places=str(row.get("places") or ""),
            revisit_read_aloud=str(row.get("revisit_read_aloud") or ""),
            revisit_gm_notes=str(row.get("revisit_gm_notes") or ""),
            music_path=str(row.get("music_path") or ""),
            music_loop=bool(row.get("music_loop", False)),
            continue_to_id=str(row.get("continue_to_id") or row.get("continueToId") or ""),
            day_number=int(row.get("day_number") or 0),
            time_of_day=str(row.get("time_of_day") or ""),
            rest=str(row.get("rest") or ""),
            advance_minutes=int(row.get("advance_minutes") or 0),
            audio_clips=list(row.get("audio_clips") or []),
            videos=[str(v) for v in (row.get("videos") or []) if v],
            choices=choices,
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "read_aloud": self.read_aloud,
            "gm_notes": self.gm_notes,
            "table_notes": self.table_notes,
            "items": self.items,
            "dm_items": self.dm_items,
            "quests": self.quests,
            "cast": self.cast,
            "places": self.places,
            "revisit_read_aloud": self.revisit_read_aloud,
            "revisit_gm_notes": self.revisit_gm_notes,
            "music_path": self.music_path,
            "music_loop": bool(self.music_loop),
            "continue_to_id": self.continue_to_id,
            "day_number": int(self.day_number or 0),
            "time_of_day": self.time_of_day or "",
            "rest": self.rest or "",
            "advance_minutes": int(self.advance_minutes or 0),
            "audio_clips": list(self.audio_clips or []),
            "videos": list(self.videos or []),
            "choices": [c.to_dict() for c in self.choices],
        }


@dataclass
class ScriptDetails:
    record_id: str
    linked_quest_id: str = ""
    linked_session_id: str = ""
    beats: list[ScriptBeat] = field(default_factory=list)
    # Keep display name in details too so list survives if records.json is out of sync
    name: str = ""
    status: str = "Draft"
    description: str = ""
    next_script_id: str = ""
    music_path: str = ""
    music_loop: bool = False

    def to_row(self) -> dict:
        return {
            "record_id": self.record_id,
            "name": self.name,
            "status": self.status,
            "description": self.description,
            "linked_quest_id": self.linked_quest_id,
            "linked_session_id": self.linked_session_id,
            "next_script_id": self.next_script_id,
            "music_path": self.music_path,
            "music_loop": bool(self.music_loop),
            "beats": [b.to_dict() for b in self.beats],
        }

    @classmethod
    def from_row(cls, row: dict) -> "ScriptDetails":
        beats = [
            ScriptBeat.from_dict(b)
            for b in (row.get("beats") or [])
            if isinstance(b, dict)
        ]
        return cls(
            record_id=str(row.get("record_id") or ""),
            linked_quest_id=str(row.get("linked_quest_id") or ""),
            linked_session_id=str(row.get("linked_session_id") or ""),
            beats=beats,
            name=str(row.get("name") or ""),
            status=str(row.get("status") or "Draft"),
            description=str(row.get("description") or ""),
            next_script_id=str(row.get("next_script_id") or ""),
            music_path=str(row.get("music_path") or ""),
            music_loop=bool(row.get("music_loop", False)),
        )


@dataclass
class ForgeNextScript:
    record: ForgeNextRecord
    details: ScriptDetails



def _script_sort_key(name: str):
    """Chapter 2 before Chapter 10. Numbers compare as numbers."""
    text = (name or "").lower()
    parts = re.split(r"(\d+)", text)
    key = []
    for part in parts:
        if part.isdigit():
            key.append((0, int(part), -len(part)))
        else:
            key.append((1, part))
    return key


class ScriptRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "scripts.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        try:
            with self.path.open("r", encoding="utf-8") as handle:
                value = json.load(handle)
            return value if isinstance(value, list) else []
        except (OSError, json.JSONDecodeError):
            return []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def scripts(self) -> list[ForgeNextScript]:
        """Load scripts from scripts.json; repair missing records if needed."""
        detail_rows = [row for row in self._read() if isinstance(row, dict) and row.get("record_id")]
        records_by_id = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Script"
        }
        result: list[ForgeNextScript] = []
        repaired = False
        for row in detail_rows:
            details = ScriptDetails.from_row(row)
            rid = details.record_id
            record = records_by_id.get(rid)
            if record is None:
                # details file has data but records.json missing the Script — recreate shell record
                name = details.name or f"Script {rid[-6:]}"
                try:
                    record = self.records.create_record(
                        "Script",
                        name,
                        details.status or "Draft",
                        details.description or "",
                    )
                    # rewrite detail row to new record_id
                    old_id = rid
                    details.record_id = record.record_id
                    details.name = record.name
                    detail_rows = [
                        (details.to_row() if r.get("record_id") == old_id else r)
                        for r in detail_rows
                    ]
                    repaired = True
                    rid = record.record_id
                except Exception:
                    # synthesize in-memory only
                    from datetime import datetime, timezone
                    record = ForgeNextRecord(
                        record_id=rid,
                        record_type="Script",
                        name=details.name or "Script",
                        status=details.status or "Draft",
                        description=details.description or "",
                        created_at=datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
                    )
            else:
                # keep details name in sync if empty
                if not details.name:
                    details.name = record.name
            result.append(ForgeNextScript(record, details))
        if repaired:
            try:
                self._write([ScriptDetails.from_row(r).to_row() if isinstance(r, dict) else r for r in detail_rows])
            except Exception:
                log_exception()
        result.sort(key=lambda s: _script_sort_key(s.record.name or ""))
        return result

    def create_script(
        self,
        name: str,
        status: str,
        description: str,
        linked_quest_id: str = "",
        linked_session_id: str = "",
        beats: list[ScriptBeat] | None = None,
        next_script_id: str = "",
        music_path: str = "",
        music_loop: bool = False,
    ) -> ForgeNextScript:
        name = (name or "").strip() or "Untitled script"
        record = self.records.create_record("Script", name, status or "Draft", description or "")
        if not beats:
            beats = [
                ScriptBeat(
                    id=new_beat_id(),
                    title="Opening",
                    read_aloud="",
                    gm_notes="",
                    choices=[],
                )
            ]
        details = ScriptDetails(
            record_id=record.record_id,
            linked_quest_id=(linked_quest_id or "").strip(),
            linked_session_id=(linked_session_id or "").strip(),
            beats=list(beats),
            name=record.name,
            status=record.status,
            description=record.description,
            next_script_id=(next_script_id or "").strip(),
            music_path=(music_path or "").strip(),
            music_loop=bool(music_loop),
        )
        rows = [r for r in self._read() if r.get("record_id") != record.record_id]
        rows.append(details.to_row())
        self._write(rows)
        # verify
        if not self.path.exists():
            raise RuntimeError(f"Failed to write {self.path}")
        return ForgeNextScript(record, details)

    def update_script(
        self,
        record_id: str,
        name: str,
        status: str,
        description: str,
        linked_quest_id: str = "",
        linked_session_id: str = "",
        beats: list[ScriptBeat] | None = None,
        next_script_id: str = "",
        music_path: str = "",
        music_loop: bool = False,
    ) -> ForgeNextScript:
        name = (name or "").strip() or "Untitled script"
        try:
            record = self.records.update_record(
                record_id, name, status or "Draft", description or ""
            )
        except Exception:
            # record missing — create new
            record = self.records.create_record(
                "Script", name, status or "Draft", description or ""
            )
            record_id = record.record_id
        existing = None
        for row in self._read():
            if row.get("record_id") == record_id:
                existing = ScriptDetails.from_row(row)
                break
        if beats is None:
            beats = existing.beats if existing else []
        details = ScriptDetails(
            record_id=record_id,
            linked_quest_id=(linked_quest_id or "").strip(),
            linked_session_id=(linked_session_id or "").strip(),
            beats=list(beats),
            name=name,
            status=status or "Draft",
            description=description or "",
            next_script_id=(next_script_id or "").strip(),
            music_path=(music_path or "").strip(),
            music_loop=bool(music_loop),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(details.to_row())
        self._write(rows)
        if not self.path.exists():
            raise RuntimeError(f"Failed to write {self.path}")
        return ForgeNextScript(record, details)
