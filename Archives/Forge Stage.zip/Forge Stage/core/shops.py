"""Shop-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


SHOP_TYPES = (
    "General Store",
    "Trading Post",
    "Provisioner",
    "Market Stall",
    "Blacksmith",
    "Armorer",
    "Weapons",
    "Fletcher",
    "Bowyer",
    "Leatherworker",
    "Tanner",
    "Alchemist",
    "Apothecary",
    "Herbalist",
    "Magic Shop",
    "Enchanter",
    "Scroll Shop",
    "Tavern",
    "Inn",
    "Brewer",
    "Baker",
    "Butcher",
    "Miller",
    "Stable",
    "Wagonwright",
    "Carpenter",
    "Mason",
    "Shipwright",
    "Jeweler",
    "Clothier",
    "Cobbler",
    "Bookstore",
    "Scribe",
    "Cartographer",
    "Temple Goods",
    "Curiosity Shop",
    "Pawn Shop",
    "Monster Artisan",
    "Other",
)


@dataclass(frozen=True)
class ShopDetails:
    record_id: str
    shop_type: str = "General Store"
    owner: str = ""
    location_name: str = ""
    price_notes: str = ""
    inventory_notes: str = ""
    recipes: str = "[]"


def _details_from_row(row: dict) -> ShopDetails:
    return ShopDetails(
        record_id=str(row.get("record_id", "") or ""),
        shop_type=str(row.get("shop_type", "General Store") or "General Store"),
        owner=str(row.get("owner", "") or ""),
        location_name=str(row.get("location_name", "") or ""),
        price_notes=str(row.get("price_notes", "") or ""),
        inventory_notes=str(row.get("inventory_notes", "") or ""),
        recipes=str(row.get("recipes", "") or "[]"),
    )


@dataclass(frozen=True)
class ForgeNextShop:
    record: ForgeNextRecord
    details: ShopDetails


class ShopRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "shops.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def shops(self) -> list[ForgeNextShop]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Shop"
        }
        details_by_id = {
            row.get("record_id", ""): _details_from_row(row)
            for row in self._read()
            if isinstance(row, dict)
        }
        return [
            ForgeNextShop(
                record,
                details_by_id.get(record.record_id, ShopDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_shop(
        self,
        name: str,
        shop_type: str,
        owner: str,
        location_name: str,
        price_notes: str,
        inventory_notes: str,
        status: str,
        description: str,
        recipes: str = "[]",
    ) -> ForgeNextShop:
        record = self.records.create_record("Shop", name, status, description)
        details = ShopDetails(
            record.record_id,
            shop_type or "Other",
            owner.strip(),
            location_name.strip(),
            price_notes.strip(),
            inventory_notes.strip(),
            recipes or "[]",
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextShop(record, details)

    def update_shop(
        self,
        record_id: str,
        name: str,
        shop_type: str,
        owner: str,
        location_name: str,
        price_notes: str,
        inventory_notes: str,
        status: str,
        description: str,
        recipes: str = "[]",
    ) -> ForgeNextShop:
        record = self.records.update_record(record_id, name, status, description)
        details = ShopDetails(
            record_id,
            shop_type or "Other",
            owner.strip(),
            location_name.strip(),
            price_notes.strip(),
            inventory_notes.strip(),
            recipes or "[]",
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextShop(record, details)
