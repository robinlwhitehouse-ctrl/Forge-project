"""Readable stat-block text for Stage popups (monsters and player characters).

Reads the flat detail fields plus the optional nested "sheet" dict that
Library's Monster workbook / Character worksheet write.  Works from the raw
JSON row so Stage does not need Library's dataclasses.  Empty fields are skipped.
"""

from __future__ import annotations

ABILITIES = (("STR", "str_score"), ("DEX", "dex_score"), ("CON", "con_score"),
             ("INT", "int_score"), ("WIS", "wis_score"), ("CHA", "cha_score"))
SPEED_MODES = ("walk", "fly", "swim", "climb", "burrow")
PC_SKILLS = (
    "Acrobatics", "Animal Handling", "Arcana", "Athletics", "Deception", "History",
    "Insight", "Intimidation", "Investigation", "Medicine", "Nature", "Perception",
    "Performance", "Persuasion", "Religion", "Sleight of Hand", "Stealth", "Survival",
)


def _s(value) -> str:
    return "" if value is None else str(value).strip()


def modifier(score) -> str:
    try:
        value = (int(_s(score)) - 10) // 2
    except ValueError:
        return ""
    return f"+{value}" if value >= 0 else str(value)


def _merge(details=None, row: dict | None = None) -> tuple[dict, dict]:
    data: dict = {}
    if details is not None:
        try:
            data.update({k: v for k, v in vars(details).items()})
        except TypeError:
            pass
    if isinstance(row, dict):
        data.update(row)
    sheet = data.get("sheet")
    return data, (sheet if isinstance(sheet, dict) else {})


class _Out:
    def __init__(self) -> None:
        self.lines: list[str] = []

    def line(self, label: str, value) -> None:
        value = _s(value)
        if value:
            self.lines.append(f"{label}: {value}" if label else value)

    def section(self, title: str, body) -> None:
        body = _s(body)
        if body:
            if self.lines and self.lines[-1] != "":
                self.lines.append("")
            self.lines.extend([title.upper(), body, ""])

    def gap(self) -> None:
        if self.lines and self.lines[-1] != "":
            self.lines.append("")

    def text(self) -> str:
        while self.lines and self.lines[-1] == "":
            self.lines.pop()
        return "\n".join(self.lines)


def _abilities(get) -> str:
    cells = []
    for label, key in ABILITIES:
        score = _s(get(key))
        if score:
            mod = modifier(score)
            cells.append(f"{label} {score} ({mod})" if mod else f"{label} {score}")
    return "   ".join(cells)


def format_monster(name: str = "", description: str = "", details=None, row: dict | None = None) -> str:
    data, sheet = _merge(details, row)
    get = lambda k: data.get(k, "")
    sh = lambda k: sheet.get(k, "")
    out = _Out()
    header = ", ".join(p for p in (
        " ".join(p for p in (_s(get("size")), _s(get("creature_type"))) if p),
        _s(get("alignment")),
    ) if p)
    out.line("", header)
    out.line("Watch use", get("watch_use"))
    out.gap()
    ac = _s(get("ac"))
    if ac and _s(sh("armor_note")):
        ac = f"{ac} ({_s(sh('armor_note'))})"
    out.line("Armor Class", ac)
    hp = _s(get("hp"))
    max_hp = _s(get("max_hp"))
    hp_text = hp if not max_hp or max_hp == hp else f"{hp} / {max_hp}" if hp else max_hp
    if _s(sh("hit_dice")):
        hp_text = f"{hp_text} ({_s(sh('hit_dice'))})" if hp_text else _s(sh("hit_dice"))
    out.line("Hit Points", hp_text)
    speeds = []
    for mode in SPEED_MODES:
        value = _s(sh(f"speed_{mode}"))
        if value:
            tag = " (hover)" if mode == "fly" and _s(sh("hover")) else ""
            speeds.append((value if mode == "walk" else f"{mode} {value}") + tag)
    if not speeds and _s(sh("hover")):
        speeds.append("hover")
    out.line("Speed", ", ".join(speeds) or get("speed"))
    out.gap()
    out.line("", _abilities(get))
    out.gap()
    out.line("Saving Throws", sh("saving_throws"))
    out.line("Skills", get("skills"))
    out.line("Damage Vulnerabilities", get("damage_vulnerabilities"))
    out.line("Damage Resistances", get("damage_resistances"))
    out.line("Damage Immunities", get("damage_immunities"))
    out.line("Condition Immunities", get("condition_immunities"))
    senses = _s(get("senses"))
    pp = _s(sh("passive_perception"))
    if pp and "passive" not in senses.lower():
        senses = f"{senses}, passive Perception {pp}" if senses else f"passive Perception {pp}"
    out.line("Senses", senses)
    out.line("Languages", get("languages"))
    cr_bits = [b for b in (
        _s(get("challenge_rating")),
        f"{_s(get('xp'))} XP" if _s(get("xp")) else "",
    ) if b]
    cr_text = " (".join(cr_bits) + (")" if len(cr_bits) == 2 else "")
    if _s(sh("proficiency_bonus")):
        cr_text = f"{cr_text}    Proficiency Bonus {_s(sh('proficiency_bonus'))}" if cr_text else ""
        if not cr_text:
            out.line("Proficiency Bonus", sh("proficiency_bonus"))
    out.line("Challenge", cr_text)
    out.line("Main attack", get("attack"))
    out.section("Traits", get("traits"))
    out.section("Spellcasting", sh("spellcasting"))
    out.section("Innate Spellcasting", sh("innate_spellcasting"))
    out.section("Actions", get("actions"))
    out.section("Bonus Actions", get("bonus_actions"))
    out.section("Reactions", get("reactions"))
    legendary = _s(get("legendary"))
    count = _s(sh("legendary_count"))
    if legendary or count:
        title = f"Legendary Actions ({count} per round)" if count else "Legendary Actions"
        out.section(title, legendary or "—")
    out.section("Lair Actions", sh("lair_actions"))
    out.section("Regional Effects", sh("regional_effects"))
    out.section("Description / Lore", sh("lore"))
    out.section("Tactics / DM Notes", sh("tactics"))
    out.section("Notes", description)
    out.section("Stat block (pasted)", get("stat_block"))
    _leftovers(out, sheet, _MONSTER_SHEET_KNOWN)
    return out.text()


_MONSTER_SHEET_KNOWN = {
    "armor_note", "hit_dice", "hover", "saving_throws", "passive_perception",
    "proficiency_bonus", "legendary_count", "lair_actions", "regional_effects",
    "spellcasting", "innate_spellcasting", "lore", "tactics",
} | {f"speed_{m}" for m in SPEED_MODES}


def _leftovers(out: _Out, sheet: dict, known: set) -> None:
    """Show any sheet key this Stage build doesn't know yet, so nothing is hidden."""
    extra = [(k, v) for k, v in sheet.items() if k not in known and _s(v)]
    if extra:
        out.section("Other", "\n".join(f"{k.replace('_', ' ')}: {_s(v)}" for k, v in extra))


def format_player_character(name: str = "", description: str = "", details=None, row: dict | None = None) -> str:
    data, sheet = _merge(details, row)
    get = lambda k: data.get(k, "")
    sh = lambda k: sheet.get(k, "")
    used: set = set()

    def take(k):
        used.add(k)
        return sh(k)

    out = _Out()
    level = _s(get("level"))
    klass = _s(get("character_class"))
    out.line("", " ".join(p for p in (_s(get("ancestry")), klass, f"(Level {level})" if level else "") if p))
    out.line("Player", get("player_name"))
    out.line("Background", get("background"))
    out.line("Alignment", get("alignment"))
    out.line("Experience", take("experience"))
    out.line("Inspiration", take("inspiration"))
    out.gap()
    out.line("Armor Class", get("ac"))
    hp = _s(get("hp"))
    max_hp = _s(get("max_hp"))
    hp_text = f"{hp} / {max_hp}" if hp and max_hp else hp or max_hp
    temp = _s(take("temp_hp"))
    if temp:
        hp_text = f"{hp_text}  (+{temp} temp)" if hp_text else f"+{temp} temp"
    out.line("Hit Points", hp_text)
    dice = "/".join(p for p in (_s(take("hit_dice")), _s(take("hit_dice_total"))) if p)
    out.line("Hit Dice (remaining/total)", dice)
    out.line("Initiative", take("initiative"))
    out.line("Speed", take("speed"))
    out.line("Proficiency Bonus", take("proficiency_bonus"))
    out.line("Passive Perception", take("passive_perception"))
    ds, df = _s(take("death_successes")), _s(take("death_failures"))
    if ds or df:
        out.line("Death Saves", f"successes {ds or 0}, failures {df or 0}")
    out.gap()
    cells, saves = [], []
    for label in ("STR", "DEX", "CON", "INT", "WIS", "CHA"):
        score = _s(take(f"score_{label}"))
        if score:
            mod = modifier(score)
            cells.append(f"{label} {score} ({mod})" if mod else f"{label} {score}")
        if _s(take(f"save_{label}")):
            saves.append(label)
    out.line("", "   ".join(cells))
    out.line("Saving Throw Proficiencies", ", ".join(saves))
    skills = []
    for skill in PC_SKILLS:
        mark = _s(take(f"skill_{skill}"))
        if mark:
            skills.append(f"{skill} (expertise)" if mark.lower().startswith("exp") else skill)
    out.line("Skill Proficiencies", ", ".join(skills))
    out.line("Skills / features", get("skills"))
    out.line("Attack", get("attack"))
    coins = "  ".join(f"{_s(take('coin_' + c))} {c}" for c in ("PP", "GP", "EP", "SP", "CP") if _s(sh("coin_" + c)))
    for c in ("PP", "GP", "EP", "SP", "CP"):
        used.add("coin_" + c)
    out.line("Coins", coins)
    for key, title in (
        ("attacks", "Attacks & Spellcasting"), ("other_proficiencies", "Other Proficiencies & Languages"),
        ("features_traits", "Features & Traits"), ("additional_features", "Additional Features & Traits"),
        ("equipment", "Equipment"), ("treasure", "Treasure"),
    ):
        out.section(title, take(key))
    cast = [(lbl, take(k)) for k, lbl in (
        ("spellcasting_class", "Class"), ("spellcasting_ability", "Ability"),
        ("spell_save_dc", "Save DC"), ("spell_attack_bonus", "Attack bonus"))]
    slots = []
    for n in range(1, 10):
        total, spent = _s(take(f"slots_total_{n}")), _s(take(f"slots_used_{n}"))
        if total or spent:
            slots.append(f"L{n} {spent or 0}/{total or '?'} used")
    spell_lines = ["   ".join(f"{l} {_s(v)}" for l, v in cast if _s(v))]
    if slots:
        spell_lines.append("Slots: " + ", ".join(slots))
    if _s(take("cantrips")):
        spell_lines.append("Cantrips: " + _s(sh("cantrips")))
    for n in range(1, 10):
        if _s(take(f"spells_{n}")):
            spell_lines.append(f"Level {n}: " + _s(sh(f"spells_{n}")))
    out.section("Spellcasting", "\n".join(l for l in spell_lines if l))
    looks = "   ".join(f"{k.title()} {_s(take(k))}" for k in ("age", "height", "weight", "eyes", "skin", "hair") if _s(sh(k)))
    for k in ("age", "height", "weight", "eyes", "skin", "hair"):
        used.add(k)
    out.section("Appearance", "\n".join(p for p in (looks, _s(take("appearance"))) if p))
    for key, title in (
        ("personality_traits", "Personality Traits"), ("ideals", "Ideals"), ("bonds", "Bonds"),
        ("flaws", "Flaws"), ("backstory", "Backstory"), ("allies_organizations", "Allies & Organizations"),
    ):
        out.section(title, take(key))
    out.section("Notes", description)
    _leftovers(out, sheet, used)
    return out.text()


def format_connections(records_repo, record_id: str) -> str:
    """Read-only 'Connections' text for a popup (two-way wording, grouped by type)."""
    if records_repo is None or not record_id:
        return ""
    try:
        from .link_presets import label_from
        links = records_repo.links_for(record_id)
        if not links:
            return ""
        names = {r.record_id: r for r in records_repo.records()}
    except Exception:
        return ""
    groups: dict[str, list[str]] = {}
    for link in links:
        outgoing = link.source_id == record_id
        other_id = link.target_id if outgoing else link.source_id
        other = names.get(other_id)
        kind = other.record_type if other else "Missing"
        name = other.name if other else other_id
        groups.setdefault(kind, []).append(f"  {label_from(link.relationship, outgoing)} {name}")
    lines = []
    for kind in sorted(groups):
        lines.append(f"{kind}:")
        lines.extend(sorted(groups[kind], key=str.lower))
    return "\n".join(lines)
