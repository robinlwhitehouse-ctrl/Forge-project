"""Player-character data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


@dataclass(frozen=True)
class PlayerCharacterDetails:
    record_id: str
    player_name: str = ""
    ancestry: str = ""
    character_class: str = ""
    level: str = "1"
    background: str = ""
    alignment: str = ""
    # Combat snapshot for tokens / stage
    ac: str = ""
    hp: str = ""
    max_hp: str = ""
    attack: str = ""
    skills: str = ""


def _details_from_row(row: dict) -> PlayerCharacterDetails:
    return PlayerCharacterDetails(
        record_id=str(row.get("record_id", "") or ""),
        player_name=str(row.get("player_name", "") or ""),
        ancestry=str(row.get("ancestry", "") or ""),
        character_class=str(row.get("character_class", "") or ""),
        level=str(row.get("level", "1") or "1"),
        background=str(row.get("background", "") or ""),
        alignment=str(row.get("alignment", "") or ""),
        ac=str(row.get("ac", "") or ""),
        hp=str(row.get("hp", "") or ""),
        max_hp=str(row.get("max_hp", "") or ""),
        attack=str(row.get("attack", "") or ""),
        skills=str(row.get("skills", "") or ""),
    )


@dataclass(frozen=True)
class ForgeNextPlayerCharacter:
    record: ForgeNextRecord
    details: PlayerCharacterDetails


class PlayerCharacterRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "player_characters.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def player_characters(self) -> list[ForgeNextPlayerCharacter]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Player Character"
        }
        details_by_id = {
            row.get("record_id", ""): _details_from_row(row)
            for row in self._read()
            if isinstance(row, dict)
        }
        return [
            ForgeNextPlayerCharacter(
                record,
                details_by_id.get(record.record_id, PlayerCharacterDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_player_character(
        self,
        name: str,
        player_name: str,
        ancestry: str,
        character_class: str,
        level: str,
        background: str,
        alignment: str,
        status: str,
        description: str,
        ac: str = "",
        hp: str = "",
        max_hp: str = "",
        attack: str = "",
        skills: str = "",
    ) -> ForgeNextPlayerCharacter:
        record = self.records.create_record("Player Character", name, status, description)
        details = PlayerCharacterDetails(
            record.record_id,
            player_name.strip(),
            ancestry.strip(),
            character_class.strip(),
            level.strip() or "1",
            background.strip(),
            alignment.strip(),
            ac.strip(),
            hp.strip(),
            max_hp.strip(),
            attack.strip(),
            skills.strip(),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextPlayerCharacter(record, details)

    def update_player_character(
        self,
        record_id: str,
        name: str,
        player_name: str,
        ancestry: str,
        character_class: str,
        level: str,
        background: str,
        alignment: str,
        status: str,
        description: str,
        ac: str = "",
        hp: str = "",
        max_hp: str = "",
        attack: str = "",
        skills: str = "",
    ) -> ForgeNextPlayerCharacter:
        record = self.records.update_record(record_id, name, status, description)
        details = PlayerCharacterDetails(
            record_id,
            player_name.strip(),
            ancestry.strip(),
            character_class.strip(),
            level.strip() or "1",
            background.strip(),
            alignment.strip(),
            ac.strip(),
            hp.strip(),
            max_hp.strip(),
            attack.strip(),
            skills.strip(),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextPlayerCharacter(record, details)
