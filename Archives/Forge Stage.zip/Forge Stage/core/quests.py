"""Quest-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


QUEST_TYPES = ("Main", "Side", "Personal", "Faction", "Event", "Other")
QUEST_ARCHETYPES = (
    "Escort",
    "Exploration",
    "Investigation",
    "Rescue",
    "Fetch",
    "Mystery",
    "Dungeon Expedition",
    "Political Intrigue",
    "Faction Assignment",
    "Multi-Stage Arc",
    "Other",
)


@dataclass(frozen=True)
class QuestDetails:
    record_id: str
    quest_type: str = "Side"
    archetype: str = "Other"
    priority: str = "Normal"
    difficulty: str = "Moderate"
    rewards: str = ""
    dm_notes: str = ""


@dataclass(frozen=True)
class ForgeNextQuest:
    record: ForgeNextRecord
    details: QuestDetails


class QuestRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "quests.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def quests(self) -> list[ForgeNextQuest]:
        records = {record.record_id: record for record in self.records.records() if record.record_type == "Quest"}
        details_by_id = {}
        for row in self._read():
            if not isinstance(row, dict) or not row.get("record_id"):
                continue
            try:
                details_by_id[row["record_id"]] = QuestDetails(
                    record_id=str(row.get("record_id") or ""),
                    quest_type=str(row.get("quest_type") or "Side"),
                    archetype=str(row.get("archetype") or "Other"),
                    priority=str(row.get("priority") or "Normal"),
                    difficulty=str(row.get("difficulty") or "Moderate"),
                    rewards=str(row.get("rewards") or ""),
                    dm_notes=str(row.get("dm_notes") or ""),
                )
            except TypeError:
                details_by_id[row["record_id"]] = QuestDetails(str(row.get("record_id") or ""))
        return [ForgeNextQuest(record, details_by_id.get(record.record_id, QuestDetails(record.record_id))) for record in records.values()]

    def create_quest(self, name: str, quest_type: str, archetype: str, priority: str, difficulty: str, status: str, description: str, rewards: str = "", dm_notes: str = "") -> ForgeNextQuest:
        record = self.records.create_record("Quest", name, status, description)
        details = QuestDetails(record.record_id, quest_type or "Other", archetype or "Other", priority or "Normal", difficulty or "Moderate", rewards or "", dm_notes or "")
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextQuest(record, details)

    def update_quest(self, record_id: str, name: str, quest_type: str, archetype: str, priority: str, difficulty: str, status: str, description: str, rewards: str = "", dm_notes: str = "") -> ForgeNextQuest:
        record = self.records.update_record(record_id, name, status, description)
        details = QuestDetails(record_id, quest_type or "Other", archetype or "Other", priority or "Normal", difficulty or "Moderate", rewards or "", dm_notes or "")
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextQuest(record, details)
