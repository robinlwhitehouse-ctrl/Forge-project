"""Project storage for Forge Next.

This module deliberately owns only project identity and folders.  Workbook
records, relationships, and migration will be added in later builds.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path


PROJECT_LAYOUT = (
    "data/records",
    "assets/images",
    "assets/videos",
    "assets/documents",
    "exports",
    "backups",
)


@dataclass(frozen=True)
class ForgeNextProject:
    name: str
    root: Path
    project_id: str

    @property
    def manifest_path(self) -> Path:
        return self.root / "project.json"


class ProjectRepository:
    """Create, list, and persist the selected Forge Next project."""

    def __init__(self, application_root: Path) -> None:
        self.application_root = application_root
        self.projects_root = application_root / "projects"
        self.state_path = application_root / "forge_next_state.json"
        self.projects_root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _slug(value: str) -> str:
        slug = re.sub(r"[^A-Za-z0-9]+", "-", value.strip()).strip("-").lower()
        return slug or "new-project"

    def create(self, name: str) -> ForgeNextProject:
        clean_name = " ".join(name.split())
        if not clean_name:
            raise ValueError("Enter a project name.")
        root = self.projects_root / clean_name
        if root.exists():
            raise ValueError("A Forge Next project with that name already exists.")
        root.mkdir(parents=True)
        for relative_path in PROJECT_LAYOUT:
            (root / relative_path).mkdir(parents=True, exist_ok=True)
        project = ForgeNextProject(clean_name, root, f"forge-next-{self._slug(clean_name)}")
        project.manifest_path.write_text(
            json.dumps(
                {
                    "format": "forge-next-project",
                    "format_version": 1,
                    "project_id": project.project_id,
                    "name": project.name,
                    "layout": list(PROJECT_LAYOUT),
                },
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
        return project

    def list(self) -> list[ForgeNextProject]:
        projects: list[ForgeNextProject] = []
        for manifest_path in self.projects_root.glob("*/project.json"):
            try:
                data = json.loads(manifest_path.read_text(encoding="utf-8"))
            except (OSError, ValueError, json.JSONDecodeError):
                continue
            if data.get("format") != "forge-next-project":
                continue
            projects.append(
                ForgeNextProject(
                    str(data.get("name", manifest_path.parent.name)),
                    manifest_path.parent,
                    str(data.get("project_id", "")),
                )
            )
        return sorted(projects, key=lambda project: project.name.casefold())

    def _read_state(self) -> dict:
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError, json.JSONDecodeError):
            return {}

    def _write_state(self, data: dict) -> None:
        current = self._read_state()
        current.update(data)
        self.state_path.write_text(
            json.dumps(current, indent=2) + "\n",
            encoding="utf-8",
        )

    def active_project_id(self) -> str:
        return str(self._read_state().get("active_project_id", ""))

    def set_active(self, project: ForgeNextProject) -> None:
        self._write_state({"active_project_id": project.project_id})

    def window_geometry(self) -> str:
        return str(self._read_state().get("window_geometry", ""))

    def set_window_geometry(self, geometry: str) -> None:
        if geometry:
            self._write_state({"window_geometry": geometry})

    def named_window_geometry(self, name: str, default: str = "") -> str:
        """Return last geometry for a named window (e.g. table_tools, scene, player)."""
        key = str(name or "").strip()
        if not key:
            return default
        geometries = self._read_state().get("window_geometries")
        if isinstance(geometries, dict):
            value = str(geometries.get(key, "") or "")
            if value:
                return value
        # Legacy single main window key still used via window_geometry()
        return default

    def set_named_window_geometry(self, name: str, geometry: str) -> None:
        key = str(name or "").strip()
        if not key or not geometry:
            return
        state = self._read_state()
        geometries = state.get("window_geometries")
        if not isinstance(geometries, dict):
            geometries = {}
        geometries[key] = str(geometry)
        self._write_state({"window_geometries": geometries})
