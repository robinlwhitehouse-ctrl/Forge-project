"""Trap-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


TRAP_TYPES = (
    "Mechanical", "Magical", "Natural", "Hybrid", "Alchemical", "Other",
)
TRAP_TRIGGERS = (
    "Pressure Plate", "Tripwire", "Proximity", "Touch", "Timed",
    "Sound", "Light", "Opening", "Closing", "Manual", "Other",
)
TRAP_SEVERITIES = (
    "Setback", "Dangerous", "Deadly",
)
TRAP_RESETS = (
    "None", "Manual", "Automatic", "Special",
)


@dataclass(frozen=True)
class TrapDetails:
    record_id: str
    trap_type: str = "Mechanical"
    trigger: str = "Pressure Plate"
    severity: str = "Dangerous"
    detection_dc: str = ""
    disarm_dc: str = ""
    damage: str = ""
    reset: str = "Manual"
    location_note: str = ""


@dataclass(frozen=True)
class ForgeNextTrap:
    record: ForgeNextRecord
    details: TrapDetails


class TrapRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "traps.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def traps(self) -> list[ForgeNextTrap]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Trap"
        }
        details_by_id = {
            row.get("record_id", ""): TrapDetails(**row)
            for row in self._read()
        }
        return [
            ForgeNextTrap(
                record,
                details_by_id.get(record.record_id, TrapDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_trap(
        self, name: str, trap_type: str, trigger: str, severity: str,
        detection_dc: str, disarm_dc: str, damage: str, reset: str,
        location_note: str, status: str, description: str,
    ) -> ForgeNextTrap:
        record = self.records.create_record("Trap", name, status, description)
        details = TrapDetails(
            record.record_id, trap_type or "Mechanical", trigger or "Pressure Plate",
            severity or "Dangerous", detection_dc.strip(), disarm_dc.strip(),
            damage.strip(), reset or "Manual", location_note.strip(),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextTrap(record, details)

    def update_trap(
        self, record_id: str, name: str, trap_type: str, trigger: str,
        severity: str, detection_dc: str, disarm_dc: str, damage: str,
        reset: str, location_note: str, status: str, description: str,
    ) -> ForgeNextTrap:
        record = self.records.update_record(record_id, name, status, description)
        details = TrapDetails(
            record_id, trap_type or "Mechanical", trigger or "Pressure Plate",
            severity or "Dangerous", detection_dc.strip(), disarm_dc.strip(),
            damage.strip(), reset or "Manual", location_note.strip(),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextTrap(record, details)
