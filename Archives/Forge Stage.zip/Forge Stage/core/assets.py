"""Project asset library and per-record attachments for Forge Next."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import hashlib
import shutil
from pathlib import Path
from uuid import uuid4

from .projects import ForgeNextProject


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff"}


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


KIND_FOLDERS = {
    "Map": "maps",
    "NPC": "npcs",
    "Monster": "monsters",
    "Player Character": "pcs",
    "Companion": "companions",
    "Item": "items",
    "Weapon": "weapons",
    "Armor": "armor",
    "Artifact": "artifacts",
    "Spell": "spells",
    "Feat": "feats",
    "Location": "locations",
    "Faction": "factions",
    "Shop": "shops",
    "Trap": "traps",
    "Encounter": "encounters",
    "Quest": "quests",
    "Session": "sessions",
    "Script": "scripts",
    "Table": "tables",
    "Token": "tokens",
}
# Unknown or missing types are stored in the assets/images root, as before.


@dataclass(frozen=True)
class ForgeNextAttachment:
    attachment_id: str
    record_id: str
    relative_path: str
    label: str
    kind: str
    created_at: str


class AssetRepository:
    """Files under assets/ plus attachment links to records."""

    def __init__(self, project: ForgeNextProject) -> None:
        self.project = project
        self.images_root = project.root / "assets" / "images"
        self.documents_root = project.root / "assets" / "documents"
        self.attachments_path = project.root / "data" / "records" / "attachments.json"
        self.images_root.mkdir(parents=True, exist_ok=True)
        self.documents_root.mkdir(parents=True, exist_ok=True)

    def _read_attachments(self) -> list[dict]:
        if not self.attachments_path.exists():
            return []
        with self.attachments_path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write_attachments(self, rows: list[dict]) -> None:
        self.attachments_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.attachments_path.with_suffix(self.attachments_path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.attachments_path)

    def attachments(self) -> list[ForgeNextAttachment]:
        rows = []
        for row in self._read_attachments():
            try:
                rows.append(ForgeNextAttachment(**row))
            except TypeError:
                continue
        return rows

    def attachments_for(self, record_id: str) -> list[ForgeNextAttachment]:
        return [item for item in self.attachments() if item.record_id == record_id]

    def list_images(self) -> list[Path]:
        files = []
        if not self.images_root.exists():
            return files
        for path in sorted(self.images_root.rglob("*")):
            if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS:
                files.append(path)
        return files

    def absolute_path(self, relative_path: str) -> Path:
        return (self.project.root / relative_path).resolve()

    def _file_digest(self, path: Path) -> str:
        hasher = hashlib.md5()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                hasher.update(chunk)
        return hasher.hexdigest()

    def import_image(self, source: Path, label: str | None = None) -> Path:
        source = Path(source)
        if not source.is_file():
            raise ValueError("Choose an existing image file.")
        if source.suffix.lower() not in IMAGE_EXTENSIONS:
            raise ValueError("Unsupported image type. Use PNG, JPG, GIF, WEBP, or BMP.")
        self.images_root.mkdir(parents=True, exist_ok=True)
        digest = self._file_digest(source)
        for existing in self.list_images():
            try:
                if existing.stat().st_size == source.stat().st_size and self._file_digest(existing) == digest:
                    return existing
            except OSError:
                continue
        stem = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in source.stem) or "image"
        folder = KIND_FOLDERS.get(label or "", "")
        dest_dir = self.images_root / folder if folder else self.images_root
        dest_dir.mkdir(parents=True, exist_ok=True)
        candidate = dest_dir / f"{stem}{source.suffix.lower()}"
        counter = 2
        while candidate.exists():
            candidate = dest_dir / f"{stem}_{counter}{source.suffix.lower()}"
            counter += 1
        shutil.copy2(source, candidate)
        return candidate

    def attach_image(self, record_id: str, source: Path, label: str | None = None, record_type: str = "") -> ForgeNextAttachment:
        stored = self.import_image(source, record_type or label)
        relative = stored.relative_to(self.project.root).as_posix()
        return self.attach_existing(record_id, relative, label or stored.name)

    def attach_existing(self, record_id: str, relative_path: str, label: str | None = None) -> ForgeNextAttachment:
        absolute = self.absolute_path(relative_path)
        if not absolute.is_file():
            raise ValueError("That asset file no longer exists.")
        relative_path = relative_path.replace("\\", "/")
        for item in self.attachments_for(record_id):
            if item.relative_path.replace("\\", "/") == relative_path:
                return item
        attachment = ForgeNextAttachment(
            attachment_id=f"ATT-{uuid4().hex[:8].upper()}",
            record_id=record_id,
            relative_path=relative_path.replace("\\", "/"),
            label=(label or absolute.name).strip() or absolute.name,
            kind="image",
            created_at=_now(),
        )
        rows = self._read_attachments()
        rows.append(asdict(attachment))
        self._write_attachments(rows)
        return attachment

    def detach(self, attachment_id: str) -> None:
        rows = self._read_attachments()
        remaining = [row for row in rows if row.get("attachment_id") != attachment_id]
        if len(remaining) == len(rows):
            raise ValueError("The selected attachment no longer exists.")
        self._write_attachments(remaining)

    def delete_image_file(self, relative_path: str) -> None:
        absolute = self.absolute_path(relative_path)
        if absolute.is_file() and self.images_root.resolve() in absolute.resolve().parents:
            absolute.unlink()
        rows = [
            row for row in self._read_attachments()
            if row.get("relative_path") != relative_path.replace("\\", "/")
        ]
        self._write_attachments(rows)
