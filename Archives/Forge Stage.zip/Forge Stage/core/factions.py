"""Faction-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


FACTION_TYPES = (
    "Guild", "Kingdom", "Order", "Cult", "Company",
    "Tribe", "Church", "Cabal", "House", "Other",
)
FACTION_SCOPES = (
    "Local", "Regional", "National", "Continental", "Planar", "Other",
)
INFLUENCE_LEVELS = (
    "Obscure", "Minor", "Moderate", "Major", "Dominant",
)


@dataclass(frozen=True)
class FactionDetails:
    record_id: str
    faction_type: str = "Other"
    scope: str = "Local"
    leader: str = ""
    headquarters: str = ""
    influence: str = "Minor"
    goals: str = ""


@dataclass(frozen=True)
class ForgeNextFaction:
    record: ForgeNextRecord
    details: FactionDetails


class FactionRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "factions.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def factions(self) -> list[ForgeNextFaction]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Faction"
        }
        details_by_id = {
            row.get("record_id", ""): FactionDetails(**row)
            for row in self._read()
        }
        return [
            ForgeNextFaction(
                record,
                details_by_id.get(record.record_id, FactionDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def create_faction(
        self, name: str, faction_type: str, scope: str, leader: str,
        headquarters: str, influence: str, goals: str,
        status: str, description: str,
    ) -> ForgeNextFaction:
        record = self.records.create_record("Faction", name, status, description)
        details = FactionDetails(
            record.record_id, faction_type or "Other", scope or "Local",
            leader.strip(), headquarters.strip(),
            influence or "Minor", goals.strip(),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextFaction(record, details)

    def update_faction(
        self, record_id: str, name: str, faction_type: str, scope: str,
        leader: str, headquarters: str, influence: str, goals: str,
        status: str, description: str,
    ) -> ForgeNextFaction:
        record = self.records.update_record(record_id, name, status, description)
        details = FactionDetails(
            record_id, faction_type or "Other", scope or "Local",
            leader.strip(), headquarters.strip(),
            influence or "Minor", goals.strip(),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextFaction(record, details)
