"""Session-specific data layered over shared Forge Next records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .projects import ForgeNextProject
from .records import ForgeNextRecord, RecordRepository


SESSION_ARCHETYPES = (
    "Campaign Opening",
    "Travel",
    "Investigation",
    "Exploration",
    "Roleplay",
    "Combat",
    "Downtime",
    "Mystery",
    "Boss Encounter",
    "Campaign Finale",
    "Other",
)


@dataclass(frozen=True)
class SessionDetails:
    record_id: str
    session_number: str = ""
    archetype: str = "Other"
    scheduled_date: str = ""
    read_aloud: str = ""
    dm_notes: str = ""
    hud_summary: str = ""
    narration_audio: str = ""
    map_id: str = ""  # Maps workbook record_id for Stage load
    encounter_id: str = ""  # Encounters workbook record_id for Stage load


def _details_from_row(row: dict) -> SessionDetails:
    return SessionDetails(
        record_id=str(row.get("record_id", "") or ""),
        session_number=str(row.get("session_number", "") or ""),
        archetype=str(row.get("archetype", "Other") or "Other"),
        scheduled_date=str(row.get("scheduled_date", "") or ""),
        read_aloud=str(row.get("read_aloud", "") or ""),
        dm_notes=str(row.get("dm_notes", "") or ""),
        hud_summary=str(row.get("hud_summary", "") or ""),
        narration_audio=str(row.get("narration_audio", "") or ""),
        map_id=str(row.get("map_id", "") or ""),
        encounter_id=str(row.get("encounter_id", "") or ""),
    )


@dataclass(frozen=True)
class ForgeNextSession:
    record: ForgeNextRecord
    details: SessionDetails


class SessionRepository:
    def __init__(self, project: ForgeNextProject, records: RecordRepository | None = None) -> None:
        self.project = project
        self.records = records or RecordRepository(project)
        self.path = project.root / "data" / "records" / "sessions.json"

    def _read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, list) else []

    def _write(self, rows: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(self.path)

    def sessions(self) -> list[ForgeNextSession]:
        records = {
            record.record_id: record
            for record in self.records.records()
            if record.record_type == "Session"
        }
        details_by_id = {
            str(row.get("record_id", "")): _details_from_row(row)
            for row in self._read()
            if isinstance(row, dict)
        }
        return [
            ForgeNextSession(
                record,
                details_by_id.get(record.record_id, SessionDetails(record.record_id)),
            )
            for record in records.values()
        ]

    def get(self, record_id: str) -> ForgeNextSession | None:
        for session in self.sessions():
            if session.record.record_id == record_id:
                return session
        return None

    def create_session(
        self,
        name: str,
        session_number: str,
        archetype: str,
        scheduled_date: str,
        status: str,
        description: str,
        *,
        read_aloud: str = "",
        dm_notes: str = "",
        hud_summary: str = "",
        narration_audio: str = "",
        map_id: str = "",
        encounter_id: str = "",
    ) -> ForgeNextSession:
        record = self.records.create_record("Session", name, status, description)
        details = SessionDetails(
            record.record_id,
            session_number.strip(),
            archetype or "Other",
            scheduled_date.strip(),
            (read_aloud or "").strip(),
            (dm_notes or "").strip(),
            (hud_summary or "").strip(),
            (narration_audio or "").strip(),
            (map_id or "").strip(),
            (encounter_id or "").strip(),
        )
        rows = self._read()
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextSession(record, details)

    def update_session(
        self,
        record_id: str,
        name: str,
        session_number: str,
        archetype: str,
        scheduled_date: str,
        status: str,
        description: str,
        *,
        read_aloud: str = "",
        dm_notes: str = "",
        hud_summary: str = "",
        narration_audio: str = "",
        map_id: str = "",
        encounter_id: str = "",
    ) -> ForgeNextSession:
        record = self.records.update_record(record_id, name, status, description)
        details = SessionDetails(
            record_id,
            session_number.strip(),
            archetype or "Other",
            scheduled_date.strip(),
            (read_aloud or "").strip(),
            (dm_notes or "").strip(),
            (hud_summary or "").strip(),
            (narration_audio or "").strip(),
            (map_id or "").strip(),
            (encounter_id or "").strip(),
        )
        rows = [row for row in self._read() if row.get("record_id") != record_id]
        rows.append(asdict(details))
        self._write(rows)
        return ForgeNextSession(record, details)

    def set_scene_text(
        self,
        record_id: str,
        *,
        read_aloud: str | None = None,
        dm_notes: str | None = None,
        hud_summary: str | None = None,
        narration_audio: str | None = None,
    ) -> ForgeNextSession:
        session = self.get(record_id)
        if session is None:
            raise ValueError("Session not found.")
        d = session.details
        return self.update_session(
            record_id,
            session.record.name,
            d.session_number,
            d.archetype,
            d.scheduled_date,
            session.record.status,
            session.record.description,
            read_aloud=d.read_aloud if read_aloud is None else read_aloud,
            dm_notes=d.dm_notes if dm_notes is None else dm_notes,
            hud_summary=d.hud_summary if hud_summary is None else hud_summary,
            narration_audio=d.narration_audio if narration_audio is None else narration_audio,
            map_id=d.map_id,
            encounter_id=d.encounter_id,
        )
