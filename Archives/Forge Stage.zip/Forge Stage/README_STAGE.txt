Forge Stage (new layout)
========================
This is the table-runner. Do NOT copy over C:\Forge Next 89\forge_next.py.

Unzip to C:\Forge Stage
RUN_STAGE.bat
Forge folder… → C:\Forge Next 89

Library / workbooks stay in 89.
This Stage writes map tokens, fog reveals, clock, and story-tracker log
into the same project those files already use.
